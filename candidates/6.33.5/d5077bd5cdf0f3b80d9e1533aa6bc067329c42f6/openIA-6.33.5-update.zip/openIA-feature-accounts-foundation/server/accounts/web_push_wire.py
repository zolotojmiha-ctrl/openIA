"""Web Push payload encryption (RFC 8291) and VAPID authentication (RFC 8292)."""
import base64
import json
import os
import re
import struct
import time
from http.client import HTTPSConnection
from urllib.parse import urlsplit

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


def encode(data):
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')


def decode(value):
    if not isinstance(value,str) or not re.fullmatch(r'[A-Za-z0-9_-]+',value):
        raise ValueError('Invalid base64url')
    return base64.b64decode(value+'='*(-len(value)%4),altchars=b'-_',validate=True)


def host_for(endpoint):
    if not isinstance(endpoint,str) or len(endpoint)>768 or not endpoint.isascii() or any(ord(c)<=32 or ord(c)==127 for c in endpoint):
        raise ValueError('Invalid push endpoint')
    parts = urlsplit(endpoint)
    host = parts.hostname or ''
    supported = host in ('fcm.googleapis.com','updates.push.services.mozilla.com','web.push.apple.com') or host.endswith('.web.push.apple.com')
    if not supported or parts.scheme!='https' or parts.netloc!=host or not parts.path.startswith('/') or '\\' in endpoint or parts.fragment:
        raise ValueError('Unsupported push endpoint')
    return parts


def public_bytes(key):
    return key.public_key().public_bytes(serialization.Encoding.X962,serialization.PublicFormat.UncompressedPoint)


def encrypt(message,ua_public,auth,private=None,salt=None):
    key = private or ec.generate_private_key(ec.SECP256R1())
    salt = os.urandom(16) if salt is None else salt
    sender_public = public_bytes(key)
    receiver_key = ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(),ua_public)
    shared = key.exchange(ec.ECDH(),receiver_key)
    ikm = HKDF(hashes.SHA256(),32,auth,b'WebPush: info\0'+ua_public+sender_public).derive(shared)
    cek = HKDF(hashes.SHA256(),16,salt,b'Content-Encoding: aes128gcm\0').derive(ikm)
    nonce = HKDF(hashes.SHA256(),12,salt,b'Content-Encoding: nonce\0').derive(ikm)
    if len(message)>3993:
        raise ValueError('Push payload too large')
    encrypted = AESGCM(cek).encrypt(nonce,message+b'\x02',None)
    return salt+struct.pack('!IB',4096,len(sender_public))+sender_public+encrypted


def authorization(key,origin,subject,now=None):
    header = encode(b'{"typ":"JWT","alg":"ES256"}')
    claims = encode(json.dumps({'aud':origin,'exp':int(time.time() if now is None else now)+3600,'sub':subject},separators=(',',':')).encode())
    token = header+'.'+claims
    signature = key.sign(token.encode(),ec.ECDSA(hashes.SHA256()))
    r,s = decode_dss_signature(signature)
    return f'vapid t={token}.{encode(r.to_bytes(32,"big")+s.to_bytes(32,"big"))}, k={encode(public_bytes(key))}'


def send(device,key,subject,payload):
    parts = host_for(device.endpoint)
    body = encrypt(json.dumps(payload,separators=(',',':')).encode(),decode(device.public_key),decode(device.auth_secret))
    path = parts.path+('?' +parts.query if parts.query else '')
    connection = HTTPSConnection(parts.hostname,timeout=4)
    try:
        connection.request('POST',path,body,{
            'Authorization':authorization(key,'https://'+parts.hostname,subject),
            'Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream',
            'TTL':'900','Topic':'armada-'+device.tag.hex[:24],
        })
        return connection.getresponse().status
    finally:
        connection.close()
