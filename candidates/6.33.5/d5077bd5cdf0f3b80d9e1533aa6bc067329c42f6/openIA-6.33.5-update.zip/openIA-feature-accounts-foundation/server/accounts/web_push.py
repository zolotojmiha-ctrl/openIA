"""Per-session Web Push for the cabinet. The same unread sources feed its badge."""
from datetime import timedelta
from http.client import HTTPException
import uuid

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ec
from django.conf import settings
from django.contrib.auth import HASH_SESSION_KEY, SESSION_KEY
from django.contrib.sessions.models import Session
from django.db import transaction
from django.utils import timezone
from django.utils.crypto import constant_time_compare

from documents.access import unread_documents, visible_documents
from documents.models import Notice
from postoffice.access import boxes
from projects.subcontract_scope import managed
from . import business_notices, web_push_wire as wire
from .models import Preference, WebPushDevice, WebPushKey


ROUTES = {'business':'/cabinet/inbox/','document':'/cabinet/documents/?mode=inbox','mail':'/cabinet/mail/'}


def enabled(user):
    return bool(settings.ARMADA_WEB_PUSH_ENABLED and user.is_authenticated and user.is_active
                and not user.must_change_password
                and (user.is_leader or user.role not in ('customer','lessor') and not managed(user)))


def comments(user):
    return Notice.objects.filter(user=user,read=False,document__in=visible_documents(user).filter(archived=False))


def inventory(user):
    documents = set()
    versions = set()
    for ident, sequence in unread_documents(user).order_by().values_list('current_version_id','current_version__sequence'):
        (documents if sequence==1 else versions).add(str(ident))
    attention = set(map(str,comments(user).order_by().values_list('pk',flat=True)))
    business = set(map(str,business_notices.unread(user).order_by().values_list('pk',flat=True)))
    mail = {}
    count = len(documents)+len(versions)+len(attention)+len(business)
    for ident, unread, uids in boxes(user).filter(state='active').values_list('pk','unread','unread_uids'):
        count += unread
        # A mailbox carried over from the old cache has a count but no UID baseline yet.
        mail[str(ident)] = sorted(set(uids)) if uids or not unread else None
    return count,{'documents':sorted(documents),'versions':sorted(versions),'comments':sorted(attention),
                  'business':sorted(business),'mail':mail}


def badge_count(user, inbox, mail, business):
    return inbox+mail+business+comments(user).count()


def pending_route(user,previous,current):
    def added(kind):
        return bool(set(current[kind])-set(previous.get(kind,[])))
    if added('business'):
        return ROUTES['business']
    preference = Preference.objects.filter(user=user).first() or Preference()
    if any(getattr(preference,'notify_'+key) and added(key) for key in ('documents','versions','comments')):
        return ROUTES['document']
    old_mail = previous.get('mail',{})
    if any(uids and old_mail.get(ident,[]) is not None and set(uids)-set(old_mail.get(ident,[]))
           for ident,uids in current['mail'].items()):
        return ROUTES['mail']
    return None


def key():
    def generate():
        private = ec.generate_private_key(ec.SECP256R1())
        return private.private_bytes(serialization.Encoding.DER,serialization.PrivateFormat.PKCS8,serialization.NoEncryption())
    record,_ = WebPushKey.objects.get_or_create(pk=1,defaults={'private_key':generate})
    return serialization.load_der_private_key(bytes(record.private_key),password=None)


def subscription_values(data):
    endpoint = data.get('endpoint')
    wire.host_for(endpoint)
    keys = data.get('keys',{})
    public = keys.get('p256dh')
    auth = keys.get('auth')
    if len(wire.decode(public))!=65 or len(wire.decode(auth))!=16 or not public.startswith('B'):
        raise ValueError('Invalid push subscription')
    ec.EllipticCurvePublicKey.from_encoded_point(ec.SECP256R1(),wire.decode(public))
    return endpoint,public,auth


@transaction.atomic
def register(user,session_key,data):
    endpoint,public,auth = subscription_values(data)
    count,state = inventory(user)
    device,created = WebPushDevice.objects.select_for_update().get_or_create(endpoint=endpoint,defaults={
        'public_key':public,'auth_secret':auth,'user':user,'session_key':session_key,'checkpoint':state,
    })
    if not created and (device.user_id!=user.pk or device.session_key!=session_key or
                        device.public_key!=public or device.auth_secret!=auth):
        device.user=user
        device.session_key=session_key
        device.public_key=public
        device.auth_secret=auth
        device.tag=uuid.uuid4()
        device.checkpoint=state
        device.due_at=timezone.now()
        device.save(update_fields=['user','session_key','public_key','auth_secret','tag','checkpoint','due_at'])
    return device.tag,count


def live_session(device,now):
    if not enabled(device.user):
        return False
    session = Session.objects.filter(session_key=device.session_key,expire_date__gt=now).first()
    if not session:
        return False
    data = session.get_decoded()
    return (data.get(SESSION_KEY)==str(device.user_id) and
            constant_time_compare(data.get(HASH_SESSION_KEY,''),device.user.get_session_auth_hash()))


@transaction.atomic
def scan(device_id,now):
    device = WebPushDevice.objects.select_for_update(of=('self',),skip_locked=True).select_related('user').filter(
        pk=device_id,due_at__lte=now,
    ).first()
    if not device:
        return
    if not live_session(device,now):
        device.delete()
        return
    count,state = inventory(device.user)
    route = pending_route(device.user,device.checkpoint,state)
    delay = 30
    if route:
        try:
            status = wire.send(device,key(),settings.ARMADA_WEB_PUSH_SUBJECT,
                               {'tag':str(device.tag),'badge':count,'route':route})
        except (OSError,HTTPException,ValueError):
            status = 503
        if status in (404,410):
            device.delete()
            return
        if not 200<=status<300:
            # Keep the checkpoint to retry this unread event. Never log the endpoint.
            state = device.checkpoint
            delay = 120
    device.checkpoint = state
    device.due_at = now+timedelta(seconds=delay)
    device.save(update_fields=['checkpoint','due_at'])


def tick():
    if not settings.ARMADA_WEB_PUSH_ENABLED:
        return
    now = timezone.now()
    ids = list(WebPushDevice.objects.filter(due_at__lte=now).order_by('due_at','pk').values_list('pk',flat=True)[:4])
    for pk in ids:
        scan(pk,now)
