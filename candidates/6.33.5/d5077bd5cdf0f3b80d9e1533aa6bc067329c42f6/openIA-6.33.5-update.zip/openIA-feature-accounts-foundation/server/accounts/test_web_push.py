from datetime import timedelta
from unittest.mock import patch

from cryptography.hazmat.primitives.asymmetric import ec
from django.contrib.sessions.models import Session
from django.test import Client, SimpleTestCase, TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from documents.models import Comment, Document, Notice
from postoffice.models import Mailbox
from postoffice.transport import unread_fields
from projects.models import COMPANY_TAX_ID, LegalEntity

from . import web_push, web_push_wire as wire
from .models import AuditEvent, BusinessNoticeRead, User, WebPushDevice


class WebPushWireTests(SimpleTestCase):
    def test_matches_rfc_8291_example(self):
        receiver = wire.decode(
            'BCVxsr7N_eNgVRqvHtD0zTZsEc6-VV-JvLexhqUzORcx'
            'aOzi6-AYWXvTBHm4bjyPjs7Vd8pZGH6SRpkNtoIAiw4'
        )
        sender = wire.decode('yfWPiYE-n46HLnH0KqZOF1fJJU3MYrct3AELtAQ-oRw')
        private = ec.derive_private_key(int.from_bytes(sender, 'big'), ec.SECP256R1())
        body = wire.encrypt(
            b'When I grow up, I want to be a watermelon',
            receiver, wire.decode('BTBZMqHH6r4Tts7J_aSIgg'),
            private, wire.decode('DGv6ra1nlYgDCS1FRnbzlw'),
        )
        self.assertEqual(
            wire.encode(body),
            'DGv6ra1nlYgDCS1FRnbzlwAAEABBBP4z9KsN6nGRTbVYI_c7VJSPQTBtkgcy27ml'
            'mlMoZIIgDll6e3vCYLocInmYWAmS6TlzAC8wEqKK6PBru3jl7A_yl95bQpu6cVPT'
            'pK4Mqgkf1CXztLVBSt2Ks3oZwbuwXPXLWyouBWLVWGNWQexSgSxsj_Qulcy4a-fN',
        )


@override_settings(ARMADA_WEB_PUSH_ENABLED=True)
class WebPushTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.leader = User.objects.create_user('+70000004001', leader_slot=1, must_change_password=False)
        cls.employee = User.objects.create_user('+70000004002', must_change_password=False)
        cls.customer = User.objects.create_user('+70000004003', role='customer', must_change_password=False)

    def setUp(self):
        self.client.force_login(self.leader)
        self.endpoint = 'https://web.push.apple.com/synthetic'
        self.keys = {
            'p256dh': wire.encode(wire.public_bytes(ec.generate_private_key(ec.SECP256R1()))),
            'auth': wire.encode(b'1234567890123456'),
        }
        self.url = reverse('web_push_subscribe')

    def subscribe(self, endpoint=None, client=None):
        return (client or self.client).post(
            self.url, {'endpoint': endpoint or self.endpoint, 'keys': self.keys},
            content_type='application/json', secure=True,
        )

    def scan(self):
        device = WebPushDevice.objects.get()
        web_push.scan(device.pk, device.due_at)

    @patch('accounts.web_push.wire.send', return_value=201)
    def test_business_event_only_pushes_once_and_read_clears_badge(self, send):
        AuditEvent.objects.create(action='repair_reported', details={'kind': 'complete'})
        baseline = self.subscribe().json()
        self.assertEqual(baseline['badge'], 1)
        self.scan()
        send.assert_not_called()

        event = AuditEvent.objects.create(action='repair_exclusion_requested', details={'private': 'example'})
        self.assertEqual(self.subscribe().json()['tag'], baseline['tag'])
        self.scan()
        send.assert_called_once()
        self.assertEqual(send.call_args.args[3], {
            'tag': baseline['tag'], 'badge': 2, 'route': reverse('business_inbox'),
        })
        BusinessNoticeRead.objects.create(user=self.leader, event=event)
        self.scan()
        send.assert_called_once()
        self.assertEqual(self.subscribe().json()['badge'], 1)

    @patch('accounts.web_push.wire.send', return_value=201)
    def test_new_mail_with_same_unread_count_pushes(self, send):
        mailbox = Mailbox.objects.create(address='fixture@example.org', owner=self.leader, created_by=self.leader, state='active')
        Mailbox.objects.filter(pk=mailbox.pk).update(**unread_fields([b'1']))
        subscribed = self.subscribe()
        self.assertEqual(subscribed.json()['badge'], 1)

        Mailbox.objects.filter(pk=mailbox.pk).update(**unread_fields([b'2']))
        self.scan()
        self.assertEqual(send.call_args.args[3], {
            'tag': subscribed.json()['tag'], 'badge': 1, 'route': reverse('mail'),
        })

        Mailbox.objects.filter(pk=mailbox.pk).update(**unread_fields([]))
        self.scan()
        send.assert_called_once()
        self.assertEqual(self.subscribe().json()['badge'], 0)

    @patch('accounts.web_push.wire.send', side_effect=[503, 410])
    def test_temporary_failure_can_retry_and_gone_endpoint_is_removed(self, send):
        self.subscribe()
        AuditEvent.objects.create(action='repair_exclusion_requested')
        checkpoint = WebPushDevice.objects.get().checkpoint
        self.scan()
        self.assertEqual(WebPushDevice.objects.get().checkpoint, checkpoint)
        self.scan()
        self.assertEqual(send.call_count, 2)
        self.assertFalse(WebPushDevice.objects.exists())

    @patch('accounts.web_push.wire.send', return_value=201)
    def test_comment_push_opens_inbox_containing_the_document(self, send):
        document = Document.objects.create(
            legal_entity=LegalEntity.objects.get(tax_id=COMPANY_TAX_ID),
            title='Контрольный документ с комментарием', section='general', created_by=self.leader,
        )
        self.subscribe()
        comment = Comment.objects.create(document=document, author=self.employee, text='Проверка')
        Notice.objects.create(user=self.leader, document=document, comment=comment)
        self.scan()
        payload = send.call_args.args[3]
        self.assertEqual(payload['badge'], 1)
        self.assertContains(self.client.get(payload['route'], secure=True), document.title)
        self.assertEqual(self.client.get(reverse('notifications'), secure=True).json()['badge'], 1)

    @patch('accounts.web_push.wire.send')
    def test_revoked_session_drops_device(self, send):
        self.subscribe()
        Session.objects.filter(session_key=self.client.session.session_key).update(
            expire_date=timezone.now()-timedelta(seconds=1),
        )
        self.scan()
        send.assert_not_called()
        self.assertFalse(WebPushDevice.objects.exists())

    def test_switch_account_rotates_tag_and_logout_revokes_device(self):
        initial = self.subscribe().json()
        second = Client()
        second.force_login(self.employee)
        self.assertNotEqual(initial['tag'], self.subscribe(client=second).json()['tag'])
        self.assertEqual(WebPushDevice.objects.get().user, self.employee)
        second.post(reverse('logout'), secure=True)
        self.assertFalse(WebPushDevice.objects.exists())

    def test_subscription_requires_allowed_https_account_and_endpoint(self):
        for endpoint in (
            'http://web.push.apple.com/foo', 'https://web.push.apple.com.invalid/foo',
            'https://127.0.0.1/foo', 'https://web.push.apple.com:443/foo',
        ):
            with self.subTest(endpoint=endpoint):
                self.assertEqual(self.subscribe(endpoint).status_code, 400)
        self.client.force_login(self.customer)
        self.assertEqual(self.subscribe().status_code, 403)
        self.assertFalse(WebPushDevice.objects.exists())

        protected = Client(enforce_csrf_checks=True)
        protected.force_login(self.leader)
        self.assertEqual(self.subscribe(client=protected).status_code, 403)

    def test_config_keeps_public_key_and_worker_is_scoped_to_cabinet(self):
        config = reverse('web_push_config')
        self.assertEqual(self.client.get(config).status_code, 403)
        first = self.client.get(config, secure=True).json()['key']
        self.assertEqual(first, self.client.get(config, secure=True).json()['key'])
        self.assertEqual(len(wire.decode(first)), 65)
        worker = self.client.get(reverse('cabinet_worker'), secure=True)
        self.assertEqual(worker.headers['Service-Worker-Allowed'], '/cabinet/')
        self.assertContains(worker, 'showNotification')
