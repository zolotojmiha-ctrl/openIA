import json
from pathlib import Path

from django.conf import settings
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_GET, require_POST

from . import web_push
from .web_push_wire import encode, public_bytes


@require_GET
def worker(request):
    path = Path(settings.BASE_DIR)/'server'/'static'/'brand'/'cabinet-worker.js'
    return HttpResponse(path.read_bytes(),content_type='application/javascript',
                        headers={'Cache-Control':'no-cache','Service-Worker-Allowed':'/cabinet/'})


def allowed(request):
    return request.is_secure() and web_push.enabled(request.user) and request.session.session_key


@require_GET
@ensure_csrf_cookie
def config(request):
    if not allowed(request):
        return JsonResponse({},status=403)
    return JsonResponse({'key':encode(public_bytes(web_push.key()))},headers={'Cache-Control':'private, no-store'})


@require_POST
def subscribe(request):
    if not allowed(request):
        return JsonResponse({},status=403)
    if request.content_type!='application/json' or len(request.body)>4096:
        return JsonResponse({},status=400)
    try:
        data = json.loads(request.body)
        tag,count = web_push.register(request.user,request.session.session_key,data)
    except (ValueError,AttributeError,TypeError):
        return JsonResponse({},status=400)
    return JsonResponse({'tag':str(tag),'badge':count},headers={'Cache-Control':'private, no-store'})
