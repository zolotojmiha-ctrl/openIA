"""Native MAX submission and review of repair exclusion requests."""
from datetime import timedelta
from uuid import UUID

from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone

from repairs import exclusions
from .models import Draft


def label(defect):
    return f'№{defect.number} · км {defect.km} · {defect.section.project_object.name}'


def context(user, defect):
    from .leadership import contract_name
    return 'Контракт: '+contract_name(user,defect.contract)+'\n'+label(defect)


def request_text(user, row):
    return (
        f'Заявка на исключение дефекта\n{context(user,row.defect)}'
        + (f'\nВ заявке: №{row.target["number"]} · км {row.target["km"]}'
           if row.target != exclusions.target_snapshot(row.defect) else '')
        + f'\nПричина: {row.reason}\n{row.get_state_display()}'
    )


def delivery_allowed(binding, scope):
    user = binding.user
    if 'requests' in scope:
        current = exclusions.visible(user).filter(pk__in=scope['requests'],state='pending')
        return user.is_leader and current.count()==len(scope['requests'])
    if 'targets' in scope:
        return exclusions.can_request(user) and exclusions.targets(user).filter(pk__in=scope['targets']).count()==len(scope['targets'])
    return False


def leader_action(event, binding, parts):
    from .dialog import button, queue

    user = binding.user
    if not user.is_leader:
        raise PermissionDenied
    action, value = parts
    if action=='requests':
        page = max(0,int(value))
        rows = list(exclusions.visible(user).filter(state='pending').order_by('-created_at','-pk')[page*6:page*6+7])
        shown = rows[:6]
        buttons = [button(label(row.defect),f'excl:review:{row.pk}') for row in shown]
        if page:
            buttons.append(button('Назад',f'excl:requests:{page-1}'))
        if len(rows)>6:
            buttons.append(button('Далее',f'excl:requests:{page+1}'))
        queue(event,'Заявки на исключение дефектов' if shown else 'Заявок на рассмотрении нет.',buttons,
              binding=binding,scope={'exclusion':{'requests':[str(row.pk) for row in shown]}})
        return
    pk = UUID(value)
    row = exclusions.visible(user).filter(pk=pk).first()
    if row is None:
        raise PermissionDenied
    if action=='review':
        buttons = []
        if row.state=='pending':
            buttons = [button('Подтвердить исключение',f'excl:approve:{pk}'),
                       button('Отклонить заявку',f'excl:reject:{pk}')]
        body = request_text(user,row)
        if row.state=='pending':
            body += '\nПосле подтверждения дефект уйдёт из реестра. История и фото сохранятся.'
        # Do not send an obsolete confirmation card after another leader decides.
        scope = {'exclusion':{'requests':[str(pk)]}} if buttons else {}
        queue(event,body,buttons,binding=binding,scope=scope)
        return
    result = exclusions.decide(user,pk,action=='approve')
    queue(event,result.get_state_display(),[button('Другие заявки','excl:requests:0')],binding=binding)


def coordinator_action(event, binding, text, parts):
    from .dialog import button, queue

    user = binding.user
    if not exclusions.can_request(user):
        raise PermissionDenied
    drafts = Draft.objects.filter(binding=binding,action='exclusion',state__in=['reason','preview'])
    action, value = parts if parts else ('reason','')
    if action=='targets':
        page = max(0,int(value))
        rows = list(exclusions.targets(user).order_by('contract__number','section__project_object__name','kilometre','number','pk')[page*6:page*6+7])
        shown = rows[:6]
        buttons = [button(label(row),f'excl:pick:{row.pk}') for row in shown]
        if page:
            buttons.append(button('Назад',f'excl:targets:{page-1}'))
        if len(rows)>6:
            buttons.append(button('Далее',f'excl:targets:{page+1}'))
        queue(event,'Выберите дефект для заявки.' if shown else 'Доступных дефектов нет.',buttons,
              binding=binding,scope={'exclusion':{'targets':[str(row.pk) for row in shown]}})
        return
    if action=='pick':
        defect = exclusions.targets(user).filter(pk=UUID(value)).first()
        if defect is None or not exclusions.request_allowed(user,defect):
            raise PermissionDenied
        if Draft.objects.filter(binding=binding,state__in=['editing','photos','confirm']).exists():
            raise ValidationError('Сначала завершите или отмените текущий отчёт.')
        drafts.update(state='cancelled',raw={})
        draft = Draft.objects.create(binding=binding,job=defect.jobs.order_by('pk').first(),
            state='reason',action='exclusion',expires=timezone.now()+timedelta(minutes=30),
            raw={'defect':str(defect.pk),'snapshot':exclusions.target_snapshot(defect)})
        queue(event,context(user,defect)+'\nНапишите причину исключения.',
              [button('Отменить',f'excl:cancel:{draft.pk}')],binding=binding,
              scope={'exclusion':{'targets':[str(defect.pk)]}})
        return
    locked = drafts.select_for_update()
    draft = locked.filter(state='reason').first() if action=='reason' else locked.filter(pk=UUID(value)).first()
    if draft is None or draft.expires<=timezone.now():
        raise ValidationError('Откройте /исключить и выберите дефект заново.')
    if action=='cancel':
        draft.state='cancelled'
        draft.raw={}
        draft.save(update_fields=['state','raw'])
        queue(event,'Черновик заявки отменён.',binding=binding)
        return
    defect = exclusions.targets(user).filter(pk=draft.raw['defect']).first()
    if defect is None or exclusions.target_snapshot(defect)!=draft.raw['snapshot']:
        raise ValidationError('Карточка изменилась. Откройте /исключить и выберите дефект заново.')
    if action=='send' and draft.state=='preview':
        exclusions.submit(user,defect.pk,draft.raw['reason'],draft.raw['snapshot'])
        draft.state='done'
        draft.raw={}
        draft.save(update_fields=['state','raw'])
        queue(event,'Заявка направлена руководителям. Работа продолжается.',binding=binding)
        return
    if action!='reason':
        raise PermissionDenied
    if event.payload.get('photos') or not 1<=len(text)<=1000:
        raise ValidationError('Напишите причину текстом, до 1000 символов.')
    draft.raw['reason']=text
    draft.state='preview'
    draft.save(update_fields=['state','raw'])
    queue(event,context(user,defect)+'\nПричина: '+text,
          [button('Направить руководителям',f'excl:send:{draft.pk}'),button('Отменить',f'excl:cancel:{draft.pk}')],
          binding=binding,scope={'exclusion':{'targets':[str(defect.pk)]}})


def handle(event, binding):
    from .dialog import button, queue

    text = event.payload.get('text','').strip()
    if text.startswith('excl:'):
        _, action, value = text.split(':')
        if action in ('requests','review','approve','reject'):
            leader_action(event,binding,(action,value))
        elif action in ('targets','pick','send','cancel'):
            coordinator_action(event,binding,text,(action,value))
        else:
            raise PermissionDenied
        return True
    if not exclusions.can_request(binding.user):
        return False
    active = Draft.objects.filter(binding=binding,action='exclusion',state__in=['reason','preview'],
                                  expires__gt=timezone.now()).first()
    if active and text=='/отмена':
        coordinator_action(event,binding,text,('cancel',str(active.pk)))
    elif text=='/исключить':
        coordinator_action(event,binding,text,('targets','0'))
    elif active and active.state=='reason' and not text.startswith('/') and event.payload.get('kind')!='message_callback':
        coordinator_action(event,binding,text,None)
    elif active:
        queue(event,'Сначала отправьте или отмените черновик заявки.',[button('Отменить',f'excl:cancel:{active.pk}')],binding=binding)
    else:
        from projects.subcontract_scope import can_report
        if can_report(binding.user):
            return False
        queue(event,'Меню сотрудника субподрядчика.',[button('Запросить исключение дефекта','/исключить'),button('Склады','/склады')],binding=binding)
    return True
