"""Choose a physical coupling and reserve it against a subcontract job in MAX."""
from datetime import timedelta
from uuid import UUID, uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.db.models import Q
from django.utils import timezone

from projects import subcontract_stock as stock
from projects.stock_planning import job_label, validate_reservation_fit
from .models import Draft
from .subcontract_receipt import editable_warehouse


def pieces(event,binding,warehouse_id,page):
    from .dialog import button
    from .subcontract_stock import emit

    wh = editable_warehouse(binding.user,UUID(warehouse_id))
    if not 0<=page<=10000:
        raise ValidationError('Неверная страница.')
    allowed = stock.reservation_jobs(binding.user,wh,include_archived=True)
    rows = list(stock.reservable_pieces(wh).filter(
        Q(reserved_job__isnull=True) | Q(reserved_job__in=allowed),
    )[page*6:page*6+7])
    buttons = [button(('Закреплена: ' if item.reserved_job_id else 'Свободна: ')+str(item),
                      f'substock:reserve:{wh.pk}:{item.pk}') for item in rows[:6]]
    if page:
        buttons.append(button('Назад',f'substock:pieces:{wh.pk}:{page-1}'))
    if len(rows)>6:
        buttons.append(button('Далее',f'substock:pieces:{wh.pk}:{page+1}'))
    buttons.append(button('Склад',f'substock:show:{wh.pk}'))
    emit(event,binding,f'{wh.name}\nВыберите муфту.' if rows else 'Доступных для закрепления муфт нет.',
         buttons,warehouses=[wh.pk])


def begin(event,binding,warehouse_id,item_id):
    from .subcontract_stock import save_draft

    wh = editable_warehouse(binding.user,UUID(warehouse_id))
    item = stock.reservable_pieces(wh).filter(pk=UUID(item_id)).first()
    if not item:
        raise PermissionDenied
    if Draft.objects.filter(binding=binding,state__in=['editing','photos','confirm','reason','preview'],expires__gt=timezone.now()).exists():
        raise ValidationError('Сначала завершите или отмените текущее действие.')
    draft = {'mode':'reservation','warehouse':str(wh.pk),'item':str(item.pk),'version':item.version,
             'id':uuid4().hex,'step':'jobs','expires':(timezone.now()+timedelta(minutes=30)).isoformat()}
    if item.reserved_job_id:
        current = stock.reservation_jobs(binding.user,wh,include_archived=True).filter(pk=item.reserved_job_id).first()
        if not current:
            raise PermissionDenied
        draft.update(step='review',job=None)
        save_draft(binding,draft)
        preview(event,binding,draft,wh,item,current)
        return
    save_draft(binding,draft)
    jobs(event,binding,draft,wh,item,0)


def jobs(event,binding,draft,wh,item,page):
    from .dialog import button
    from .subcontract_stock import emit

    rows = list(stock.reservation_jobs(binding.user,wh,item)[page*6:page*6+7])
    nonce = draft['id']
    buttons = [button(f'{", ".join("км "+defect.km+" № "+defect.number for defect in job.active_defects)} · {job.section.project_object.name}',
                      f'substock:sjob:{nonce}:{job.pk}') for job in rows[:6]]
    if page:
        buttons.append(button('Назад',f'substock:sjobs:{nonce}:{page-1}'))
    if len(rows)>6:
        buttons.append(button('Далее',f'substock:sjobs:{nonce}:{page+1}'))
    buttons.append(button('Отменить',f'substock:cancel:{nonce}'))
    text = f'{item}\nВыберите работу для закрепления.' if rows else 'Нет текущих работ с таким типом, диаметром и толщиной стенки.'
    emit(event,binding,text,buttons,warehouses=[wh.pk],jobs=[job.pk for job in rows[:6]])


def preview(event,binding,draft,wh,item,job):
    from .dialog import button
    from .subcontract_stock import emit

    label = 'Закрепить муфту' if draft['job'] else 'Снять закрепление'
    emit(event,binding,f'{label}\n{wh.name}\n{item}\n{job_label(job)}',
         [button(label,f'substock:sconfirm:{draft["id"]}'),button('Отменить',f'substock:cancel:{draft["id"]}')],
         warehouses=[wh.pk],jobs=[job.pk])


def advance(event,binding,draft,wh,action,value,selected):
    from .dialog import button
    from .subcontract_stock import emit, save_draft

    item = stock.reservable_pieces(wh).filter(pk=draft['item'],version=draft['version']).first()
    if not item:
        raise ValidationError('Остаток или закрепление изменились. Отмените черновик и откройте склад заново.')
    if value!=draft['id']:
        raise ValidationError('Эта кнопка устарела. Откройте текущий черновик или отмените его.')
    if action=='sconfirm' and draft['step']=='review':
        job_id = UUID(draft['job']) if draft['job'] else None
        stock.reserve(binding.user,wh.pk,item.pk,draft['version'],job_id)
        save_draft(binding)
        text = 'Муфта закреплена за работой.' if job_id else 'Закрепление снято. Муфта снова свободна.'
        emit(event,binding,text,[button('Открыть склад',f'substock:show:{wh.pk}')],warehouses=[wh.pk])
        return
    if action=='sjobs' and draft['step']=='jobs':
        page = int(selected)
        if not 0<=page<=10000:
            raise ValidationError('Неверная страница.')
        jobs(event,binding,draft,wh,item,page)
        return
    if action=='sjob' and draft['step']=='jobs':
        job = stock.reservation_jobs(binding.user,wh,item).filter(pk=UUID(selected)).first()
        if not job:
            raise PermissionDenied
        validate_reservation_fit(item,job)
        draft.update(step='review',job=str(job.pk))
        save_draft(binding,draft)
        preview(event,binding,draft,wh,item,job)
        return
    raise ValidationError('Выберите работу, подтвердите действие или отмените черновик.')
