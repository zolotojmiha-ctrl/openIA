"""Native MAX warehouse listing and creation."""
from datetime import timedelta
from uuid import UUID, uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from projects import subcontract_stock as stock
from projects.subcontract_scope import managed
from .models import Draft


def save_draft(binding, draft=None):
    data = binding.menu_scope.copy()
    if draft is None:
        data.pop('subcontract_warehouse',None)
    else:
        data['subcontract_warehouse'] = draft
    binding.menu_scope = data
    binding.save(update_fields=['menu_scope'])


def delivery_allowed(binding, scope):
    user = binding.user
    ids = scope.get('warehouses',[])
    assignments = scope.get('assignments',[])
    if scope.get('jobs'):
        wh = stock.editable_warehouses(user).filter(pk__in=ids).first()
        if not wh or stock.reservation_jobs(user,wh,include_archived=True).filter(pk__in=scope['jobs']).count()!=len(scope['jobs']):
            return False
    return (user.is_leader or stock.assignments(user).exists()) and (
        stock.warehouses(user).filter(pk__in=ids).count()==len(ids)
        and stock.assignments(user).filter(pk__in=assignments).count()==len(assignments)
    )


def emit(event,binding,text,buttons=(),warehouses=(),assignments=(),jobs=()):
    from .dialog import queue
    queue(event,text,buttons,binding=binding,scope={'subcontract_stock':{
        'warehouses':[str(pk) for pk in warehouses],'assignments':[str(pk) for pk in assignments],
        'jobs':[str(pk) for pk in jobs],
    }})


def list_warehouses(event,binding,page):
    from .dialog import button
    start = page*6
    rows = list(stock.warehouses(binding.user).filter(archived=False).order_by(
        'subcontract_assignment__company__name','subcontract_assignment__contract__number','name','pk',
    )[start:start+7])
    buttons = [button(f'{row.name} · {row.subcontract_assignment.contract.number}',f'substock:show:{row.pk}') for row in rows[:6]]
    if page:
        buttons.append(button('Назад',f'substock:list:{page-1}'))
    if len(rows)>6:
        buttons.append(button('Далее',f'substock:list:{page+1}'))
    if not binding.user.is_leader:
        buttons.append(button('Добавить склад','substock:contracts:0'))
    emit(event,binding,'Склады субподрядчиков' if rows else 'Складов пока нет.',buttons,warehouses=[row.pk for row in rows[:6]])


def list_contracts(event,binding,page):
    from .dialog import button
    start = page*6
    scopes = list(stock.assignments(binding.user).order_by('contract__number','pk')[start:start+7])
    buttons = [button(str(scope.contract),f'substock:pick:{scope.pk}') for scope in scopes[:6]]
    if page:
        buttons.append(button('Назад',f'substock:contracts:{page-1}'))
    if len(scopes)>6:
        buttons.append(button('Далее',f'substock:contracts:{page+1}'))
    buttons.append(button('Склады','substock:list:0'))
    emit(event,binding,'Выберите контракт для нового склада.',buttons,assignments=[scope.pk for scope in scopes[:6]])


def preview(event,binding,draft,scope):
    from .dialog import button
    emit(event,binding,f'Новый склад\n{scope.company.name} · {scope.contract}\n{draft["name"]}\n{draft["location"] or "Адрес не указан"}',
         [button('Сохранить склад',f'substock:save:{draft["id"]}'),button('Отменить',f'substock:cancel:{draft["id"]}')],assignments=[scope.pk])


def handle(event,binding):
    from .dialog import button

    text = event.payload.get('text','').strip()
    user = binding.user
    draft = binding.menu_scope.get('subcontract_warehouse')
    callback = text.startswith('substock:')
    command = text=='/склады_субподрядчиков' or (text=='/склады' and managed(user))
    if not (command or callback or draft):
        return False
    if not user.is_leader and not stock.assignments(user).exists():
        raise PermissionDenied

    if callback:
        _,action,value,*extra = text.split(':',3)
    elif command:
        action,value = 'list','0'
    else:
        action,value = 'input',''
    if draft and (text=='/отмена' or action=='cancel' and value==draft['id']):
        save_draft(binding)
        emit(event,binding,'Черновик отменён.',[button('Склады','substock:list:0')])
        return True
    if draft and parse_datetime(draft['expires'])<=timezone.now():
        if not command:
            raise ValidationError('Черновик истёк. Откройте /склады и начните заново.')
        save_draft(binding)
        draft = None

    if action=='receive' and not draft:
        from .subcontract_receipt import begin
        begin(event,binding,value)
        return True
    if action=='transfer' and not draft:
        from .subcontract_transfer import begin
        begin(event,binding,value)
        return True
    if action in ('pieces','reserve') and not draft:
        from . import subcontract_reservation
        if action=='pieces':
            subcontract_reservation.pieces(event,binding,value,int(extra[0]) if extra else 0)
        else:
            subcontract_reservation.begin(event,binding,value,extra[0] if extra else '')
        return True
    if draft and draft.get('mode')=='reservation':
        from .subcontract_reservation import advance
        from .subcontract_receipt import editable_warehouse
        wh = editable_warehouse(user,draft['warehouse'])
        advance(event,binding,draft,wh,action,value,extra[0] if callback and extra else '')
        return True
    if draft and draft.get('mode')=='transfer':
        from .subcontract_transfer import advance
        from .subcontract_receipt import editable_warehouse
        source = editable_warehouse(user,draft['warehouse'])
        advance(event,binding,draft,source,action,value,extra[0] if callback and extra else '',text)
        return True
    if draft and draft.get('mode')=='receipt':
        from .subcontract_receipt import advance, editable_warehouse
        wh = editable_warehouse(user,draft['warehouse'])
        advance(event,binding,draft,wh,action,value,extra[0] if callback and extra else '',text)
        return True

    if action in ('list','contracts','show') and draft:
        raise ValidationError('Сначала сохраните или отмените черновик склада командой /отмена.')
    if action in ('list','contracts'):
        page = int(value)
        if not 0<=page<=10000:
            raise ValidationError('Неверная страница.')
        if action=='list':list_warehouses(event,binding,page)
        else:
            if user.is_leader:raise PermissionDenied
            list_contracts(event,binding,page)
    elif action=='show':
        row = stock.warehouses(user).filter(pk=UUID(value)).first()
        if row is None:
            raise PermissionDenied
        scope = row.subcontract_assignment
        page = int(extra[0]) if extra else 0
        if not 0<=page<=10000:
            raise ValidationError('Неверная страница.')
        balances = stock.balances(row)
        count = balances.count()
        positions = '\n'.join(
            f'{b.item.name} · {format(b.quantity.normalize(),"f").replace(".",",")} {b.item.get_unit_display()}'
            + (' · закреплено' if b.item.reserved_job_id else '')
            for b in balances[page*6:page*6+6]
        )
        buttons = [button('Склады','substock:list:0')]
        if page:
            buttons.insert(0,button('Назад',f'substock:show:{row.pk}:{page-1}'))
        if count>(page+1)*6:
            buttons.insert(0,button('Следующие остатки',f'substock:show:{row.pk}:{page+1}'))
        if not row.archived and stock.assignments(user).filter(pk=scope.pk).exists():
            buttons.insert(0,button('Оформить поступление',f'substock:receive:{row.pk}'))
            if stock.transfer_destinations(user,row).exists() and stock.transfer_items(row).exists():
                buttons.insert(1,button('Переместить материал',f'substock:transfer:{row.pk}'))
            if stock.reservable_pieces(row).exists():
                buttons.insert(1,button('Закрепление муфт',f'substock:pieces:{row.pk}:0'))
        emit(event,binding,f'{row.name}\n{scope.company.name} · {scope.contract}\n{row.location or "Адрес не указан"}\nПозиций в остатках: {count}.\n{positions}',
             buttons,warehouses=[row.pk])
    elif action=='pick' and not draft:
        scope = stock.assignments(user).filter(pk=int(value)).first()
        if scope is None:
            raise PermissionDenied
        if Draft.objects.filter(binding=binding,state__in=['editing','photos','confirm','reason','preview'],expires__gt=timezone.now()).exists():
            raise ValidationError('Сначала завершите или отмените текущее действие.')
        draft = {'id':uuid4().hex,'assignment':scope.pk,'step':'name','expires':(timezone.now()+timedelta(minutes=30)).isoformat()}
        save_draft(binding,draft)
        emit(event,binding,f'{scope.contract}\nНапишите название склада (до 160 символов).',
             [button('Отменить',f'substock:cancel:{draft["id"]}')],assignments=[scope.pk])
    elif draft:
        scope = stock.assignments(user).filter(pk=draft['assignment']).first()
        if scope is None:
            raise PermissionDenied
        typed = action=='input' and text and not text.startswith('/') and not event.payload.get('photos')
        if action=='save' and value==draft['id'] and draft['step']=='preview':
            row = stock.create_warehouse(user,scope.pk,draft['name'],draft['location'])
            save_draft(binding)
            emit(event,binding,'Склад сохранён.',[button('Открыть склад',f'substock:show:{row.pk}')],warehouses=[row.pk])
        elif draft['step']=='name' and typed and len(text)<=160:
            draft.update(name=text,step='location')
            save_draft(binding,draft)
            emit(event,binding,'Напишите адрес или ориентир склада (до 250 символов).',
                 [button('Пропустить адрес',f'substock:skip:{draft["id"]}'),button('Отменить',f'substock:cancel:{draft["id"]}')],assignments=[scope.pk])
        elif draft['step']=='location' and ((action=='skip' and value==draft['id']) or (typed and len(text)<=250)):
            draft.update(location='' if action=='skip' else text,step='preview')
            save_draft(binding,draft)
            preview(event,binding,draft,scope)
        else:
            raise ValidationError('Проверьте текущий вопрос или отмените черновик командой /отмена.')
    else:
        raise ValidationError('Откройте /склады и выберите действие.')
    return True
