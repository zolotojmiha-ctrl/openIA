"""Receive customer materials from MAX using the cabinet receipt fields and ledger."""
from datetime import timedelta
from uuid import UUID, uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone

from projects import subcontract_stock as stock
from projects.diameters import label as diameter_label
from projects.stock_planning_views import ReceiptForm
from .models import Draft


FIXED_UNITS = {'coupling':'pcs','insulation':'m2','electrode':'kg'}
KIND_FIELDS = {'coupling':['method','diameter_mm','length_mm','wall_mm','serial'],
               'electrode':['name','electrode_brand','electrode_diameter']}


def editable_warehouse(user,pk):
    wh = stock.editable_warehouses(user).filter(pk=pk).first()
    if wh is None:
        raise PermissionDenied
    return wh


def begin(event,binding,value):
    from .subcontract_stock import save_draft

    wh = editable_warehouse(binding.user,UUID(value))
    if Draft.objects.filter(binding=binding,state__in=['editing','photos','confirm','reason','preview'],expires__gt=timezone.now()).exists():
        raise ValidationError('Сначала завершите или отмените текущее действие.')
    draft = {'mode':'receipt','warehouse':str(wh.pk),'id':uuid4().hex,'fields':['kind'],'step':0,
             'expires':(timezone.now()+timedelta(minutes=30)).isoformat(),'values':{}}
    save_draft(binding,draft)
    prompt(event,binding,draft,wh)


def prompt(event,binding,draft,wh):
    from .dialog import button
    from .subcontract_stock import emit

    form = ReceiptForm(user=binding.user,subcontract_warehouse=wh)
    key = draft['fields'][draft['step']]
    field = form.fields[key]
    prefix = f'substock:r{draft["step"]}:{draft["id"]}'
    buttons = []
    for value,title in getattr(field,'choices',[]):
        if not value:
            continue
        if key=='unit' and draft['values']['kind'] in ('composite','sealant') and value not in ('pcs','kit'):
            continue
        buttons.append(button(title,f'{prefix}:{value}'))
    if key=='serial':
        buttons.append(button('Номер пока неизвестен',f'{prefix}:skip'))
    if key=='date':
        buttons.append(button('Сегодня',f'{prefix}:{timezone.localdate():%Y-%m-%d}'))
    buttons.append(button('Отменить',f'substock:cancel:{draft["id"]}'))
    text = f'{wh.name} · приход от заказчика\n{field.label}'
    if key=='date':
        text += '\nВведите дату в формате ДД.ММ.ГГ или выберите «Сегодня».'
    emit(event,binding,text,buttons,warehouses=[wh.pk])


def advance(event,binding,draft,wh,action,value,selected,text):
    from .dialog import button, report_date
    from .subcontract_stock import emit, save_draft

    raw = draft['values']
    if action=='rconfirm' and value==draft['id'] and draft.get('review'):
        form = ReceiptForm(
            {**raw,'token':draft['id']},user=binding.user,subcontract_warehouse=wh,
        )
        if not form.is_valid():
            raise ValidationError([error for errors in form.errors.values() for error in errors])
        stock.receive(binding.user,wh.pk,form.cleaned_data)
        save_draft(binding)
        emit(event,binding,'Поступление сохранено. Остатки обновлены.',
             [button('Открыть склад',f'substock:show:{wh.pk}')],warehouses=[wh.pk])
        return
    if draft.get('review'):
        raise ValidationError('Подтвердите поступление или отмените его командой /отмена.')
    key = draft['fields'][draft['step']]
    form = ReceiptForm(user=binding.user,subcontract_warehouse=wh)
    field = form.fields[key]
    if action==f'r{draft["step"]}' and value==draft['id']:
        input_value = '' if key=='serial' and selected=='skip' else selected
    elif action=='input' and text and not text.startswith('/') and not event.payload.get('photos') and not getattr(field,'choices',None):
        input_value = text
    else:
        raise ValidationError('Ответьте на текущий вопрос или используйте /отмена.')
    if key=='date':
        input_value = report_date(input_value).isoformat()
    if key in ('quantity','electrode_diameter'):
        input_value = input_value.replace(',','.')
    cleaned = field.clean(input_value)
    if key=='date' and cleaned>timezone.localdate():
        raise ValidationError('Укажите фактическую дату получения.')
    if key=='quantity':
        from projects.models import StockItem
        from projects.stock import quantity
        amount = quantity(cleaned,StockItem(unit=raw['unit']))
        if raw['kind']=='coupling' and (amount>500 or amount>1 and raw.get('serial')):
            raise ValidationError('Укажите от 1 до 500 муфт. С заводским номером можно оприходовать одну муфту.')
    if key in ('length_mm','wall_mm','electrode_diameter') and cleaned<=0:
        raise ValidationError('Укажите размер больше нуля.')
    raw[key] = input_value
    if key=='kind':
        kind = raw[key]
        draft['fields'] += KIND_FIELDS.get(kind,['name'])
        if kind in FIXED_UNITS:
            raw['unit'] = FIXED_UNITS[kind]
        else:
            draft['fields'].append('unit')
        draft['fields'] += ['quantity','date','note']
    draft['step'] += 1
    if draft['step'] < len(draft['fields']):
        save_draft(binding,draft)
        prompt(event,binding,draft,wh)
        return
    form = ReceiptForm({**raw,'token':draft['id']},user=binding.user,subcontract_warehouse=wh)
    if not form.is_valid():
        raise ValidationError([error for errors in form.errors.values() for error in errors])
    values = form.cleaned_data
    from projects.models import StockItem
    kind = dict(StockItem._meta.get_field('kind').choices)[values['kind']]
    unit = dict(StockItem._meta.get_field('unit').choices)[values['unit']]
    lines = ['Проверьте поступление от заказчика',str(wh.subcontract_assignment.contract),wh.name,
             kind + (f' · {values["name"]}' if values.get('name') else '')]
    if values['kind']=='coupling':
        method = dict(form.fields['method'].choices)[values['method']]
        lines.append(f'{method} · {diameter_label(values["diameter_mm"])} · {values["length_mm"]}×{values["wall_mm"]} мм')
        lines.append(f'Заводской номер: {values["serial"] or "пока не указан"}')
    if values['kind']=='electrode':
        lines.append(f'{values["electrode_brand"]} · Ø {values["electrode_diameter"]} мм')
    amount = format(values['quantity'].normalize(),'f').replace('.',',')
    lines += [f'{amount} {unit} · {values["date"]:%d.%m.%Y}',values['note']]
    draft['review'] = True
    save_draft(binding,draft)
    emit(event,binding,'\n'.join(lines),
         [button('Оприходовать',f'substock:rconfirm:{draft["id"]}'),button('Отменить',f'substock:cancel:{draft["id"]}')],warehouses=[wh.pk])
