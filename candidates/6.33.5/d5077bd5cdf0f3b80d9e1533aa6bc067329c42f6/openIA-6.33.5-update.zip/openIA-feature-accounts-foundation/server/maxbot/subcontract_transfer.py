"""Native MAX transfer using the cabinet forms and stock ledger."""
from datetime import timedelta
from uuid import UUID, uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone

from projects import subcontract_stock as stock
from projects.stock import quantity
from projects.subcontract_stock_views import TransferForm
from .models import Draft
from .subcontract_receipt import editable_warehouse


def begin(event,binding,value):
    from .subcontract_stock import save_draft

    source = editable_warehouse(binding.user,UUID(value))
    if Draft.objects.filter(binding=binding,state__in=['editing','photos','confirm','reason','preview'],expires__gt=timezone.now()).exists():
        raise ValidationError('Сначала завершите или отмените текущее действие.')
    if not stock.transfer_destinations(binding.user,source).exists() or not stock.transfer_items(source).exists():
        raise ValidationError('Для перемещения нужен материал в остатке и другой склад этого контракта.')
    draft = {'mode':'transfer','warehouse':str(source.pk),'id':uuid4().hex,'step':'item',
             'expires':(timezone.now()+timedelta(minutes=30)).isoformat(),'values':{}}
    save_draft(binding,draft)
    prompt(event,binding,draft,source)


def prompt(event,binding,draft,source,page=0):
    from .dialog import button
    from .subcontract_stock import emit

    step = draft['step']
    nonce = draft['id']
    warehouses = [source.pk]
    buttons = []
    if step in ('item','destination'):
        if step=='item':
            rows = stock.transfer_items(source)
            title = 'Выберите материал или изделие'
        else:
            rows = stock.transfer_destinations(binding.user,source)
            title = 'Выберите склад назначения'
        choices = list(rows[page*6:page*6+7])
        buttons = [button(str(row),f'substock:t{step}:{nonce}:{row.pk}') for row in choices[:6]]
        if step=='destination':
            warehouses += [row.pk for row in choices[:6]]
        if page:
            buttons.append(button('Назад',f'substock:tpage:{nonce}:{page-1}'))
        if len(choices)>6:
            buttons.append(button('Далее',f'substock:tpage:{nonce}:{page+1}'))
    else:
        form = TransferForm(user=binding.user,source=source)
        title = form.fields[step].label
        if step=='date':
            buttons.append(button('Сегодня',f'substock:tdate:{nonce}:{timezone.localdate():%Y-%m-%d}'))
            title += '\nВведите дату в формате ДД.ММ.ГГ или выберите «Сегодня».'
    buttons.append(button('Отменить',f'substock:cancel:{nonce}'))
    emit(event,binding,f'Перемещение со склада {source.name}\n{title}',buttons,warehouses=warehouses)


def advance(event,binding,draft,source,action,value,selected,text):
    from .dialog import button, report_date
    from .subcontract_stock import emit, save_draft

    step = draft['step']
    nonce = draft['id']
    values = draft['values']
    if action=='tpage' and value==nonce and step in ('item','destination'):
        page = int(selected)
        if not 0<=page<=10000:
            raise ValidationError('Неверная страница.')
        prompt(event,binding,draft,source,page)
        return
    if step=='review':
        if action!='tconfirm' or value!=nonce:
            raise ValidationError('Подтвердите перемещение или отмените его командой /отмена.')
        form = checked_form(binding,source,draft)
        movement = stock.transfer(binding.user,source.pk,form.cleaned_data)
        save_draft(binding)
        emit(event,binding,'Перемещение сохранено. Остатки обоих складов обновлены.',
             [button('Открыть склад назначения',f'substock:show:{movement.destination_id}')],
             warehouses=[source.pk,movement.destination_id])
        return

    form = TransferForm(user=binding.user,source=source)
    if action==f't{step}' and value==nonce and step in ('item','destination','date'):
        answer = selected
    elif action=='input' and step not in ('item','destination') and text and not text.startswith('/') and not event.payload.get('photos'):
        answer = text
    else:
        raise ValidationError('Ответьте на текущий вопрос или используйте /отмена.')
    if step=='date':
        day = report_date(answer)
        if day>timezone.localdate():
            raise ValidationError('Укажите фактическую дату перемещения.')
        answer = day.isoformat()
    if step=='quantity':
        item = stock.transfer_items(source).filter(pk=values['item']).first()
        if not item:
            raise ValidationError('Материал больше недоступен на этом складе.')
        amount = quantity(answer.replace(',','.'),item)
        available = stock.balances(source).filter(item=item).values_list('quantity',flat=True).first() or 0
        if amount>available:
            raise ValidationError('Недостаточный остаток. Укажите меньшее количество.')
        answer = str(amount)
    form.fields[step].clean(answer)
    values[step] = answer
    steps = {'item':'destination','destination':'quantity','quantity':'date','date':'note','note':'review'}
    draft['step'] = steps[step]
    if draft['step']!='review':
        save_draft(binding,draft)
        prompt(event,binding,draft,source)
        return
    data = checked_form(binding,source,draft).cleaned_data
    amount = format(data['quantity'].normalize(),'f').replace('.',',')
    preview = (
        f'Проверьте перемещение\n{source.subcontract_assignment.contract}\n'
        f'{source.name} → {data["destination"].name}\n{data["item"]}\n'
        f'{amount} {data["item"].get_unit_display()} · {data["date"]:%d.%m.%Y}\n{data["note"]}'
    )
    save_draft(binding,draft)
    emit(event,binding,preview,
         [button('Переместить',f'substock:tconfirm:{nonce}'),button('Отменить',f'substock:cancel:{nonce}')],
         warehouses=[source.pk,data['destination'].pk])


def checked_form(binding,source,draft):
    form = TransferForm({**draft['values'],'token':draft['id']},user=binding.user,source=source)
    if not form.is_valid():
        raise ValidationError([error for errors in form.errors.values() for error in errors])
    return form
