from projects.diameters import label as dn_label
from projects.diameters import DiameterField,preserve_legacy
import uuid
from collections import Counter
from decimal import Decimal
from django import forms
from django.contrib import messages
from django.core.exceptions import ValidationError
from django.db.models import Q,Prefetch
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, render, redirect
from django.utils import timezone
from accounts.permissions import permission_required, permitted
from repairs.access import visible_jobs
from repairs.models import Job, METHODS
from .models import StockItem,StockMovement
from .stock_views import ItemForm, DATE
from . import stock, stock_planning as planning

class ReceiptForm(ItemForm):
    return_inventory=forms.BooleanField(required=False,widget=forms.HiddenInput)
    catalogue_item=forms.ModelChoiceField(queryset=None,required=False,widget=forms.HiddenInput)
    catalogue_version=forms.IntegerField(required=False,widget=forms.HiddenInput)
    warehouse=forms.ModelChoiceField(label='На какой склад добавить (место хранения)',queryset=None)
    quantity=forms.DecimalField(label='Количество (муфты — отдельные изделия)',min_value=Decimal('.001'),max_digits=18,decimal_places=3,initial=1)
    date=forms.DateField(label='Дата получения',widget=DATE,initial=timezone.localdate)
    note=forms.CharField(label='Основание / поставка',max_length=1300,initial='Поступление на склад')
    token=forms.UUIDField(widget=forms.HiddenInput,initial=uuid.uuid4)
    def __init__(self,*args,user,subcontract_warehouse=None,**kwargs):
        super().__init__(*args,user=user,**kwargs)
        self.subcontract_receipt = subcontract_warehouse is not None
        for key in ('sku','archived','coupling','expected_version'):self.fields.pop(key,None)
        self.fields['name'].required=False
        self.fields['name'].help_text='Для муфты можно оставить пустым: название составится из типа.'
        self.fields['catalogue_item'].queryset=stock.items(user).filter(archived=False)
        self.fields['warehouse'].queryset=stock.warehouses(user).filter(archived=False).order_by('name')
        self.fields['unit'].help_text='Муфты — шт.; композит и герметик — компл.; изоляция — м²; Ксизол, обёртка, праймер и купершлак — кг. Старые единицы не пересчитываются автоматически.'
        if subcontract_warehouse:
            for name in ('return_inventory','catalogue_item','catalogue_version','warehouse','receipt_origin'):
                self.fields.pop(name)

    def clean(self):
        data = super().clean()
        if not self.subcontract_receipt:
            return data
        kind = data.get('kind')
        if kind=='coupling':
            for name in ('method','diameter_mm','length_mm','wall_mm'):
                if name not in self.errors and not data.get(name):
                    self.add_error(name,'Заполните параметр муфты.')
        elif kind and not data.get('name') and 'name' not in self.errors:
            self.add_error('name','Укажите наименование материала.')
        quantity = data.get('quantity')
        if quantity is not None:
            try:
                stock.quantity(quantity,StockItem(unit=data.get('unit')))
                if kind=='coupling' and quantity>500:
                    raise ValidationError('За одно поступление можно внести до 500 муфт.')
                if kind=='coupling' and quantity>1 and data.get('serial'):
                    raise ValidationError('С заводским номером можно оприходовать одну муфту.')
            except ValidationError as error:
                self.add_error('quantity',error)
        if data.get('date') and data['date']>timezone.localdate():
            self.add_error('date','Укажите фактическую дату получения.')
        return data

@permission_required('stock.manage')
def receipt(request):
    initial={'return_inventory':request.GET.get('return_inventory')=='1'}
    if request.GET.get('warehouse'):
        from django.http import Http404
        try:wid=uuid.UUID(request.GET['warehouse'])
        except ValueError:raise Http404
        wh=get_object_or_404(stock.warehouses(request.user),pk=wid);initial['warehouse']=wh
    if request.GET.get('item'):
        from django.http import Http404
        try:iid=uuid.UUID(request.GET['item'])
        except ValueError:raise Http404
        item=get_object_or_404(stock.items(request.user),pk=iid)
        initial.update({k:getattr(item,k) for k in (*stock.ITEM_FIELDS[:-1],'serial','receipt_origin')})
        if not item.movements.exists() and not item.coupling_id:initial.update(catalogue_item=item,catalogue_version=item.version)
    form=ReceiptForm(request.POST or None,user=request.user,initial=initial);status=200
    if request.method=='GET' and 'warehouse' not in initial:
        only=list(form.fields['warehouse'].queryset[:2])
        if len(only)==1:form.initial['warehouse']=only[0]
    if request.method=='POST' and form.is_valid():
        c=form.cleaned_data
        try:wh=planning.receive(request.user,c,c['warehouse'],c['quantity'],c['date'],c['note'],c['token'])
        except ValidationError as e:form.add_error(None,'; '.join(e.messages));status=409
        else:
            messages.success(request,'Поступление сохранено. Муфты добавлены поштучно в остатки.')
            return redirect('stock_inventory') if c.get('return_inventory') else redirect('stock_detail',pk=wh.pk)
    return render(request,'projects/stock_form.html',{'form':form,'title':'Добавить материал / муфты на склад','receipt':True},status=status)

class AllocationForm(forms.Form):
    expected_version=forms.IntegerField(widget=forms.HiddenInput)
    job=forms.ModelChoiceField(label='Закрепить за работой / дефектами',queryset=None,required=False,empty_label='Свободна — снять закрепление')
    serial=forms.CharField(label='Заводской № (необязательно)',max_length=100,required=False)
    def __init__(self,*args,user,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['job'].queryset=visible_jobs(user).exclude(state__in=['reported','confirmed','unrepairable']).exclude(contract__status='archived')
        self.fields['job'].label_from_instance=planning.job_label

@permission_required('stock.manage')
def allocate(request,pk):
    item=get_object_or_404(stock.items(request.user),pk=pk)
    if request.method=='GET':
        from .stock_groups import groups
        from django.urls import reverse
        from urllib.parse import urlencode
        group=next((g for g in groups(request.user) if any(m['item'].pk==pk for m in g['members'])),None)
        if not group or not group['warehouse'] or group['quantity']<=0:
            messages.error(request,'Сначала укажите склад и количество в режиме «Редактировать список».');return redirect('stock_inventory')
        member=next(m for m in group['members'] if m['item'].pk==pk)
        query={'group':group['token']}
        if member['quantity']==1:query['item']=str(pk)
        return redirect(reverse('stock_distribute')+'?'+urlencode(query))
    form=AllocationForm(request.POST or None,user=request.user,initial={'expected_version':item.version,'serial':item.serial or (item.coupling.serial if item.coupling_id else ''),'job':item.reserved_job_id});status=200
    if request.method=='POST' and form.is_valid():
        from django.db import transaction
        c=form.cleaned_data
        try:
            with transaction.atomic():
                values={k:getattr(item,k) for k in stock.ITEM_FIELDS};values.update(coupling=item.coupling,serial=c['serial'])
                updated=stock.save_item(request.user,item.pk,c['expected_version'],values)
                planning.reserve(request.user,pk,updated.version,c['job'].pk if c['job'] else None)
        except ValidationError as e:form.add_error(None,'; '.join(e.messages));status=409
        else:return redirect('stock_inventory')
    return render(request,'projects/stock_form.html',{'form':form,'title':'Заводской номер и назначение муфты','item_summary':item},status=status)

class DeleteForm(forms.Form):
    snapshot=forms.CharField(widget=forms.HiddenInput)
    warehouse_id=forms.UUIDField(required=False,widget=forms.HiddenInput)
    all_warehouses=forms.BooleanField(label='Подтверждаю удаление со ВСЕХ перечисленных складов',required=False)
    expected_version=forms.IntegerField(widget=forms.HiddenInput)
    note=forms.CharField(label='Причина удаления ошибочной позиции',max_length=1200,widget=forms.Textarea)

@permission_required('stock.manage')
def delete(request,pk):
    item=get_object_or_404(stock.items(request.user),pk=pk);status=200
    raw=request.POST.get('warehouse_id') if request.method=='POST' else request.GET.get('warehouse')
    warehouse=None
    if raw:
        from django.http import Http404
        try:wid=uuid.UUID(raw)
        except ValueError:raise Http404
        warehouse=get_object_or_404(stock.warehouses(request.user),pk=wid)
    balances=item.balances.filter(quantity__gt=0).select_related('warehouse')
    if warehouse:balances=balances.filter(warehouse=warehouse)
    balances=list(balances)
    form=DeleteForm(request.POST or None,initial={'expected_version':item.version,'warehouse_id':warehouse.pk if warehouse else None,'snapshot':planning.delete_snapshot(request.user,item,warehouse.pk if warehouse else None)})
    if warehouse or len(balances)<=1:form.fields.pop('all_warehouses')
    if request.method=='POST' and form.is_valid():
        try:planning.delete(request.user,pk,form.cleaned_data['expected_version'],form.cleaned_data['note'],warehouse.pk if warehouse else None,form.cleaned_data.get('all_warehouses',False),form.cleaned_data['snapshot'])
        except ValidationError as e:form.add_error(None,'; '.join(e.messages));status=409
        else:
            messages.success(request,'Позиция удалена с выбранного склада. Остальные склады и история сохранены.' if warehouse else 'Позиция удалена. История сохранена.')
            return redirect('stock_detail',pk=warehouse.pk) if warehouse else redirect('stock_inventory')
    return render(request,'projects/stock_form.html',{'form':form,'title':'Удалить со склада '+warehouse.name if warehouse else 'Удалить карточку со всех складов','item_summary':item,'deletion':True,'delete_balances':balances,'warehouse':warehouse},status=status)

@permission_required('stock.manage')
def split(request,pk,warehouse_id):
    item=get_object_or_404(stock.items(request.user),pk=pk);form=forms.Form(request.POST or None);form.fields['expected_version']=forms.IntegerField(widget=forms.HiddenInput,initial=item.version);status=200
    if request.method=='POST' and form.is_valid():
        try:piece=planning.split(request.user,pk,form.cleaned_data['expected_version'],warehouse_id)
        except ValidationError as e:form.add_error(None,'; '.join(e.messages));status=409
        else:return redirect('stock_allocate',pk=piece.pk)
    return render(request,'projects/stock_form.html',{'form':form,'title':'Выделить 1 муфту из группового остатка','item_summary':item,'split_piece':True},status=status)


def inventory_rows(user,warehouse=None,include_archived=False):
    result=[]
    visible_movement_ids=set(stock.movements(user).values_list('pk',flat=True)) if not permitted(user,'stock.manage') else None
    allowed_warehouses=set(stock.warehouses(user).values_list('pk',flat=True))
    allowed_jobs=set(visible_jobs(user,include_archived=True).values_list('pk',flat=True))
    qs=stock.items(user)
    if not include_archived:qs=qs.filter(Q(archived=False)|Q(coupling__installation__isnull=False))
    qs=qs.select_related('coupling__installation__report','coupling__installation__job__section__project_object','coupling__installation__job__contract','receipt_warehouse','reserved_job__section__project_object','reserved_job__contract').prefetch_related('balances__warehouse',Prefetch('movements',queryset=StockMovement.objects.select_related('source','destination')),'reserved_job__defects','coupling__installation__job__defects')
    for item in qs.order_by('name','method','length_mm','serial','sku'):
        balances=[b for b in item.balances.all() if b.quantity>0 and (warehouse is None or b.warehouse_id==warehouse.pk)]
        moves=[m for m in item.movements.all() if visible_movement_ids is None or m.pk in visible_movement_ids];receipts=[m for m in reversed(moves) if m.kind=='receipt']
        install=item.coupling.installation if item.coupling_id and hasattr(item.coupling,'installation') else None
        state='installed' if install else 'reserved' if item.reserved_job_id else 'free' if balances else 'catalogue'
        if warehouse and not balances and not any(m.source_id==warehouse.pk or m.destination_id==warehouse.pk for m in moves):continue
        job=install.job if install else item.reserved_job
        # Do not reveal a repair assignment to warehouse-only viewers.
        if job and job.pk not in allowed_jobs:job=None
        receipt=receipts[0] if receipts else None
        result.append({'item':item,'movements':moves,'balances':balances,'quantity':sum(b.quantity for b in balances),'receipt':receipt,'receipt_warehouse':item.receipt_warehouse if item.receipt_warehouse_id in allowed_warehouses else (receipt.destination if receipt else None),'receipt_source':item.receipt_origin or (item.receipt_warehouse.name if item.receipt_warehouse_id in allowed_warehouses else (receipt.destination.name if receipt and receipt.destination else '')),'receipt_date':item.receipt_date if item.receipt_warehouse_id in allowed_warehouses else (receipt.date if receipt else None),'state':state,'label':{'installed':'Смонтирована','reserved':'Закреплена','free':'Свободна','catalogue':'Нет на складе'}[state],'job':job,'job_label':planning.job_label(job) if job else '', 'installed_date':install.report.performed_date if install else None,'serial':item.serial or (item.coupling.serial if item.coupling_id else '')})
    return result

def filtered_inventory(request):
    from .stock_groups import groups
    rows=groups(request.user,include_archived=request.GET.get('archive')=='1')
    q=request.GET.get('q','').strip().casefold();wh=request.GET.get('warehouse','');kind=request.GET.get('kind','');state=request.GET.get('state','')
    if q:rows=[r for r in rows if q in r['search']]
    if wh:rows=[r for r in rows if r['warehouse'] and str(r['warehouse'].pk)==wh]
    if kind:rows=[r for r in rows if r['item'].kind==kind]
    if state:rows=[r for r in rows if any(m['state']==state for m in r['members'])]
    return rows

@permission_required('stock.manage')
def inventory(request):
    from . import stock_inline
    if request.method=='POST':return stock_inline.save(request)
    page=Paginator(filtered_inventory(request),50).get_page(request.GET.get('page'))
    mode=request.GET.get('mode','')
    if mode not in ('edit','delete'):mode=''
    if mode:stock_inline.prepare(request.user,page,mode)
    query=request.GET.copy();query.pop('page',None);query.pop('mode',None)
    back=request.GET.copy();back.pop('mode',None)
    from django.urls import reverse
    return render(request,'projects/stock_inventory.html',{'rows':page,'page':page,'mode':mode,'operation':uuid.uuid4(),'return_url':reverse('stock_inventory')+('?' + back.urlencode() if back else ''),'filter_query':query.urlencode(),'warehouses':stock.warehouses(request.user).order_by('name'),'q':request.GET.get('q',''),'selected_warehouse':request.GET.get('warehouse',''),'selected_kind':request.GET.get('kind',''),'selected_state':request.GET.get('state',''),'kinds':StockItem._meta.get_field('kind').choices})

@permission_required('stock.manage')
def coverage(request):
    jobs=visible_jobs(request.user).exclude(state__in=['reported','confirmed','unrepairable']).exclude(contract__status='archived')
    from django.http import Http404
    try:
        if request.GET.get('contract'):
            from .scope_widgets import identifiers
            jobs=jobs.filter(contract_id__in=identifiers(request.GET,'contract'))
        if request.GET.get('object'):
            from .scope_widgets import identifiers
            jobs=jobs.filter(section__project_object_id__in=identifiers(request.GET,'object'))
    except ValueError:raise Http404
    from .repair_materials import all_demand
    from .demand_details import location,order
    allowed=set(jobs.values_list('pk',flat=True));grouped={};unknown=[]
    records=all_demand(request.user)
    from .stock_allocation import proposal
    stock_plan,stock_plan_token=proposal(request.user,records,allowed)
    for record in records:
        job=record['job']
        if job.pk not in allowed:continue
        for issue in record['coupling_issues']:
            unknown.append({'label':planning.job_label(job),'job':job,'section':job.section if not job.section.diameter_mm else None,'reason':issue})
        for line in record['couplings']:
            if not line['missing']:continue
            key=(job.section.project_object.name,job.section.name,str(job.section.project_object_id),str(job.section_id),line['method'],line['diameter'],line['length'],line['wall'])
            row=grouped.setdefault(key,{'scope_id':(str(job.section.project_object_id),str(job.section_id)),'object':job.section.project_object.name,'section':job.section.name,'method':dict(METHODS)[line['method']],'diameter':line['diameter'],'length':line['length'],'wall':line['wall'],'need':0,'reserved':0,'free':0,'missing':0,'placements':[]})
            row['need']+=line['need'];row['reserved']+=line['reserved'];row['missing']+=line['missing'];row['free']+=line['need']-line['reserved']-line['missing']
            row['placements'].append({**location(job),'job':job,'quantity':line['missing']})
    rows=[grouped[k] for k in sorted(grouped)]
    for row in rows:row['placements'].sort(key=order)
    if request.GET.get('export')=='xlsx':
        from django.http import HttpResponse
        from .report_excel import workbook
        sheets=[('Муфты',['Тип','Диаметр, мм','Длина, мм','Стенка, мм','Нужно, шт.','Объект','Участок'],[[dn_label(r[k]) if k=='diameter' else r[k] for k in ('method','diameter','length','wall','missing','object','section')] for r in rows]),
                ('По километрам',['Объект','Участок','Нефтепровод','км','№ дефектов','№ секций трубы','Тип','Диаметр','Длина, мм','Стенка, мм','Количество, шт.'],[[r['object'],r['section'],p['pipeline'],p['kilometres'],p['defect_numbers'],p['pipe_sections'],r['method'],dn_label(r['diameter']),r['length'],r['wall'],p['quantity']] for r in rows for p in r['placements']]),
                ('Нужно уточнить',['Работы','Причина'],[[r['label'],r['reason']] for r in unknown])]
        response=HttpResponse(workbook(sheets),content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');response['Content-Disposition']='attachment; filename="coupling-coverage.xlsx"';response['Cache-Control']='private, no-store';return response
    query=request.GET.copy();query['export']='xlsx'
    return render(request,'projects/stock_coverage.html',{'rows':rows,'unknown':unknown,'stock_plan':stock_plan,'stock_plan_token':stock_plan_token,'scoped':bool(request.GET.get('contract') or request.GET.get('object')),'export_query':query.urlencode()})



class DiameterForm(forms.Form):
    expected_diameter=forms.IntegerField(widget=forms.HiddenInput,min_value=0)
    diameter_mm=DiameterField()
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        preserve_legacy(self.fields['diameter_mm'],self.initial.get('diameter_mm'))

@permission_required('stock.manage')
def diameter(request,pk):
    from repairs.access import can_prepare, visible_sections
    from django.core.exceptions import PermissionDenied
    from django.db import transaction
    from accounts.views import audit
    if not can_prepare(request.user):raise PermissionDenied
    section=get_object_or_404(visible_sections(request.user),pk=pk)
    form=DiameterForm(request.POST or None,initial={'expected_diameter':section.diameter_mm or 0,'diameter_mm':section.diameter_mm});status=200
    if request.method=='POST' and form.is_valid():
        try:
            with transaction.atomic():
                actor=stock.manager(request.user);stock.lock()
                if not can_prepare(actor):raise PermissionDenied
                fresh=visible_sections(actor).select_for_update(of=('self',)).get(pk=pk)
                if fresh.project_object.status=='archived' or fresh.jobs.filter(contract__status='archived').exists():raise ValidationError('Участок или связанный контракт находится в архиве. Сначала восстановите его.')
                if (fresh.diameter_mm or 0)!=form.cleaned_data['expected_diameter']:raise ValidationError('Диаметр изменён другим пользователем. Откройте форму заново.')
                before=fresh.diameter_mm;fresh.diameter_mm=form.cleaned_data['diameter_mm'];fresh.full_clean();fresh.save(update_fields=['diameter_mm'])
                audit(actor,'stock_pipeline_diameter_updated',section=str(pk),previous=before,value=fresh.diameter_mm)
        except ValidationError as e:form.add_error(None,'; '.join(e.messages));status=409
        else:return redirect('stock_coverage')
    return render(request,'projects/stock_form.html',{'form':form,'title':'Уточнить диаметр: '+section.pipeline+' · '+section.project_object.name},status=status)


@permission_required('stock.manage')
def approve_allocation(request):
    if request.method!='POST':
        from django.http import HttpResponse
        return HttpResponse(status=405)
    from .stock_allocation import apply
    try:count=apply(request.user,request.POST.get('proposal',''))
    except ValidationError as exc:messages.error(request,'; '.join(exc.messages))
    else:messages.success(request,f'Комплекты закреплены за работами: {count}. Наличие и прежние закрепления сохранены.')
    return redirect('stock_coverage')
