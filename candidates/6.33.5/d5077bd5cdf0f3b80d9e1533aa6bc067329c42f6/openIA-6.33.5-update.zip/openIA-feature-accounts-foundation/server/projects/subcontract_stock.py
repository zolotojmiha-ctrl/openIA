"""Warehouses bound to a company and contract, with shared cabinet and MAX authorization."""
from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Q

from accounts.models import User
from accounts.views import audit
from . import stock
from .models import StockItem, StockMovement, SubcontractContract, Warehouse
from .subcontract_scope import job_filter, managed, registry_memberships


def assignments(user):
    if not managed(user):
        return SubcontractContract.objects.none()
    return SubcontractContract.objects.filter(
        pk__in=registry_memberships(user).values('assignment_id'),
    ).select_related('company','contract')


def warehouses(user):
    rows = Warehouse.objects.filter(subcontract_assignment__isnull=False).select_related(
        'subcontract_assignment__company','subcontract_assignment__contract',
    )
    if user.is_active and user.is_leader:
        return rows
    return rows.filter(subcontract_assignment__in=assignments(user))


def history(warehouse):
    scope = warehouse.subcontract_assignment_id
    return StockMovement.objects.filter(Q(source=warehouse) | Q(destination=warehouse),item__subcontract_assignment_id=scope).filter(
        Q(source__isnull=True) | Q(source__subcontract_assignment_id=scope),
        Q(destination__isnull=True) | Q(destination__subcontract_assignment_id=scope),
    ).select_related('item','source','destination').order_by('-created_at','-pk')


def balances(warehouse):
    return warehouse.balances.select_related('item__reserved_job').filter(
        quantity__gt=0,item__subcontract_assignment_id=warehouse.subcontract_assignment_id,
    ).order_by('item__name','pk')


def editable_warehouses(user):
    return warehouses(user).filter(archived=False,subcontract_assignment__in=assignments(user))


def assignment_for_job(job):
    if not job.contract_id:
        return None
    rows = SubcontractContract.objects.filter(contract_id=job.contract_id)
    if job.subcontract_order_id:
        return rows.filter(company_id=job.subcontract_order.company_id).values_list('pk',flat=True).first()
    ids = list(rows.values_list('pk',flat=True)[:2])
    return ids[0] if len(ids)==1 else None


def transfer_destinations(user,source):
    return editable_warehouses(user).filter(
        subcontract_assignment_id=source.subcontract_assignment_id,legal_entity_id=source.legal_entity_id,
    ).exclude(pk=source.pk).order_by('name','pk')


def transfer_items(source,include_empty=False):
    rows = StockItem.objects.filter(
        legal_entity_id=source.legal_entity_id,subcontract_assignment_id=source.subcontract_assignment_id,
        archived=False,deleted_at__isnull=True,reserved_job__isnull=True,balances__warehouse=source,
    )
    if not include_empty:
        rows = rows.filter(pk__in=balances(source).values('item_id'))
    return rows.order_by('name','sku','pk')


def lock_writer(user):
    actor = User.objects.select_for_update(no_key=True).get(pk=user.pk)
    if actor.session_version != user.session_version:
        raise PermissionDenied
    return actor, stock.lock()


@transaction.atomic
def transfer(user,source_id,data):
    from .archive import writable
    actor, company = lock_writer(user)
    destination_id = data['destination'].pk
    if source_id==destination_id:
        raise ValidationError('Выберите другой склад для перемещения.')
    rows = {wh.pk:wh for wh in editable_warehouses(actor).select_for_update(of=('self',)).filter(
        pk__in=[source_id,destination_id],legal_entity=company,
    ).order_by('pk')}
    source = rows.get(source_id)
    destination = rows.get(destination_id)
    if not source or not destination or source.subcontract_assignment_id!=destination.subcontract_assignment_id:
        raise PermissionDenied
    writable([source.subcontract_assignment.contract_id])
    if not assignments(actor).filter(pk=source.subcontract_assignment_id).exists():
        raise PermissionDenied
    item = transfer_items(source,include_empty=True).filter(pk=data['item'].pk).first()
    if not item:
        raise PermissionDenied
    quantity = stock.quantity(data['quantity'],item)
    return stock.post_locked(actor,item,'transfer',quantity,source,destination,data['date'],data['note'],data['token'],
                             subcontract_operation=True)


@transaction.atomic
def receive(user,warehouse_id,data):
    from .stock_planning import receive_locked

    actor, company = lock_writer(user)
    wh = warehouses(actor).select_for_update(of=('self',)).filter(
        pk=warehouse_id,subcontract_assignment__in=assignments(actor),legal_entity=company,
    ).first()
    if wh is None:
        raise PermissionDenied
    from .archive import writable
    writable([wh.subcontract_assignment.contract_id])
    if not assignments(actor).filter(pk=wh.subcontract_assignment_id).exists():
        raise PermissionDenied
    values = dict(data,receipt_origin='Заказчик',catalogue_item=None)
    if values['kind']=='coupling' and not values.get('diameter_mm'):
        raise ValidationError('Выберите номинальный диаметр муфты.')
    return receive_locked(actor,values,wh,values['quantity'],values['date'],values['note'],values['token'])


@transaction.atomic
def create_warehouse(user, assignment_id, name, location=''):
    actor = User.objects.select_for_update(no_key=True).get(pk=user.pk)
    if actor.session_version != user.session_version:
        raise PermissionDenied
    company = stock.lock()
    scope = assignments(actor).select_for_update(of=('self',)).filter(pk=assignment_id).first()
    if scope is None or scope.company.legal_entity_id != company.pk:
        raise PermissionDenied
    if not assignments(actor).filter(pk=scope.pk).exists():
        raise PermissionDenied
    name = name.strip()
    if Warehouse.objects.filter(subcontract_assignment=scope,name=name).exists():
        raise ValidationError('На этом контракте уже есть склад с таким названием.')
    row = Warehouse(legal_entity=company,subcontract_assignment=scope,created_by=actor,
                    name=name,location=location.strip())
    row.full_clean()
    row.save()
    audit(actor,'stock_updated',kind='subcontract_warehouse',id=str(row.pk),assignment=scope.pk,name=row.name)
    return row


def reservable_pieces(warehouse):
    return StockItem.objects.filter(
        legal_entity_id=warehouse.legal_entity_id,subcontract_assignment_id=warehouse.subcontract_assignment_id,
        kind='coupling',individual=True,archived=False,deleted_at__isnull=True,
        balances__warehouse=warehouse,balances__quantity=1,coupling__installation__isnull=True,
    ).order_by('name','sku','pk')


def reservation_jobs(user,warehouse,item=None,include_archived=False):
    from repairs.access import visible_jobs
    rows = visible_jobs(user,include_archived=include_archived).filter(
        contract_id=warehouse.subcontract_assignment.contract_id,
        section__project_object__status__in=['planned','active','completed'],
    ).filter(job_filter(user,role='coordinator',assignment=warehouse.subcontract_assignment_id))
    if include_archived:
        return rows
    rows = rows.filter(state__in=['planned','progress','partial'])
    if item is not None:
        from .stock_fit import OVERSIZE
        rows = rows.filter(method=item.method,section__diameter_mm=item.diameter_mm,wall_mm__gt=0)
        rows = rows.filter(wall_mm__lte=item.wall_mm) if item.method in OVERSIZE else rows.filter(wall_mm=item.wall_mm)
    return rows.order_by('section__project_object__name','pk')


@transaction.atomic
def reserve(user,warehouse_id,item_id,version,job_id):
    from .archive import writable
    from .stock_planning import validate_reservation_fit

    actor, company = lock_writer(user)
    wh = editable_warehouses(actor).select_for_update(of=('self',)).filter(pk=warehouse_id,legal_entity=company).first()
    if not wh:
        raise PermissionDenied
    writable([wh.subcontract_assignment.contract_id])
    item = reservable_pieces(wh).select_for_update(of=('self',)).filter(pk=item_id).first()
    if not item:
        raise PermissionDenied
    allowed = reservation_jobs(actor,wh,include_archived=True)
    if item.reserved_job_id and not allowed.filter(pk=item.reserved_job_id).exists():
        raise PermissionDenied
    if item.version!=version:
        raise ValidationError('Закрепление изменилось. Откройте карточку муфты заново.')
    if item.reserved_job_id==job_id:
        return item
    if job_id is not None:
        if item.reserved_job_id:
            raise ValidationError('Сначала снимите прежнее закрепление муфты.')
        job = reservation_jobs(actor,wh,item).select_for_update(of=('self',)).filter(pk=job_id).first()
        if job is None:
            raise ValidationError('Работа недоступна или параметры муфты не соответствуют плану ремонта.')
        if not reservation_jobs(actor,wh,item).filter(pk=job_id).exists():
            raise PermissionDenied
        validate_reservation_fit(item,job)
    else:
        if not allowed.select_for_update(of=('self',)).filter(pk=item.reserved_job_id).first():
            raise PermissionDenied
    return set_reservation(actor,wh,item,job_id)


def set_reservation(actor,warehouse,item,job_id):
    before = item.reserved_job_id
    item.reserved_job_id = job_id
    item.reservation_origin = 'manual' if job_id is not None else ''
    item.version += 1
    item.save(update_fields=['reserved_job','reservation_origin','version'])
    audit(actor,'stock_reserved',item=str(item.pk),job=str(job_id or ''),previous_job=str(before or ''),
          warehouse=str(warehouse.pk),assignment=warehouse.subcontract_assignment_id)
    return item
