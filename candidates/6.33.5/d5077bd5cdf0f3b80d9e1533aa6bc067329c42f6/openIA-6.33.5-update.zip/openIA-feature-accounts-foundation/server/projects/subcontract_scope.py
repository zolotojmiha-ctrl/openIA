"""Contract grants for the new subcontract team. Legacy orders retain their original access rules."""
from django.db.models import Exists, OuterRef, Q
from .models import SubcontractContract, SubcontractContractStaff


def managed(user):
    if not user.is_authenticated or user.is_leader or user.role != 'subcontractor':
        return False
    # Keep the restricted account boundary after revocation.
    return user.subcontract_contract_team.exists()


def memberships(user):
    return SubcontractContractStaff.objects.filter(
        user=user, user__is_active=True, user__role='subcontractor',
        active=True, assignment__company__archived=False,
    ).exclude(assignment__contract__status='archived')


def contract_ids(user):
    return memberships(user).values('assignment__contract_id')


def area_filter(user):
    rows = memberships(user).filter(assignment__contract__objects_linked=OuterRef('pk'))
    return Exists(rows.filter(Q(areas__isnull=True) | Q(areas=OuterRef('pk'))))


def job_filter(user, role=None, assignment=None):
    rows = memberships(user).filter(
        assignment__contract_id=OuterRef('contract_id'),
        assignment__contract__objects_linked=OuterRef('section__project_object_id'),
    ).filter(Q(areas__isnull=True) | Q(areas=OuterRef('section__project_object_id')))
    if role:
        rows = rows.filter(role=role)
    if assignment is not None:
        rows = rows.filter(assignment_id=assignment)
    own_order = rows.filter(assignment__company_id=OuterRef('subcontract_order__company_id'))
    # An archived company still counts when deciding ownership of unallocated
    # work, so replacing a company does not expose its former register.
    other_company = SubcontractContract.objects.filter(
        contract_id=OuterRef('assignment__contract_id'),
    ).exclude(company_id=OuterRef('assignment__company_id'))
    sole_company = rows.filter(~Exists(other_company))
    return Q(subcontract_order__isnull=False, subcontract_order__archived=False) & Q(Exists(own_order)) | Q(subcontract_order__isnull=True) & Q(Exists(sole_company))


def registry_memberships(user):
    return memberships(user).filter(role='coordinator')


def can_report(user):
    return managed(user) and memberships(user).filter(role='foreman').exists()


def registry_area_membership(user, contract_id, area_id):
    return registry_memberships(user).filter(
        assignment__contract_id=contract_id,
        assignment__contract__objects_linked=area_id,
    ).filter(Q(areas__isnull=True) | Q(areas=area_id))


def sole_registry_assignment(user, contract_id, area_id):
    assignments = list(SubcontractContract.objects.filter(
        contract_id=contract_id,
    ).values_list('pk', flat=True)[:2])
    if len(assignments) == 1 and registry_area_membership(
        user, contract_id, area_id,
    ).filter(assignment_id=assignments[0]).exists():
        return assignments[0]
    return None


def registry_places(user):
    from .models import ContractObject

    rows = registry_memberships(user).filter(assignment__contract_id=OuterRef('contract_id'))
    rows = rows.filter(Q(areas__isnull=True) | Q(areas=OuterRef('project_object_id')))
    return ContractObject.objects.filter(Exists(rows),project_object__status__in=['planned','active','completed'])
