"""Physical receipts and explicit reservations, serialized with the stock ledger."""
import re, uuid
from decimal import Decimal, InvalidOperation
from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone
from accounts.views import audit
from repairs.models import Coupling, CouplingUse, METHODS
from repairs.access import visible_jobs
from .models import StockItem, StockBalance, Contract
from . import stock, stock_fit as fit


def job_label(job):
    return f'{job.contract.number if job.contract else "Без контракта"} · {job.section.project_object.name} · {job.section.pipeline} · '+', '.join('км '+d.km+' № '+d.number for d in job.active_defects)


@transaction.atomic
def receive(user, data, warehouse, count, date, note, token):
    actor=stock.manager(user);stock.lock()
    wh=stock.warehouses(actor).get(pk=warehouse.pk)
    return receive_locked(actor,data,wh,count,date,note,token)


def receive_locked(actor,data,wh,count,date,note,token):
    # A receipt token is also the stable key for all pieces in a bulk delivery.
    from .models import StockMovement
    q=Decimal(count)
    if not q.is_finite() or q<=0:raise ValidationError('Количество должно быть положительным.')
    if data['kind']=='coupling' and (q!=q.to_integral_value() or q>500):raise ValidationError('За одно поступление — от 1 до 500 отдельных муфт.')
    existing=StockMovement.objects.filter(token=token).first()
    if existing:
        expected_count=int(count) if data['kind']=='coupling' else 1
        if (existing.created_by_id!=actor.pk or existing.kind!='receipt' or existing.destination_id!=wh.pk or existing.date!=date or existing.note!=note
            or existing.item.subcontract_assignment_id!=wh.subcontract_assignment_id
            or existing.item.kind!=data['kind'] or existing.item.method!=(data.get('method') or '')
            or existing.item.length_mm!=data.get('length_mm') or existing.item.wall_mm!=data.get('wall_mm')
            or existing.item.diameter_mm!=data.get('diameter_mm') or existing.item.unit!=data['unit']
            or existing.item.name!=(data.get('name') or ('Муфта '+dict(METHODS).get(data.get('method'),'') if data['kind']=='coupling' else ''))
            or existing.item.electrode_brand!=(data.get('electrode_brand') or '') or existing.item.electrode_diameter!=data.get('electrode_diameter')
            or existing.item.receipt_origin!=(data.get('receipt_origin') or '').strip()
            or existing.item.serial!=(data.get('serial') or '') or existing.quantity!=(1 if data['kind']=='coupling' else count)
            or (expected_count>1 and not StockMovement.objects.filter(token=uuid.uuid5(token,str(expected_count-1))).exists())
            or StockMovement.objects.filter(token=uuid.uuid5(token,str(expected_count))).exists()):
            raise ValidationError('Этот запрос поступления уже сохранён с другими данными.')
        return existing.destination
    if wh.archived:raise ValidationError('Склад в архиве.')
    if data['kind']=='coupling' and q>1 and data.get('serial'):raise ValidationError('Заводской номер укажите при поступлении одной муфты или заполните номера позже поштучно.')
    # A delivery records where material physically arrived, independently of
    # when a crew worked there. Keep legacy holder identity and ledger intact;
    # crew-date validation belongs to issuing material, not receiving it.
    n=int(q) if data['kind']=='coupling' else 1
    for index in range(n):
        values=dict(data);values['coupling']=None;values['sku']='ПР-'+str(uuid.uuid4())[:12];values['archived']=False
        values['name']=values.get('name') or ('Муфта '+dict(METHODS).get(values.get('method'),'') if data['kind']=='coupling' else '')
        catalogue=data.get('catalogue_item') if index==0 else None
        if catalogue and not wh.subcontract_assignment_id:
            original=stock.items(actor).get(pk=catalogue.pk)
            if original.version!=data.get('catalogue_version') or original.movements.exists() or original.coupling_id:raise ValidationError('Карточка уже использована или изменена. Откройте поступление заново.')
            values['sku']=original.sku
        else:
            original=StockItem(legal_entity_id=wh.legal_entity_id,subcontract_assignment_id=wh.subcontract_assignment_id,created_by=actor)
        item=stock.save_item_locked(actor,original,original.version,values)
        item.receipt_warehouse=wh;item.receipt_date=date
        if item.kind=='coupling':item.individual=True
        item.save(update_fields=['individual','receipt_warehouse','receipt_date'])
        amount=Decimal(1) if item.individual else q
        stock.quantity(amount,item)
        stock.post_locked(actor,item,'receipt',amount,None,wh,date,note,token if index==0 else uuid.uuid5(token,str(index)),
                          subcontract_operation=bool(wh.subcontract_assignment_id))
    return wh


def validate_reservation_fit(item,job):
    incompatibility=fit.reason(item,job)
    if incompatibility:raise ValidationError(incompatibility)
    lengths=requirements(job)
    if lengths is None:raise ValidationError(requirements_issue(job))
    if not any(fit.length_fits(job.method,item.length_mm,length) for length in lengths):raise ValidationError('Длина муфты не соответствует требуемой длине конструкции.')
    held,installed=fit.occupied(job,exclude=[item.pk])
    if job.method=='p1' and sum(p.length_mm for p in held+installed)+item.length_mm>10500:raise ValidationError('Суммарная длина П1 не должна превышать 10,5 м.')
    if job.method=='p1' and any(p.wall_mm!=item.wall_mm for p in held+installed):raise ValidationError('Все секции составной П1 должны иметь одинаковую толщину стенки.')
    if not fit.capacity(job,item,held,installed):raise ValidationError('Для этой конструкции уже закреплено нужное количество муфт.')


@transaction.atomic
def reserve(user, item_id, version, job_id):
    actor=stock.manager(user);stock.lock()
    item=stock.items(actor).get(pk=item_id)
    if item.version!=version:raise ValidationError('Карточка изменена. Обновите страницу.')
    if item.kind!='coupling' or item.archived:raise ValidationError('Выберите действующую муфту.')
    if item.reserved_job_id and not visible_jobs(actor,include_archived=True).filter(pk=item.reserved_job_id).exists():
        from django.core.exceptions import PermissionDenied
        raise PermissionDenied('Нет доступа к текущему назначению муфты.')
    if item.coupling_id and CouplingUse.objects.filter(coupling_id=item.coupling_id).exists():raise ValidationError('Муфта уже смонтирована.')
    if job_id:
        candidate=visible_jobs(actor).get(pk=job_id)
        if candidate.contract_id:
            parent=Contract.objects.select_for_update(no_key=True).get(pk=candidate.contract_id)
            if parent.status=='archived':raise ValidationError('Контракт находится в архиве.')
        job=visible_jobs(actor).select_for_update(of=('self',)).get(pk=job_id)
        if job.state in ('reported','confirmed','unrepairable') or job.contract and job.contract.status=='archived' or job.section.project_object.status=='archived':raise ValidationError('Работа уже выполнена или закрыта.')
        if item.reserved_job_id and item.reserved_job_id!=job.pk:raise ValidationError('Муфта уже закреплена. Сначала снимите назначение.')
        validate_reservation_fit(item,job)
        if item.deleted_at:raise ValidationError('Позиция удалена.')
        balances=list(item.balances.filter(quantity__gt=0).select_related('warehouse'))
        if not balances or not item.individual and (len(balances)!=1 or balances[0].quantity!=1):
            raise ValidationError('Это старая групповая позиция. Откройте её остаток и выделите отдельную муфту кнопкой «Выделить 1 муфту».')
        area=job.section.project_object
        if any(b.warehouse.brigade_assignment_id and b.warehouse.project_object_id!=area.pk for b in balances):raise ValidationError('Муфта у бригады другого участка. Сначала оформите перемещение.')
        if not item.coupling_id:
            coupling=Coupling(project_object=area,method=item.method,length_mm=item.length_mm,wall_mm=item.wall_mm,serial=item.serial,warehouse=balances[0].warehouse.name,source={'stock_created':True});coupling.full_clean();coupling.save();item.coupling=coupling
        elif item.coupling.project_object_id!=area.pk:
            item.coupling.project_object=area;item.coupling.full_clean();item.coupling.save(update_fields=['project_object'])
        item.individual=True;item.reserved_job=job;item.reservation_origin='manual'
    else:item.reserved_job=None;item.reservation_origin=''
    item.version+=1;item.save()
    audit(actor,'stock_reserved',item=str(item.pk),job=str(item.reserved_job_id or ''))
    return item


@transaction.atomic
def split(user,item_id,version,warehouse_id):
    actor=stock.manager(user);stock.lock();item=stock.items(actor).get(pk=item_id)
    if item.version!=version:raise ValidationError('Позиция изменена.')
    if item.kind!='coupling' or item.individual or item.coupling_id:raise ValidationError('Это уже отдельная муфта.')
    wh=stock.warehouses(actor).get(pk=warehouse_id)
    if not item.balances.filter(warehouse=wh,quantity__gte=1).exists():raise ValidationError('Муфты на этом складе нет.')
    values={k:getattr(item,k) for k in stock.ITEM_FIELDS};values.update(sku='ЕД-'+str(uuid.uuid4())[:12],coupling=None,archived=False)
    piece=stock.save_item(actor,None,None,values);piece.individual=True
    original=item.movements.filter(kind='receipt').order_by('created_at','pk').first()
    piece.receipt_origin=item.receipt_origin
    piece.receipt_warehouse=item.receipt_warehouse or (original.destination if original else None);piece.receipt_date=item.receipt_date or (original.date if original else None)
    piece.save(update_fields=['individual','receipt_warehouse','receipt_date','receipt_origin'])
    note='Выделение отдельной муфты из позиции '+str(item.pk)+' в '+str(piece.pk)
    stock.post_locked(actor,item,'loss',Decimal(1),wh,None,timezone.localdate(),note,uuid.uuid4(),automatic=True)
    stock.post_locked(actor,piece,'receipt',Decimal(1),None,wh,timezone.localdate(),note,uuid.uuid4(),automatic=True)
    item.version+=1;item.save(update_fields=['version'])
    audit(actor,'stock_piece_split',item=str(item.pk),piece=str(piece.pk),warehouse=str(wh.pk))
    return piece


def delete_snapshot(user,item,warehouse_id=None):
    from django.core import signing
    state=[str(item.pk),item.version,str(warehouse_id or ''),sorted((str(b.warehouse_id),str(b.quantity)) for b in item.balances.all()),str(item.movements.order_by('-created_at','-pk').values_list('pk',flat=True).first() or '')]
    return signing.dumps({'actor':str(user.pk),'state':state},salt='stock-delete-v620')

@transaction.atomic
def delete(user,item_id,version,note,warehouse_id=None,all_warehouses=False,snapshot=None):
    actor=stock.manager(user);stock.lock();item=stock.items(actor).get(pk=item_id)
    if item.version!=version:raise ValidationError('Позиция изменена. Обновите страницу.')
    if snapshot and snapshot!=delete_snapshot(actor,item,warehouse_id):
        from django.core import signing
        try:
            a=signing.loads(snapshot,salt='stock-delete-v620');b=signing.loads(delete_snapshot(actor,item,warehouse_id),salt='stock-delete-v620')
            if a!=b:raise ValueError
        except (signing.BadSignature,ValueError):raise ValidationError('Остатки изменились после открытия подтверждения. Откройте его заново.')
    if not note.strip():raise ValidationError('Укажите причину удаления.')
    if item.reserved_job_id:raise ValidationError('Сначала снимите закрепление за работой.')
    if item.coupling_id and CouplingUse.objects.filter(coupling_id=item.coupling_id).exists():raise ValidationError('Муфта смонтирована. Исправьте результат ремонта перед удалением.')
    balances=list(item.balances.filter(quantity__gt=0).select_related('warehouse'))
    if warehouse_id:
        if not stock.warehouses(actor).filter(pk=warehouse_id).exists():raise ValidationError('Склад недоступен.')
        balances=[b for b in balances if b.warehouse_id==warehouse_id]
        if not balances:raise ValidationError('На выбранном складе этой позиции уже нет.')
    elif len(balances)>1 and not all_warehouses:raise ValidationError('Укажите склад или явно подтвердите удаление со всех складов.')
    for balance in balances:
        if not stock.warehouses(actor).filter(pk=balance.warehouse_id).exists():raise ValidationError('Склад недоступен.')
        stock.post_locked(actor,item,'loss',balance.quantity,balance.warehouse,None,timezone.localdate(),'Удаление ошибочной позиции: '+note,uuid.uuid4(),automatic=True)
    if not item.balances.filter(quantity__gt=0).exists():item.deleted_at=timezone.now();item.archived=True
    item.version+=1;item.save(update_fields=['deleted_at','archived','version'])
    audit(actor,'stock_item_deleted',item=str(item.pk),note=note,balances_removed=[str(b.quantity) for b in balances])


def requirements(job):
    from repairs.construction import planned_parts,demand_parts,COUPLING_METHODS
    if job.method not in COUPLING_METHODS:return []
    try:return [int(part*1000) for part in (demand_parts if job.method=='p1' and not job.composition else planned_parts)(job.length_m,job.composition,job.method)[1]]
    except ValidationError:return None


def requirements_issue(job):
    from repairs.construction import planned_parts,demand_parts,COUPLING_METHODS
    if job.method not in COUPLING_METHODS:return ''
    try:planned_parts(job.length_m,job.composition,job.method)
    except ValidationError as exc:return exc.messages[0]
    return ''


@transaction.atomic
def bind_issued(user,item_id,warehouse_id,job_id,count):
    actor=stock.manager(user);stock.lock()
    for _ in range(count):
        item=stock.items(actor).get(pk=item_id)
        positive=list(item.balances.filter(quantity__gt=0))
        if len(positive)!=1 or positive[0].quantity!=1:item=split(actor,item.pk,item.version,warehouse_id)
        item=reserve(actor,item.pk,item.version,job_id);item.reservation_origin='issue';item.save(update_fields=['reservation_origin'])
