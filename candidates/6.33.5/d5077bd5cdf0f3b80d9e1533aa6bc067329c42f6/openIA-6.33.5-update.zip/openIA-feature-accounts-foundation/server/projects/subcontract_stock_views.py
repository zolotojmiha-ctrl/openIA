from uuid import uuid4

from django import forms
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from repairs.access import visible_jobs
from repairs.models import Job
from . import subcontract_stock as stock
from .models import StockItem, SubcontractContract, Warehouse
from .stock_planning import job_label


class WarehouseForm(forms.Form):
    assignment = forms.ModelChoiceField(label='Контракт',queryset=SubcontractContract.objects.none())
    name = forms.CharField(label='Название склада',max_length=160)
    location = forms.CharField(label='Адрес или место хранения',max_length=250,required=False)

    def __init__(self,*args,user,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['assignment'].queryset = stock.assignments(user).order_by('contract__number')
        self.fields['assignment'].label_from_instance = lambda scope: str(scope.contract)


class TransferForm(forms.Form):
    item = forms.ModelChoiceField(label='Материал или изделие',queryset=StockItem.objects.none())
    destination = forms.ModelChoiceField(label='Склад назначения',queryset=Warehouse.objects.none())
    quantity = forms.DecimalField(label='Количество',max_digits=18,decimal_places=3,initial=1)
    date = forms.DateField(label='Дата перемещения',initial=timezone.localdate,widget=forms.DateInput(attrs={'type':'date'}))
    note = forms.CharField(label='Основание перемещения',max_length=1500,widget=forms.Textarea(attrs={'rows':3}))
    token = forms.UUIDField(initial=uuid4,widget=forms.HiddenInput)

    def __init__(self,*args,user,source,**kwargs):
        super().__init__(*args,**kwargs)
        self.fields['item'].queryset = stock.transfer_items(source,include_empty=self.is_bound)
        self.fields['destination'].queryset = stock.transfer_destinations(user,source)


class ReservationForm(forms.Form):
    expected_version = forms.IntegerField(widget=forms.HiddenInput)
    job = forms.ModelChoiceField(label='Работа / дефекты',queryset=Job.objects.none())

    def __init__(self,*args,user,warehouse,item,**kwargs):
        super().__init__(*args,**kwargs)
        self.initial['expected_version'] = item.version
        if item.reserved_job_id:
            self.fields.pop('job')
        else:
            self.fields['job'].queryset = stock.reservation_jobs(user,warehouse,item)
            self.fields['job'].label_from_instance = job_label


@login_required
def transfer(request,pk):
    wh = get_object_or_404(stock.editable_warehouses(request.user),pk=pk)
    form = TransferForm(request.POST if request.method=='POST' else None,user=request.user,source=wh)
    if request.method=='POST' and form.is_valid():
        try:
            stock.transfer(request.user,wh.pk,form.cleaned_data)
        except ValidationError as error:
            form.add_error(None,error)
        else:
            messages.success(request,'Перемещение сохранено. Остатки обоих складов обновлены.')
            return redirect('stock_subcontract_detail',pk=wh.pk)
    return render(request,'projects/subcontract_stock_transfer.html',{'form':form,'warehouse':wh})


@login_required
def index(request):
    scopes = stock.assignments(request.user)
    if not request.user.is_leader and not scopes.exists():
        raise PermissionDenied
    rows = stock.warehouses(request.user).filter(archived=False).order_by(
        'subcontract_assignment__company__name','subcontract_assignment__company_id',
        'subcontract_assignment__contract__number','subcontract_assignment_id','name',
    )
    return render(request,'projects/subcontract_stock.html',{'warehouses':rows,'can_add':scopes.exists()})


@login_required
def detail(request,pk):
    wh = get_object_or_404(stock.warehouses(request.user),pk=pk)
    can_edit = stock.editable_warehouses(request.user).filter(pk=wh.pk).exists()
    page = Paginator(stock.balances(wh),30).get_page(request.GET.get('items'))
    job_ids = {row.item.reserved_job_id for row in page if row.item.reserved_job_id}
    visible = (visible_jobs(request.user,include_archived=True).filter(contract_id=wh.subcontract_assignment.contract_id)
               if request.user.is_leader else stock.reservation_jobs(request.user,wh,include_archived=True))
    labels = {job.pk:job_label(job) for job in visible.filter(pk__in=job_ids)}
    pieces = set(stock.reservable_pieces(wh).filter(pk__in=[row.item_id for row in page]).values_list('pk',flat=True)) if can_edit else set()
    for row in page:
        row.reservation_label = labels.get(row.item.reserved_job_id)
        row.can_reserve = row.item_id in pieces and (not row.item.reserved_job_id or row.item.reserved_job_id in labels)
    return render(request,'projects/subcontract_stock.html',{
        'warehouse':wh,'balances':page,
        'history':Paginator(stock.history(wh),30).get_page(request.GET.get('page')),
        'can_receive':can_edit,
        'can_transfer':can_edit and stock.transfer_destinations(request.user,wh).exists() and stock.transfer_items(wh).exists(),
    })


@login_required
def reserve(request,pk,item_id):
    wh = get_object_or_404(stock.editable_warehouses(request.user),pk=pk)
    item = get_object_or_404(stock.reservable_pieces(wh),pk=item_id)
    reserved_job = None
    if item.reserved_job_id:
        reserved_job = get_object_or_404(stock.reservation_jobs(request.user,wh,include_archived=True),pk=item.reserved_job_id)
    form = ReservationForm(request.POST if request.method=='POST' else None,user=request.user,warehouse=wh,item=item)
    if request.method=='POST' and form.is_valid():
        proposed = form.cleaned_data.get('job')
        try:
            stock.reserve(request.user,wh.pk,item.pk,form.cleaned_data['expected_version'],proposed.pk if proposed else None)
        except ValidationError as error:
            form.add_error(None,error)
        else:
            message = 'Муфта закреплена за работой.' if proposed else 'Закрепление снято. Муфта снова свободна.'
            messages.success(request,message)
            return redirect('stock_subcontract_detail',pk=wh.pk)
    return render(request,'projects/subcontract_stock_reserve.html',{
        'warehouse':wh,'item':item,'form':form,'reserved_label':job_label(reserved_job) if reserved_job else '',
    })


@login_required
def receipt(request,pk):
    from .stock_planning_views import ReceiptForm

    wh = get_object_or_404(stock.editable_warehouses(request.user),pk=pk)
    form = ReceiptForm(request.POST if request.method=='POST' else None,user=request.user,subcontract_warehouse=wh)
    if request.method=='POST' and form.is_valid():
        try:
            stock.receive(request.user,wh.pk,form.cleaned_data)
        except ValidationError as error:
            form.add_error(None,error)
        else:
            messages.success(request,'Поступление сохранено. Остатки обновлены.')
            return redirect('stock_subcontract_detail',pk=wh.pk)
    return render(request,'projects/subcontract_stock_receipt.html',{'form':form,'warehouse':wh})


@login_required
def create(request):
    scopes = stock.assignments(request.user)
    if not scopes.exists():
        raise PermissionDenied
    scope = scopes.first() if scopes.count()==1 else None
    form = WarehouseForm(request.POST if request.method=='POST' else None,user=request.user,initial={'assignment':scope})
    if request.method=='POST' and form.is_valid():
        data = form.cleaned_data
        try:
            wh = stock.create_warehouse(request.user,data['assignment'].pk,data['name'],data['location'])
        except ValidationError as error:
            form.add_error(None,error.messages)
        else:
            return redirect('stock_subcontract_detail',pk=wh.pk)
    return render(request,'projects/subcontract_stock.html',{'form':form})
