> Подпись получена, выпуск опубликован. [Команды установки](INSTALL_6_33_6.md).

# Подпись 6.33.6 владельцем

Кандидат прошёл переход с 6.33.5 и проверку восстановления на отдельном облачном стенде. Из 92 профильных тестов прошли 91, один пропущен по условиям сценария PostgreSQL. Перед установкой нужна подпись прежним ключом. Команда в обычном терминале Mac скачивает кандидат и помощник из GitHub с проверкой контрольных сумм.

```bash
bash <<'SIGN'
set -euo pipefail
if [[ "$(uname -s)" != Darwin || "$EUID" -eq 0 ]]; then
  echo 'Запустите в обычном терминале Mac.' >&2
  exit 1
fi
umask 077
mkdir -p "$HOME/Downloads"
work=$(mktemp -d "$HOME/Downloads/armada-6.33.6-sign.XXXXXX")
url='https://api.github.com/repos/zolotojmiha-ctrl/openIA/contents/candidates/6.33.6/6c2c3bee0e62c61e3a762a148a07d6310c06ce25'
ref='3356bd09fa6a03e6d9917faa3d16de7f30338a6d'
for name in openIA-6.33.6-update.zip install-6.33.6.sh openIA-6.33.6-update.json signing-helper-6.33.6.zip; do
  curl --http1.1 --tlsv1.2 --tls-max 1.2 -fsSL --retry 2 \
    -H 'Accept: application/vnd.github.raw+json' \
    --output "$work/$name" "$url/$name?ref=$ref"
done
(cd "$work" && shasum -a 256 -c) <<'SHA'
b8f3c196878a30fd6abc5c1d1b593fbd366c725a20697408668e95712b762407  openIA-6.33.6-update.zip
cbc93a0b732906505ef2088b5fc735353796b1e6d195e5f356762169ee01e7eb  install-6.33.6.sh
4f92f4d1e885fd0f3aecb26d9082b90a8a186c4e98caa3740ab96dbcd1326ac4  openIA-6.33.6-update.json
c6ee5d6c1afb9c067f3de20e16ba887c7e72e9d2de177779fd6b3eeb095a2c22  signing-helper-6.33.6.zip
SHA
unzip -q "$work/signing-helper-6.33.6.zip" -d "$work/helper"
python3 "$work/helper/owner_sign_6336.py" --directory "$work" \
  --archive-sha b8f3c196878a30fd6abc5c1d1b593fbd366c725a20697408668e95712b762407 \
  --installer-sha cbc93a0b732906505ef2088b5fc735353796b1e6d195e5f356762169ee01e7eb \
  --source 6c2c3bee0e62c61e3a762a148a07d6310c06ce25
SIGN
```

Передаваемый файл — `armada-6.33.6-public-signatures.zip`. Сборщик для проверки ответа владельца лежит в `/workspace/armada-6336-build/signing-tools/assemble_signed_6336.py`. Кандидат для него — `/workspace/armada-6336-build/downloaded-candidate`.
