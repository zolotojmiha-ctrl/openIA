# Установка подписанной 6.33.5

21 ноября 2026 года владелец подтвердил по выводу установщика сохранение данных и настроек и возобновление MAX-worker. Ниже сохранены команды выполненного обновления.

Подписи и повторное скачивание проверены. Источник приложения d5077bd5cdf0f3b80d9e1533aa6bc067329c42f6, immutable release commit ddeb9357fc20504bf1cd87651604b531a844cec5. Установка выполняется владельцем; агент на VPS не подключается.

1. В терминале Mac подключиться:

```bash
ssh -o UseKeychain=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -i ~/.ssh/armada_beget root@185.23.35.28
```

2. После появления root@…# выполнить:

```bash
bash <<'UPDATE'
set -euo pipefail

if [[ "$(uname -s)" != "Linux" || "$EUID" -ne 0 ]]; then
  echo 'Эту команду нужно выполнить на VPS от root, после подключения по SSH.' >&2
  exit 1
fi

test -f /opt/armada/deploy/beget/compose.yml
armada_trust='/root/armada-6.32.0/armada-release-signing.public.pem'
test -f "$armada_trust"
armada_fingerprint=$(openssl pkey -pubin -in "$armada_trust" -outform DER | sha256sum | awk '{print $1}')
[[ "$armada_fingerprint" == 'e2f6b26419ccb10faa61baf1cfb5a0ea53f499da8803f23f0dd0df3f420aa3e4' ]]

umask 077
armada_work=$(mktemp -d /root/armada-6.33.5.XXXXXX)
armada_url='https://api.github.com/repos/zolotojmiha-ctrl/openIA/contents'
armada_ref='ddeb9357fc20504bf1cd87651604b531a844cec5'
for name in armada-6.33.5.zip armada-6.33.5.zip.sig; do
  curl --http1.1 --tlsv1.2 -fsSL --retry 3 \
    -H 'Accept: application/vnd.github.raw+json' \
    --output "$armada_work/$name" "$armada_url/$name?ref=$armada_ref"
done

printf '%s\n' '3c775798524155ffb7e7209ddf2b1572073179c1936b1871d766410407eaf3b0  armada-6.33.5.zip' | (cd "$armada_work" && sha256sum -c -)
openssl dgst -sha256 -verify "$armada_trust" -signature "$armada_work/armada-6.33.5.zip.sig" "$armada_work/armada-6.33.5.zip"

unzip -q "$armada_work/armada-6.33.5.zip" -d "$armada_work"
armada_release="$armada_work/armada-6.33.5"
(
  cd "$armada_release"
  openssl dgst -sha256 -verify "$armada_trust" -signature SHA256SUMS-6.33.5.sig SHA256SUMS-6.33.5
  sha256sum -c SHA256SUMS-6.33.5
  printf '%s\n' 'ed88e924d64fa785d343907855b0245b2a01c932cfdb28a44ff3490e77aa31a4  backup-recovery.public.pem' | sha256sum -c -
)

ARMADA_APP_ROOT=/opt/armada \
ARMADA_RELEASE_PUBLIC_KEY="$armada_trust" \
ARMADA_BACKUP_PUBLIC_KEY="$armada_release/backup-recovery.public.pem" \
bash "$armada_release/install-6.33.5.sh"
UPDATE
```

Установщик создаст свежую зашифрованную копию, сохранит `deploy/beget/.env` и возобновит ранее работавший MAX-worker. После установки отправьте финальные строки без содержимого каталога recovery.
