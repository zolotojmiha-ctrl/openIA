# Установка подписанной 6.33.6

21 ноября 2026 года владелец подтвердил установку по выводу терминала. Данные и настройки сохранены, MAX-worker возобновлён. Ниже команды выполненного обновления.

Подписи и повторное скачивание проверены. Источник приложения 6c2c3bee0e62c61e3a762a148a07d6310c06ce25, immutable release commit 155ad36196345f75d582bdde8f8d3eeac56750c5. Установка выполняется владельцем; агент на VPS не подключается.

1. В терминале Mac подключиться:

```bash
ssh -o UseKeychain=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -i ~/.ssh/armada_beget root@185.23.35.28
```

2. После появления root@…# выполнить:

```bash
bash <<'UPDATE'
set -euo pipefail

if [[ "$(uname -s)" != "Linux" || "$EUID" -ne 0 ]]; then
  echo 'Эту команду нужно выполнить на VPS от root, после подключения по SSH.' >&2
  exit 1
fi

test -f /opt/armada/deploy/beget/compose.yml
armada_trust='/root/armada-6.32.0/armada-release-signing.public.pem'
test -f "$armada_trust"
armada_fingerprint=$(openssl pkey -pubin -in "$armada_trust" -outform DER | sha256sum | awk '{print $1}')
[[ "$armada_fingerprint" == 'e2f6b26419ccb10faa61baf1cfb5a0ea53f499da8803f23f0dd0df3f420aa3e4' ]]

umask 077
armada_work=$(mktemp -d /root/armada-6.33.6.XXXXXX)
armada_url='https://api.github.com/repos/zolotojmiha-ctrl/openIA/contents'
armada_ref='155ad36196345f75d582bdde8f8d3eeac56750c5'
for name in armada-6.33.6.zip armada-6.33.6.zip.sig; do
  curl --http1.1 --tlsv1.2 -fsSL --retry 3 \
    -H 'Accept: application/vnd.github.raw+json' \
    --output "$armada_work/$name" "$armada_url/$name?ref=$armada_ref"
done

printf '%s\n' 'fc90e25fe4d81b2377150db12ddb8a59a5f1e7fc015b03e9a0c3e25f250b26c1  armada-6.33.6.zip' | (cd "$armada_work" && sha256sum -c -)
openssl dgst -sha256 -verify "$armada_trust" -signature "$armada_work/armada-6.33.6.zip.sig" "$armada_work/armada-6.33.6.zip"

unzip -q "$armada_work/armada-6.33.6.zip" -d "$armada_work"
armada_release="$armada_work/armada-6.33.6"
(
  cd "$armada_release"
  openssl dgst -sha256 -verify "$armada_trust" -signature SHA256SUMS-6.33.6.sig SHA256SUMS-6.33.6
  sha256sum -c SHA256SUMS-6.33.6
  printf '%s\n' 'ed88e924d64fa785d343907855b0245b2a01c932cfdb28a44ff3490e77aa31a4  backup-recovery.public.pem' | sha256sum -c -
)

ARMADA_APP_ROOT=/opt/armada \
ARMADA_RELEASE_PUBLIC_KEY="$armada_trust" \
ARMADA_BACKUP_PUBLIC_KEY="$armada_release/backup-recovery.public.pem" \
bash "$armada_release/install-6.33.6.sh"
UPDATE
```

Установщик создаст свежую зашифрованную копию, сохранит `deploy/beget/.env` и возобновит ранее работавший MAX-worker. После установки отправьте финальные строки без содержимого каталога recovery.
