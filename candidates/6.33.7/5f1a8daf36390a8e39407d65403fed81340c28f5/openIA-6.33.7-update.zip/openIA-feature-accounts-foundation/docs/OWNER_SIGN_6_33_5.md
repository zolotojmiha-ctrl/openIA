> Подпись получена и проверена. Следующий шаг — [установка подписанного выпуска](INSTALL_6_33_5.md).

# Подпись кандидата 6.33.5 владельцем

Кандидат 6.33.5 доступен из GitHub по неизменяемому коммиту `9fe926cd09a9445e04f784c1dd7ffedf5e81f510`. Проведено независимое скачивание всех четырёх файлов и сверка SHA-256. Помощник и сборщик воспроизведения пакета прошли пять проверок с синтетическим ключом. Прежнее подписанное подтверждение восстановления 6.33.1 прошло проверку.

Вариант ниже загружает файлы через GitHub API по HTTPS с TLS 1.2. Он предназначен в том числе для случая, когда загрузка с raw.githubusercontent.com оборвалась с ошибкой LibreSSL.

Вставьте команду в обычный терминал Mac и выберите проверенный ранее ключ подписи выпуска. Пароль ключа запрашивает OpenSSL в терминале.

```bash
bash <<'SIGN'
set -euo pipefail
if [[ "$(uname -s)" != Darwin || "$EUID" -eq 0 ]]; then
  echo 'Запустите в обычном терминале Mac.' >&2
  exit 1
fi
umask 077
mkdir -p "$HOME/Downloads"
work=$(mktemp -d "$HOME/Downloads/armada-6.33.5-sign.XXXXXX")
url='https://api.github.com/repos/zolotojmiha-ctrl/openIA/contents/candidates/6.33.5/d5077bd5cdf0f3b80d9e1533aa6bc067329c42f6'
ref='9fe926cd09a9445e04f784c1dd7ffedf5e81f510'
for name in openIA-6.33.5-update.zip install-6.33.5.sh openIA-6.33.5-update.json signing-helper-6.33.5.zip; do
  curl --http1.1 --tlsv1.2 --tls-max 1.2 -fsSL --retry 2 \
    -H 'Accept: application/vnd.github.raw+json' \
    --output "$work/$name" "$url/$name?ref=$ref"
done
(cd "$work" && shasum -a 256 -c) <<'SHA'
f47a40b1458d1e16ff19ea32f512866a35209f5cd13b691aedc50c760c6b2300  openIA-6.33.5-update.zip
cdf35412c6492804c1b60d48bac56a64cb71a5c506768238d992a962d8209810  install-6.33.5.sh
ba2abd299d8f4200f98634cf024490204b744ac04b952e3b0c94ae3b075ec34f  openIA-6.33.5-update.json
301baec219c6bbfe73cf89cf440e971560aaa3b728dd74b99edea82c14d6f772  signing-helper-6.33.5.zip
SHA
unzip -q "$work/signing-helper-6.33.5.zip" -d "$work/helper"
python3 "$work/helper/owner_sign_6335.py" --directory "$work" \
  --archive-sha f47a40b1458d1e16ff19ea32f512866a35209f5cd13b691aedc50c760c6b2300 \
  --installer-sha cdf35412c6492804c1b60d48bac56a64cb71a5c506768238d992a962d8209810 \
  --source d5077bd5cdf0f3b80d9e1533aa6bc067329c42f6
SIGN
```

Передаваемый файл — `armada-6.33.5-public-signatures.zip`. Он содержит только публичную часть процедуры подписи. После получения агент воспроизводит внешний ZIP из кандидата и проверяет обе подписи. Облачный сборщик и независимо скачанный кандидат находятся в `/workspace/armada-6335-build/signing-tools` и `/workspace/armada-6335-build/downloaded-candidate`. Рабочая версия 6.33.4 подтверждена владельцем.
