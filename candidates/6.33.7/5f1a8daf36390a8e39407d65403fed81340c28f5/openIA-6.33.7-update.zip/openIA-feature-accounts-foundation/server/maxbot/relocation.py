"""Native MAX selection and confirmation for moving defects."""
from datetime import timedelta
from uuid import UUID, uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone

from repairs import relocation
from repairs.models import Defect

COMMAND = '/перенести_дефекты'
PAGE_SIZE = 6
KEY = 'defect_relocation'


def delivery_allowed(binding, scope):
    if not relocation.allowed(binding.user):
        return False
    if not scope:
        return True
    contract = relocation.contracts(binding.user).filter(pk=scope['contract']).first()
    if contract is None:
        return False
    return relocation.areas(binding.user, contract).filter(pk__in=scope['areas']).count() == len(scope['areas'])


def save(binding, state):
    if state is None:
        binding.menu_scope.pop(KEY, None)
    else:
        binding.menu_scope[KEY] = {**state, 'expires': (timezone.now()+timedelta(minutes=30)).isoformat()}
    binding.save(update_fields=['menu_scope'])


def send(event, binding, text, actions=(), state=None, cancellable=True):
    from .dialog import button, queue
    scope = {}
    if state and state.get('contract'):
        scope = {'contract': state['contract'], 'areas': [state[k] for k in ('source', 'destination') if state.get(k)]}
    buttons = [button(label, payload) for label, payload in actions]
    if cancellable:
        buttons.append(button('Отменить перенос', 'relocate:cancel'))
    queue(event, text, buttons, binding=binding, scope={'defect_relocation': scope})


def page_rows(rows, page, action, choice, label):
    start = page*PAGE_SIZE
    subset = list(rows[start:start+PAGE_SIZE+1])
    buttons = [(label(row), f'relocate:{choice}:{row.pk}') for row in subset[:PAGE_SIZE]]
    if page:
        buttons.append(('Назад', f'relocate:{action}:{page-1}'))
    if len(subset) > PAGE_SIZE:
        buttons.append(('Далее', f'relocate:{action}:{page+1}'))
    return buttons


def page_number(value):
    try:
        return max(0, min(10000, int(value)))
    except (TypeError, ValueError):
        raise ValidationError('Откройте список заново.') from None


def pick(rows, value):
    try:
        row = rows.filter(pk=UUID(value)).first()
    except (TypeError, ValueError):
        row = None
    if row is None:
        raise ValidationError('Выбранная запись недоступна. Откройте перенос заново.')
    return row


def handle(event, binding):
    text = event.payload.get('text', '').strip()
    state = binding.menu_scope.get(KEY)
    if text != COMMAND and not text.startswith('relocate:'):
        return False
    user = binding.user
    if not relocation.allowed(user):
        raise PermissionDenied
    parts = text.split(':', 2)
    action, value = ('contracts', '0') if text == COMMAND else (parts[1], parts[2] if len(parts) == 3 else '')
    if action == 'cancel':
        save(binding, None)
        send(event, binding, 'Перенос отменён.', cancellable=False)
        return True
    if action == 'contracts':
        save(binding, {})
        from .leadership import contract_name
        buttons = page_rows(relocation.contracts(user).order_by('number', 'pk'), page_number(value),
                            'contracts', 'contract', lambda row: contract_name(user, row))
        send(event, binding, 'Выберите контракт.' if buttons else 'Доступных контрактов нет.', buttons)
        return True
    if state is None or timezone.datetime.fromisoformat(state['expires']) <= timezone.now():
        raise ValidationError('Откройте перенос заново: '+COMMAND)

    if action == 'contract':
        contract = pick(relocation.contracts(user), value)
        state = {'contract': str(contract.pk), 'ids': []}
        save(binding, state)
        action, value = 'sources', '0'
    contract = pick(relocation.contracts(user), state.get('contract', ''))
    objects = relocation.areas(user, contract)
    if action == 'sources':
        with_defects = objects.filter(pk__in=Defect.objects.filter(
            contract=contract, archived_at__isnull=True,
        ).values('section__project_object_id'))
        buttons = page_rows(with_defects, page_number(value), 'sources', 'source', lambda row: row.name)
        send(event, binding, 'Выберите исходный объект.' if buttons else 'На объектах контракта нет дефектов.',
             buttons, state)
        return True

    if action == 'source':
        source = pick(objects, value)
        state = {'contract': str(contract.pk), 'source': str(source.pk), 'ids': [], 'page': 0}
        save(binding, state)
        action, value = 'defects', '0'
    source = pick(objects, state.get('source', ''))
    available = relocation.candidates(contract, source)

    if action in ('defects', 'toggle'):
        if action == 'toggle':
            ident = str(pick(available, value).pk)
            selected = state['ids']
            if ident in selected:
                selected.remove(ident)
            elif len(selected) >= relocation.MAX_DEFECTS:
                raise ValidationError(f'За один перенос можно выбрать до {relocation.MAX_DEFECTS} дефектов.')
            else:
                selected.append(ident)
        else:
            state['page'] = page_number(value)
        for key in ('destination', 'fingerprint', 'nonce'):
            state.pop(key, None)
        save(binding, state)
        buttons = page_rows(available, state['page'], 'defects', 'toggle',
                            lambda row: ('✓ ' if str(row.pk) in state['ids'] else '') + relocation.defect_label(row))
        if state['ids']:
            buttons.append(('Выбрать новый объект', 'relocate:targets:0'))
        send(event, binding, f'{source.name}\nВыберите дефекты · выбрано {len(state["ids"])}.', buttons, state)
        return True

    ids = relocation.identifiers(state['ids'])
    if action == 'targets':
        for key in ('destination', 'fingerprint', 'nonce'):
            state.pop(key, None)
        save(binding, state)
        buttons = page_rows(objects.exclude(pk=source.pk), page_number(value), 'targets', 'target', lambda row: row.name)
        buttons.append(('Изменить выбор дефектов', f'relocate:defects:{state["page"]}'))
        send(event, binding, 'Куда перенести выбранные дефекты?', buttons, state)
        return True

    if action == 'target':
        target = pick(objects.exclude(pk=source.pk), value)
        preview = relocation.inspect(user, contract.pk, source.pk, target.pk, ids)
        state.update(destination=str(target.pk), fingerprint=relocation.fingerprint(preview), nonce=uuid4().hex)
        save(binding, state)
        stats = (f'Дефектов: {len(preview.defects)} · работ: {len(preview.jobs)} · '
                 f'отчётов: {preview.reports} · фото: {preview.photos}\n'
                 f'Закреплений: {preview.reservations} · муфт: {len(preview.couplings)} · '
                 f'складских операций: {preview.stock_movements}')
        body = f'{source.name} → {target.name}\n{stats}\n'
        if preview.warehouses:
            body += 'Связанные склады · ' + ', '.join(preview.warehouses[:5]) + '\n'
        body += '\n'.join(f'№{row.number} · км {row.km}' for row in preview.defects[:20])
        if len(preview.defects) > 20:
            body += f'\nИ ещё {len(preview.defects)-20} из выбранных дефектов.'
        buttons = [('Изменить выбор дефектов', f'relocate:defects:{state["page"]}'),
                   ('Выбрать другой объект', 'relocate:targets:0')]
        body += '\nМеняется участок. Отчёты, назначения и складские связи сохраняются.'
        if preview.issues:
            body += '\n' + '\n'.join(preview.issues)
        else:
            buttons.insert(0, ('Подтвердить перенос', 'relocate:confirm:'+state['nonce']))
        if preview.notes:
            body += '\n' + '\n'.join(preview.notes)
        send(event, binding, body, buttons, state)
        return True

    if action == 'confirm' and value == state.get('nonce'):
        target = pick(objects.exclude(pk=source.pk), state['destination'])
        result = relocation.move(user, contract.pk, source.pk, target.pk, ids, state['fingerprint'])
        save(binding, None)
        send(event, binding, f'Дефектов перенесено: {len(result.defects)}. Новый объект — {result.destination.name}.',
             state=state, cancellable=False)
        return True
    raise ValidationError('Подтверждение устарело. Проверьте перенос заново.')
