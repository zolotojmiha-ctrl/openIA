from datetime import date

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from accounts.models import User
from accounts.views import audit
from projects.models import SubcontractContractStaff
from projects.subcontract_scope import memberships
from .access import visible_people
from .models import Person, TimesheetAssignment, TimesheetDay


def eligible(person):
    candidates = User.objects.filter(is_active=True).exclude(role__in=['customer', 'lessor']).order_by('full_name', 'pk')
    if person.user_id and person.user.role == 'subcontractor':
        assignment_ids = memberships(person.user).values('assignment_id')
        same_team = SubcontractContractStaff.objects.filter(
            assignment_id__in=assignment_ids, active=True,
        ).values('user_id')
        return candidates.filter(~Q(role='subcontractor') | Q(pk__in=same_team))
    return candidates.exclude(role='subcontractor')


def assigned_people(user):
    people = Person.objects.filter(archived=False, timesheet__responsible__isnull=False)
    if user.is_leader:
        return people
    if not user.is_active or user.role in ('customer', 'lessor'):
        return people.none()
    people = people.filter(timesheet__responsible=user)
    if user.role == 'subcontractor':
        teammates = SubcontractContractStaff.objects.filter(
            assignment_id__in=memberships(user).values('assignment_id'),
            active=True, user__is_active=True, user__role='subcontractor',
        ).values('user_id')
        people = people.filter(user_id__in=teammates)
    return people


def may_open(user):
    return user.is_active and (user.is_leader or assigned_people(user).exists())


def directory(user):
    if not user.is_active or not user.is_leader:
        raise PermissionDenied
    return visible_people(user).filter(archived=False)


def for_date(user, day):
    if not may_open(user):
        raise PermissionDenied
    people = assigned_people(user)
    if user.is_leader:
        people = visible_people(user).filter(Q(pk__in=people) | Q(timesheet_days__date=day)).distinct()
    return people.order_by('full_name', 'pk')


def parse_date(value):
    try:
        return date.fromisoformat(value)
    except (TypeError, ValueError):
        raise ValidationError('Укажите дату в формате ГГГГ-ММ-ДД.') from None


def _actor(user):
    current = User.objects.select_for_update(no_key=True).get(pk=user.pk)
    if not current.is_active or current.session_version != user.session_version:
        raise PermissionDenied
    return current


@transaction.atomic
def configure(user, person_id, responsible_id, version):
    actor = _actor(user)
    person = directory(actor).select_for_update(no_key=True, of=('self',)).filter(pk=person_id).first()
    if person is None:
        raise PermissionDenied
    responsible = eligible(person).filter(pk=responsible_id).first() if responsible_id else None
    if responsible_id and not responsible:
        raise ValidationError('Этот ответственный больше недоступен.')
    assignment = TimesheetAssignment.objects.filter(person=person).first()
    if (assignment.version if assignment else 0) != version:
        raise ValidationError('Настройки уже изменены. Откройте карточку заново.')
    if (assignment.responsible_id if assignment else None) == responsible_id:
        return
    TimesheetAssignment.objects.update_or_create(person=person, defaults={'responsible': responsible, 'version': version + 1})
    audit(actor, 'person_timesheet_configured', person=str(person.pk), responsible=str(responsible_id or ''))


@transaction.atomic
def record(user, person_id, day, mark, version, assignment_version):
    if day > timezone.localdate() or mark not in TimesheetDay.Mark.values:
        raise ValidationError('Выберите прошедшую или сегодняшнюю дату и отметку.')
    actor = _actor(user)
    person = Person.objects.select_for_update(no_key=True).filter(pk=person_id).first()
    assignment = TimesheetAssignment.objects.filter(person_id=person_id).first()
    if not person or not assignment or not assigned_people(actor).filter(pk=person_id).exists():
        raise PermissionDenied
    if assignment.version != assignment_version:
        raise ValidationError('Ответственный изменился. Откройте табель заново.')
    entry = TimesheetDay.objects.filter(person=person, date=day).first()
    if entry and entry.mark == mark:
        return entry
    if (entry.version if entry else 0) != version:
        raise ValidationError('Отметка уже изменена. Откройте табель заново.')
    previous_mark = entry.mark if entry else ''
    entry, _ = TimesheetDay.objects.update_or_create(
        person=person, date=day, defaults={'mark': mark, 'author': actor, 'version': version + 1},
    )
    audit(actor, 'person_timesheet_marked', person=str(person_id), date=day.isoformat(), previous=previous_mark, mark=mark)
    return entry
