from datetime import timedelta
from uuid import uuid4

from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from accounts.models import User
from maxbot.models import Binding, Inbox, Outbox
from maxbot.worker import delivery_allowed, process
from projects.models import SubcontractContract, Subcontractor
from projects import test_stock as fixtures
from .models import Person, TimesheetAssignment, TimesheetDay
from .timesheets import configure


class PersonnelTimesheetTests(TestCase):
    setUpTestData = classmethod(fixtures.StockTests.setUpTestData.__func__)

    def setUp(self):
        self.person = Person.objects.create(
            legal_entity=self.company, full_name='ТЕСТ Работник', created_by=self.leader,
        )
        self.other = Person.objects.create(
            legal_entity=self.company, full_name='ТЕСТ Без табеля', created_by=self.leader,
        )
        self.url = reverse('person_timesheet')
        self.settings = reverse('person_timesheet_config', args=[self.person.pk])
        self.day = timezone.localdate()

    def payload(self, **updates):
        return {'person': str(self.person.pk), 'date': self.day.isoformat(), 'mark': 'work',
                'version': 0, 'assignment_version': 1, **updates}

    def test_web_opt_in_mark_correct_disable_and_preserve_history(self):
        self.client.force_login(self.leader)
        self.assertNotContains(self.client.get(self.url), self.person.full_name)
        self.assertContains(self.client.get(self.settings), self.worker.full_name)
        self.assertEqual(self.client.post(self.settings, {'responsible': self.worker.pk, 'version': 0}).status_code, 302)
        self.client.force_login(self.worker)
        page = self.client.get(self.url)
        self.assertContains(page, self.person.full_name)
        self.assertNotContains(page, self.other.full_name)
        self.assertEqual(self.client.post(self.url, self.payload(person=self.other.pk)).status_code, 403)
        self.assertEqual(self.client.get(self.settings).status_code, 403)
        self.assertEqual(self.client.post(self.url, self.payload()).status_code, 302)
        self.assertEqual(self.client.post(self.url, self.payload()).status_code, 302)
        self.assertEqual(TimesheetDay.objects.count(), 1)
        self.client.force_login(self.leader)
        self.assertEqual(self.client.post(self.url, self.payload(mark='off', version=1)).status_code, 302)
        self.assertEqual(self.client.post(self.url, self.payload(mark='work', version=1)).status_code, 409)
        self.assertEqual(self.client.post(self.settings, {'responsible': '', 'version': 1}).status_code, 302)
        self.assertContains(self.client.get(self.url), 'Выходной')
        self.assertEqual(TimesheetDay.objects.get().author, self.leader)
        self.client.force_login(self.worker)
        self.assertEqual(self.client.get(self.url).status_code, 403)

    def test_stale_assignment_and_future_date_cannot_change_marks(self):
        configure(self.leader, self.person.pk, self.worker.pk, 0)
        configure(self.leader, self.person.pk, self.supply.pk, 1)
        self.client.force_login(self.worker)
        self.assertEqual(self.client.post(self.url, self.payload()).status_code, 403)
        self.client.force_login(self.supply)
        self.assertEqual(self.client.post(self.url, self.payload()).status_code, 409)
        future = (self.day + timedelta(days=1)).isoformat()
        self.assertEqual(self.client.post(self.url, self.payload(date=future, assignment_version=2)).status_code, 409)
        self.assertFalse(TimesheetDay.objects.exists())

    def test_subcontract_responsible_is_confined_to_own_active_contract_team(self):
        worker = User.objects.create_user('+70000007101', role='subcontractor', full_name='ТЕСТ Мастер субподрядчика',
                                          must_change_password=False)
        teammate = User.objects.create_user('+70000007102', role='subcontractor', full_name='ТЕСТ Сотрудник субподрядчика',
                                            must_change_password=False)
        outsider = User.objects.create_user('+70000007103', role='subcontractor', full_name='ТЕСТ Другая компания',
                                            must_change_password=False)
        company = Subcontractor.objects.create(legal_entity=self.company, name='ТЕСТ Компания', tax_id='0000000001',
                                               created_by=self.leader)
        assignment = SubcontractContract.objects.create(company=company, contract=self.contract, assigned_by=self.leader)
        assignment.team.create(user=worker, role='foreman')
        member = assignment.team.create(user=teammate, role='foreman')
        self.person.user = teammate
        self.person.save(update_fields=['user'])
        self.client.force_login(self.leader)
        self.assertEqual(self.client.post(self.settings, {'responsible': outsider.pk, 'version': 0}).status_code, 200)
        self.assertFalse(TimesheetAssignment.objects.exists())
        self.assertEqual(self.client.post(self.settings, {'responsible': worker.pk, 'version': 0}).status_code, 302)
        self.client.force_login(worker)
        self.assertContains(self.client.get(reverse('repairs')), self.url)
        self.assertEqual(self.client.post(self.url, self.payload()).status_code, 302)
        member.active = False
        member.save(update_fields=['active'])
        self.assertEqual(self.client.get(self.url).status_code, 403)
        self.assertEqual(TimesheetDay.objects.count(), 1)

    def bot(self, binding, text, suffix='reply'):
        inbox = Inbox.objects.create(key=uuid4().hex, max_user=binding.max_user, chat=binding.chat,
                                     payload={'text': text, 'kind': 'message_created'})
        process(inbox.pk)
        return Outbox.objects.get(key=f'in:{inbox.pk}:{suffix}')

    def bind(self, user, index):
        return Binding.objects.create(user=user, max_user=index, chat=index, session_version=user.session_version)

    def test_max_configuration_and_mark_have_confirmation_cancellation_and_delivery_scope(self):
        leader = self.bind(self.leader, 1431)
        worker = self.bind(self.worker, 1432)
        self.bot(leader, f'ts:assign:{self.person.pk}:{self.worker.pk}')
        leader.refresh_from_db()
        nonce = leader.menu_scope['timesheet_pending']['nonce']
        self.assertFalse(TimesheetAssignment.objects.exists())
        self.bot(leader, f'ts:save:{nonce}')
        self.assertEqual(TimesheetAssignment.objects.get().responsible, self.worker)
        listing = self.bot(worker, '/табель')
        self.assertTrue(delivery_allowed(listing))
        self.assertIn(self.person.full_name, str(listing.body))
        self.assertNotIn(self.other.full_name, str(listing.body))
        self.bot(worker, f'ts:mark:{self.person.pk}:{self.day}:work')
        worker.refresh_from_db()
        nonce = worker.menu_scope['timesheet_pending']['nonce']
        self.bot(worker, f'ts:cancel:{nonce}')
        self.bot(worker, f'ts:save:{nonce}', suffix='error')
        self.assertFalse(TimesheetDay.objects.exists())
        self.bot(worker, f'ts:mark:{self.person.pk}:{self.day}:off')
        worker.refresh_from_db()
        self.bot(worker, f"ts:save:{worker.menu_scope['timesheet_pending']['nonce']}")
        self.assertEqual(TimesheetDay.objects.get().mark, 'off')
        configure(self.leader, self.person.pk, self.supply.pk, 1)
        self.assertFalse(delivery_allowed(listing))
        self.bot(worker, f'ts:person:{self.person.pk}:{self.day}', suffix='error')
