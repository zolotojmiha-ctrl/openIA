from datetime import timedelta

from django import forms
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.core.paginator import Paginator
from django.db.models import Prefetch
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from . import timesheets
from .models import TimesheetAssignment, TimesheetDay


class ResponsibleChoice(forms.ModelChoiceField):
    def label_from_instance(self, user):
        role = 'Руководитель' if user.is_leader else user.get_role_display()
        return f'{user.full_name} · {role}' if role else user.full_name


class SettingsForm(forms.Form):
    responsible = ResponsibleChoice(
        queryset=None, label='Кто ведёт табель', required=False, empty_label='Табель выключен',
    )
    version = forms.IntegerField(min_value=0, widget=forms.HiddenInput)


@login_required
@require_http_methods(['GET', 'POST'])
def configure(request, pk):
    person = get_object_or_404(timesheets.directory(request.user).select_related('user'), pk=pk)
    assignment = TimesheetAssignment.objects.filter(person=person).first()
    form = SettingsForm(request.POST if request.method == 'POST' else None, initial={
        'responsible': assignment.responsible_id if assignment else None,
        'version': assignment.version if assignment else 0,
    })
    form.fields['responsible'].queryset = timesheets.eligible(person)
    if request.method == 'POST' and form.is_valid():
        responsible = form.cleaned_data['responsible']
        try:
            timesheets.configure(request.user, pk, responsible.pk if responsible else None, form.cleaned_data['version'])
        except ValidationError as error:
            form.add_error(None, error)
        else:
            return redirect('person_detail', pk=pk)
    return render(request, 'documents/timesheet_config.html', {'person': person, 'form': form})


class MarkForm(forms.Form):
    person = forms.UUIDField()
    date = forms.DateField(input_formats=['%Y-%m-%d'])
    mark = forms.ChoiceField(choices=TimesheetDay.Mark.choices)
    version = forms.IntegerField(min_value=0)
    assignment_version = forms.IntegerField(min_value=1)
    page = forms.IntegerField(min_value=1, required=False)


@login_required
@require_http_methods(['GET', 'POST'])
def sheet(request):
    error = ''
    today = timezone.localdate()
    page_number = request.GET.get('page')
    if request.method == 'POST':
        form = MarkForm(request.POST)
        if not form.is_valid():
            return HttpResponse('Проверьте дату и отметку.', status=400)
        data = form.cleaned_data
        day = data['date']
        page_number = data['page']
        try:
            timesheets.record(request.user, data['person'], day, data['mark'], data['version'], data['assignment_version'])
        except ValidationError as exc:
            error = exc.messages[0]
        else:
            target = f"{request.path}?date={day.isoformat()}"
            return redirect(f'{target}&page={page_number}' if page_number else target)
    else:
        try:
            day = timesheets.parse_date(request.GET['date']) if 'date' in request.GET else today
        except ValidationError as exc:
            return HttpResponse(exc.messages[0], status=400)
        if day > today:
            return HttpResponse('Выберите сегодняшнюю или прошедшую дату.', status=400)
    people = timesheets.for_date(request.user, day).select_related('timesheet').prefetch_related(
        Prefetch('timesheet_days', queryset=TimesheetDay.objects.filter(date=day), to_attr='selected_day_entries'),
    )
    page = Paginator(people, 40).get_page(page_number)
    for person in page:
        person.selected_day = next(iter(person.selected_day_entries), None)
    return render(request, 'documents/timesheet.html', {
        'day': day, 'previous': day - timedelta(days=1) if day > day.min else None,
        'next_day': day + timedelta(days=1) if day < today else None,
        'today': today, 'page': page, 'error': error,
    }, status=409 if error else 200)
