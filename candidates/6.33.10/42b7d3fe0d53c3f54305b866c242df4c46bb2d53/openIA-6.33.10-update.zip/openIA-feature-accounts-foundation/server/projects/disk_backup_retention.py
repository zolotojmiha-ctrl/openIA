"""Keep seven verified nightly backups and the latest verified restore on Disk."""
import re
from datetime import datetime, timezone as utc

from django.core.exceptions import ValidationError
from django.db import transaction
from django.utils import timezone

from .models import DiskBackupJob, DiskBackupSettings
from .yandex_disk import DiskError, ROOT


KEEP_NIGHTLY = 7


def archive_path(job):
    return f'{ROOT}/backups/{job.created_at.date()}-{job.pk}.encrypted'


def checks_match(client, job):
    if job.remote_path != archive_path(job) or job.size <= 0 or not re.fullmatch('[a-f0-9]{64}',job.sha256):
        raise DiskError('Резервная копия отсутствует в реестре или путь изменился.')
    meta=client.metadata(job.remote_path)
    if meta.get('type') != 'file' or meta.get('size') != job.size or meta.get('sha256') != job.sha256:
        raise DiskError('Размер или SHA-256 резервной копии на Диске изменился.')


def active_copies():
    return DiskBackupJob.objects.filter(state='verified',verified_at__isnull=False,disk_removed_at__isnull=True)


def restore_point():
    return active_copies().exclude(restored_at__isnull=True).order_by('-restored_at','-verified_at','pk').first()


@transaction.atomic
def register_restore(actor, receipt):
    from .disk_backups import admin
    from accounts.views import audit

    actor=admin(actor)
    config=DiskBackupSettings.objects.select_for_update().filter(pk=1).first()
    if not config or not isinstance(receipt,dict) or receipt.get('restored') is not True:
        raise ValidationError('Нужна квитанция об успешном восстановлении.')
    sha=receipt.get('sha256')
    stamp=receipt.get('verified_at')
    if not isinstance(sha,str) or not re.fullmatch('[a-f0-9]{64}',sha) or type(stamp) is not int:
        raise ValidationError('В квитанции должны быть SHA-256 файла и время восстановления.')
    try:
        restored_at=datetime.fromtimestamp(stamp,tz=utc.utc)
    except (OverflowError,OSError,ValueError):
        raise ValidationError('Неверное время восстановления.') from None
    candidates=active_copies().filter(sha256=sha,created_at__lte=restored_at).order_by('-verified_at','pk')
    job=next((candidate for candidate in candidates if candidate.remote_path==archive_path(candidate)),None)
    if not job or restored_at > timezone.now():
        raise ValidationError('Квитанция не соответствует доступной копии в истории Яндекс Диска.')
    if job.restored_at is None or restored_at > job.restored_at:
        job.restored_at=restored_at
        job.save(update_fields=['restored_at'])
        audit(actor,'disk_backup_settings',kind='restore_registered',job=str(job.pk))
    return job


def prune_after_nightly(client, completed):
    if not completed.automatic_day:
        return
    nightly=active_copies().filter(automatic_day__isnull=False).order_by('-automatic_day')
    kept=list(nightly[:KEEP_NIGHTLY])
    restored=restore_point()
    if len(kept) < KEEP_NIGHTLY or not restored or kept[0].pk != completed.pk:
        return
    if not nightly.filter(automatic_day__lt=kept[-1].automatic_day).exclude(pk=restored.pk).exists():
        return
    for job in {job.pk:job for job in [*kept,restored]}.values():
        checks_match(client,job)
    older=nightly.filter(automatic_day__lt=kept[-1].automatic_day).exclude(pk=restored.pk)
    old_ids=list(older.values_list('pk',flat=True))
    for pk in old_ids:
        with transaction.atomic():
            config=DiskBackupSettings.objects.select_for_update().get(pk=1)
            if config.version != completed.config_version:
                return
            current_restore=restore_point()
            if not current_restore or current_restore.pk != restored.pk:
                return
            job=older.filter(pk=pk).first()
            if not job:
                continue
            try:
                checks_match(client,job)
                client.delete_backup(job.remote_path)
                client.metadata(job.remote_path)
            except FileNotFoundError:
                job.disk_removed_at=timezone.now()
                job.save(update_fields=['disk_removed_at'])
