from .passwords import temporary_password
from datetime import timedelta
from functools import wraps
from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied,ValidationError
from django.db import IntegrityError, transaction
from django.http import FileResponse, Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.utils.crypto import salted_hmac
from django.views.decorators.debug import sensitive_post_parameters, sensitive_variables
from django.views.decorators.http import require_POST
from .permissions import permission_required,manageable_user
from .forms import REMEMBER_ME_DAYS, LoginForm, EmployeeForm, SecurePasswordChangeForm
from .models import User, AccessGrant, AuditEvent, LoginAttempt, WebPushDevice, PERMISSIONS, temporary_deadline


def leader_required(view):
    @login_required
    @wraps(view)
    def wrapper(request,*args,**kwargs):
        if not request.user.is_leader:
            raise PermissionDenied
        return view(request,*args,**kwargs)
    return wrapper

def audit(actor,action,subject=None,**details):
    AuditEvent.objects.create(actor=actor,subject=subject,action=action,details=details)

def consume_attempts(phone,ip):
    now=timezone.now()
    blocked=False
    with transaction.atomic():
        for kind,value,limit in [('phone',phone,8),('ip',ip,40)]:
            key=salted_hmac('armada.login.'+kind,value).hexdigest()
            entry,_=LoginAttempt.objects.select_for_update().get_or_create(key=key,defaults={'window_start':now})
            if now-entry.window_start>=timedelta(minutes=15):
                entry.count=0
                entry.window_start=now
            if entry.count>=limit:
                blocked=True
            entry.count+=1
            entry.save()
    return blocked

@sensitive_post_parameters('password')
def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    form=LoginForm(request.POST or None)
    if request.method=='POST':
        # Invalid phone syntax also consumes an IP attempt.
        valid=form.is_valid()
        phone=form.cleaned_data.get('phone','invalid') if valid else 'invalid'
        blocked=consume_attempts(phone,request.META.get('REMOTE_ADDR','unknown'))
        if blocked:
            form.add_error(None,'Слишком много попыток. Попробуйте через 15 минут.')
        elif valid:
            user=authenticate(request,username=phone,password=form.cleaned_data['password'])
            if user and not (user.must_change_password and (not user.temporary_expires_at or user.temporary_expires_at <= timezone.now())):
                login(request,user)
                if form.cleaned_data['remember_me'] and not user.must_change_password:
                    request.session.set_expiry(timezone.now() + timedelta(days=REMEMBER_ME_DAYS))
                LoginAttempt.objects.filter(key=salted_hmac('armada.login.phone',phone).hexdigest()).delete()
                audit(user,'login',user)
                if user.must_change_password:return redirect('password')
                from maxbot.links import needs_onboarding
                if needs_onboarding(user):
                    request.session['max_onboarding']=str(user.pk)
                    return redirect('max_onboarding')
                return redirect('dashboard')
            form.add_error(None,'Не удалось войти. Проверьте телефон и пароль.')
    return render(request,'accounts/login.html',{'form':form})

@login_required
@require_POST
def logout_view(request):
    audit(request.user,'logout',request.user)
    WebPushDevice.objects.filter(user=request.user,session_key=request.session.session_key).delete()
    logout(request)
    return redirect('login')

@login_required
@sensitive_post_parameters('old_password','new_password1','new_password2')
def password_view(request):
    form=SecurePasswordChangeForm(request.user,request.POST or None)
    if request.method=='POST' and form.is_valid():
        with transaction.atomic():
            user=User.objects.select_for_update().get(pk=request.user.pk)
            if not user.check_password(form.cleaned_data['old_password']):
                form.add_error(None,'Пароль уже изменён. Войдите заново.')
                return render(request,'accounts/password.html',{'form':form})
            first_password = user.must_change_password
            user.set_password(form.cleaned_data['new_password1'])
            user.must_change_password=False
            user.temporary_expires_at=None
            user.session_version+=1
            user.save()
            audit(user,'password_changed',user)
        update_session_auth_hash(request,user)
        messages.success(request,'Пароль изменён. Другие сеансы завершены.')
        from maxbot.links import needs_onboarding
        if first_password and needs_onboarding(user):
            request.session['max_onboarding'] = str(user.pk)
            return redirect('max_onboarding')
        return redirect('dashboard')
    return render(request,'accounts/password.html',{'form':form})

@login_required
def dashboard(request):
    from projects.subcontract_scope import managed
    if managed(request.user):
        return redirect('repairs')
    if request.user.role=='lessor' and not request.user.is_leader:return redirect('lessor_home')
    from projects.access import visible_objects, visible_contracts,contract_card
    from documents.access import visible_documents,unread_documents
    from .personal import favorite_items
    from .models import Reminder, SupportRequest
    context={'object_count':visible_objects(request.user).count(),'contract_count':visible_contracts(request.user).count(),'document_count':visible_documents(request.user).filter(archived=False).count(),
        'recent_objects':visible_objects(request.user).order_by('name')[:5],'recent_contracts':[contract_card(c,request.user) for c in visible_contracts(request.user).order_by('id')[:5]],'new_documents':unread_documents(request.user).select_related('current_version').order_by('-current_version__created_at')[:5],
        'favorites':favorite_items(request.user),'reminders':Reminder.objects.filter(user=request.user,done=False).filter(document__isnull=True).order_by('date')[:5],
        'support_count':SupportRequest.objects.filter(status='new').count() if request.user.is_leader else 0}
    from projects.subcontracts import orders as subcontract_orders
    context['subcontract_orders_count']=subcontract_orders(request.user).count()
    from projects.stock import warehouses
    context['warehouse_count']=warehouses(request.user).filter(archived=False).count()
    from projects.equipment import visible_equipment,due_documents
    context.update(equipment_total=visible_equipment(request.user).exclude(status='archived').count(),equipment_due=due_documents(request.user))
    if request.user.is_leader:
        from finance.views import dashboard_data
        context.update(dashboard_data(request.user))
    from .start import role_home
    context['role_home']=role_home(request.user)
    return render(request,'accounts/dashboard.html',context)

@permission_required('users.manage')
def users(request):
    return render(request,'accounts/users.html',{'employees':[u for u in User.objects.filter(leader_slot__isnull=True).order_by('full_name') if manageable_user(request.user,u)],'leaders':User.objects.filter(leader_slot__isnull=False).order_by('leader_slot')})

@permission_required('users.manage')
@sensitive_post_parameters()
@sensitive_variables('temporary')
def employee_edit(request,pk=None):
    employee=get_object_or_404(User,pk=pk,leader_slot__isnull=True) if pk else None
    person=None
    initial={'expected_version':employee.session_version,'full_name':employee.full_name,'phone':employee.phone,'role':employee.role,'is_active':employee.is_active,'permissions':[p for p in employee.grants.values_list('permission',flat=True) if p in PERMISSIONS]} if employee else {}
    if employee and not manageable_user(request.user,employee):raise PermissionDenied
    if not employee and request.GET.get('person'):
        from uuid import UUID
        from .permissions import can_link_person
        from documents.access import visible_people
        if not can_link_person(request.user):raise PermissionDenied
        try:person_id=UUID(request.GET['person'])
        except ValueError:raise Http404
        person=get_object_or_404(visible_people(request.user),pk=person_id,archived=False)
        if person.user_id:return redirect('employee_edit',pk=person.user_id)
        initial.update(full_name=person.full_name,expected_version=person.revision)
    form=EmployeeForm(request.POST or None,initial=initial,user=employee,actor=request.user)
    if person:form.fields['full_name'].disabled=True
    if request.method=='POST' and form.is_valid():
        temporary=None
        try:
            with transaction.atomic():
                locked_users={u.pk:u for u in User.objects.select_for_update().filter(pk__in=[request.user.pk]+([employee.pk] if employee else [])).order_by('pk')}
                actor=locked_users[request.user.pk]
                from .permissions import permitted
                if not permitted(actor,'users.manage'):raise PermissionDenied
                if not actor.is_leader and not set(form.cleaned_data['permissions']).issubset(set(actor.grants.values_list('permission',flat=True))):raise PermissionDenied
                role=form.cleaned_data['role']
                if person:
                    from .permissions import can_link_person
                    from documents.models import Person
                    if not can_link_person(actor):raise PermissionDenied
                    person=Person.objects.select_for_update().get(pk=person.pk)
                    if person.archived or person.user_id or person.revision!=form.cleaned_data['expected_version']:
                        raise ValidationError('Карточка сотрудника изменилась. Обновите страницу.')
                    if not form.cleaned_data['is_active'] or role in ('customer','lessor'):
                        raise ValidationError('Для карточки сотрудника выберите активную учётную запись с рабочей должностью.')
                if employee:
                    employee=locked_users[employee.pk]
                    if not manageable_user(actor,employee):raise PermissionDenied
                    if not actor.is_leader and (employee.role=='pto')!=(role=='pto') and employee.contract_access.exists():
                        raise PermissionDenied
                    if form.cleaned_data['expected_version'] != employee.session_version:
                        form.add_error(None,'Настройки уже изменил другой руководитель. Обновите страницу и проверьте изменения.')
                        return render(request,'accounts/employee.html',{'form':form,'employee':employee})
                    before=list(employee.grants.values_list('permission',flat=True))
                else:
                    employee=User()
                    before=[]
                    temporary=temporary_password()
                    employee.set_password(temporary)
                employee.full_name=form.cleaned_data['full_name']
                employee.phone=form.cleaned_data['phone']
                employee.role=role
                employee.is_active=form.cleaned_data['is_active']
                employee.session_version+=1
                employee.save()
                if not employee.is_active:
                    from documents.models import Person
                    Person.objects.filter(user=employee).update(archived=True)
                employee.grants.all().delete()
                AccessGrant.objects.bulk_create([AccessGrant(user=employee,permission=p,granted_by=request.user) for p in form.cleaned_data['permissions']])
                from .work_access import save_work_access
                work_changes=save_work_access(actor,employee,form.cleaned_data)
                if employee.role=='customer' and form.cleaned_data.get('customer_scopes_present'):
                    from projects.models import CustomerAccess
                    CustomerAccess.objects.filter(user=employee).delete()
                    CustomerAccess.objects.bulk_create([CustomerAccess(user=employee,contract=s.contract,project_object=s.project_object,created_by=actor) for s in form.cleaned_data['customer_scopes']])
                if person:
                    person.user=employee
                    person.revision+=1
                    person.save(update_fields=['user','revision'])
                elif temporary and employee.role not in ('customer','lessor'):
                    from documents.models import Person
                    from projects.models import LegalEntity,COMPANY_TAX_ID
                    Person.objects.create(user=employee,legal_entity=LegalEntity.objects.get(tax_id=COMPANY_TAX_ID),full_name=employee.full_name,position=employee.get_role_display(),created_by=request.user)
                if form.cleaned_data.get('request_mail'):
                    from postoffice.services import request_address
                    request_address(actor,form.cleaned_data['mail_address'],owner=employee)
                audit(request.user,'employee_created' if temporary else 'employee_updated',employee,previous_permissions=before,permissions=form.cleaned_data['permissions'],active=employee.is_active,**work_changes)
        except ValidationError as exc:
            form.add_error(None,exc)
        except IntegrityError:
            form.add_error('phone','Телефон уже используется. Обновите страницу и повторите.')
        else:
            if temporary:
                return render(request,'accounts/temporary.html',{'employee':employee,'temporary':temporary,'person':person})
            messages.success(request,'Данные и права сохранены. Прежние сеансы сотрудника завершены.')
            return redirect('users')
    return render(request,'accounts/employee.html',{'form':form,'employee':employee,'person':person})

@permission_required('users.manage')
@require_POST
@sensitive_variables('temporary')
def reset_password(request,pk):
    with transaction.atomic():
        from .permissions import permitted
        locked_users={u.pk:u for u in User.objects.select_for_update().filter(pk__in=[request.user.pk,pk]).order_by('pk')}
        actor=locked_users[request.user.pk]
        user=locked_users.get(pk)
        if not user or not permitted(actor,'users.manage') or not manageable_user(actor,user):raise PermissionDenied
        temporary=temporary_password()
        user.set_password(temporary)
        user.must_change_password=True
        user.temporary_expires_at=temporary_deadline()
        user.session_version+=1
        user.save()
        audit(request.user,'employee_password_reset',user)
    return render(request,'accounts/temporary.html',{'employee':user,'temporary':temporary})

@leader_required
def audit_view(request):
    return render(request,'accounts/audit.html',{'events':AuditEvent.objects.select_related('actor','subject').order_by('-created_at')[:200]})

def public_site(request):
    response=FileResponse((settings.BASE_DIR/'index.html').open('rb'),content_type='text/html; charset=utf-8')
    return response

def prototype(request,filename='index.html'):
    if filename not in ['index.html','portal.css','portal.js']:
        raise Http404
    mime={'index.html':'text/html','portal.css':'text/css','portal.js':'text/javascript'}[filename]
    return FileResponse((settings.BASE_DIR/'portal'/filename).open('rb'),content_type=mime+'; charset=utf-8')
