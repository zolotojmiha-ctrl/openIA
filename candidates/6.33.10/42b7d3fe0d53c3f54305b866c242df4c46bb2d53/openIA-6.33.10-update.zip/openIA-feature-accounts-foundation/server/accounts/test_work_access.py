from django.test import TestCase
from django.urls import reverse

from accounts.models import AccessGrant, User
from documents.models import Person
from projects.access import visible_contracts, visible_objects
from projects.models import COMPANY_TAX_ID, Contract, ContractAccess, ContractObject, LegalEntity, ProjectObject


class EmployeeWorkAccessTests(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.leader = User.objects.create_user('+70000261001', leader_slot=1, full_name='Руководитель', must_change_password=False)
        cls.employee = User.objects.create_user('+70000261002', role='foreman', full_name='Мастер', must_change_password=False)
        entity = LegalEntity.objects.get(tax_id=COMPANY_TAX_ID)
        cls.contract = Contract.objects.create(legal_entity=entity, number='РЕМ-01', subject='Устранение дефектов', status='active', work_kinds=['repairs'])
        cls.area = ProjectObject.objects.create(legal_entity=entity, name='Первый участок')
        cls.other_area = ProjectObject.objects.create(legal_entity=entity, name='Второй участок')
        for area in (cls.area, cls.other_area):
            ContractObject.objects.create(contract=cls.contract, project_object=area)
        cls.person = Person.objects.create(legal_entity=entity, full_name='Инженер ПТО', created_by=cls.leader)

    def payload(self, employee=None, **fields):
        return {
            'expected_version': employee.session_version if employee else self.person.revision,
            'full_name': employee.full_name if employee else self.person.full_name,
            'phone': employee.phone if employee else '+70000261003',
            'role': 'foreman', 'profile': 'foreman', 'is_active': 'on',
            'work_scope_present': 'on', 'work_contracts': [self.contract.pk],
            **fields,
        }

    def test_personnel_card_creates_linked_pto_with_role_and_contract(self):
        self.client.force_login(self.leader)
        url = reverse('employee_new') + f'?person={self.person.pk}'
        self.assertContains(self.client.get(reverse('person_detail', args=[self.person.pk])), url)
        self.assertContains(self.client.get(url), 'Где работает сотрудник')
        response = self.client.post(url, self.payload(role='pto', profile='pto'))
        self.assertContains(response, 'Временный доступ создан')

        self.person.refresh_from_db()
        user = self.person.user
        self.assertEqual(user.role, 'pto')
        self.assertTrue(user.grants.filter(permission='repairs.prepare').exists())
        self.assertFalse(user.object_assignments.exists())
        self.assertEqual(list(visible_contracts(user)), [self.contract])
        self.assertCountEqual(visible_objects(user), [self.area, self.other_area])
        self.assertEqual(Person.objects.filter(full_name=self.person.full_name).count(), 1)

    def test_select_and_remove_contract_and_area_from_one_form(self):
        self.client.force_login(self.leader)
        url = reverse('employee_edit', args=[self.employee.pk])
        rejected = self.client.post(url, self.payload(self.employee))
        self.assertContains(rejected, 'Выберите хотя бы один участок')
        self.assertFalse(self.employee.contract_access.exists())

        response = self.client.post(url, self.payload(self.employee, work_areas=[self.area.pk]))
        self.assertRedirects(response, reverse('users'))
        self.assertEqual(list(visible_contracts(self.employee)), [self.contract])
        self.assertEqual(list(visible_objects(self.employee)), [self.area])
        self.assertTrue(self.employee.grants.filter(permission='repairs.report_scope').exists())

        grant = self.employee.contract_access.get()
        grant.show_date = True
        grant.save(update_fields=['show_date'])
        self.employee.refresh_from_db()
        self.client.post(url, self.payload(self.employee, work_areas=[self.other_area.pk]))
        self.assertTrue(self.employee.contract_access.get().show_date)
        self.assertEqual(list(visible_objects(self.employee)), [self.other_area])

        self.employee.refresh_from_db()
        response = self.client.post(url, self.payload(self.employee, work_contracts=[]))
        self.assertRedirects(response, reverse('users'))
        self.assertFalse(visible_contracts(self.employee).exists())
        self.assertFalse(visible_objects(self.employee).exists())

    def test_user_administration_does_not_grant_contracts(self):
        delegate = User.objects.create_user('+70000261004', role='technician', full_name='Администратор', must_change_password=False)
        AccessGrant.objects.create(user=delegate, permission='users.manage', granted_by=self.leader)
        self.client.force_login(delegate)
        url = reverse('employee_edit', args=[self.employee.pk])
        self.assertNotContains(self.client.get(url), 'Где работает сотрудник')
        response = self.client.post(url, self.payload(self.employee, profile='custom', work_areas=[self.area.pk]))
        self.assertRedirects(response, reverse('users'))
        self.assertFalse(ContractAccess.objects.filter(user=self.employee).exists())
        self.assertFalse(self.employee.object_assignments.exists())
