"""Save the existing contract and area grants from an employee's account form."""
from django.core.exceptions import PermissionDenied
from django.db.models import F

from projects.models import Contract, ContractAccess, ObjectAccess, ProjectObject


def save_work_access(actor, employee, data):
    if not data.get('work_scope_present'):
        return {}
    if not actor.is_leader:
        raise PermissionDenied

    changes = {}
    grants = employee.contract_access.all()
    current = set(grants.values_list('contract_id', flat=True))
    desired = {contract.pk for contract in data['work_contracts']}
    added, removed = desired - current, current - desired
    if added or removed:
        contracts = Contract.objects.filter(pk__in=added | removed)
        list(contracts.select_for_update().order_by('pk').values_list('pk', flat=True))
        contracts.update(version=F('version') + 1)
        grants.filter(contract_id__in=removed).delete()
        ContractAccess.objects.bulk_create([
            ContractAccess(user=employee, contract_id=pk, granted_by=actor, show_number=True, show_subject=True)
            for pk in added
        ])
        changes['contracts_added'] = sorted(map(str, added))
        changes['contracts_removed'] = sorted(map(str, removed))

    if employee.role == 'pto':
        return changes

    grants = employee.object_assignments.all()
    current = set(grants.values_list('project_object_id', flat=True))
    desired = {area.pk for area in data['work_areas']}
    added, removed = desired - current, current - desired
    if added or removed:
        areas = ProjectObject.objects.filter(pk__in=added | removed)
        list(areas.select_for_update().order_by('pk').values_list('pk', flat=True))
        areas.update(version=F('version') + 1)
        grants.filter(project_object_id__in=removed).delete()
        ObjectAccess.objects.bulk_create([
            ObjectAccess(user=employee, project_object_id=pk, granted_by=actor) for pk in added
        ])
        changes['areas_added'] = sorted(map(str, added))
        changes['areas_removed'] = sorted(map(str, removed))
    return changes
