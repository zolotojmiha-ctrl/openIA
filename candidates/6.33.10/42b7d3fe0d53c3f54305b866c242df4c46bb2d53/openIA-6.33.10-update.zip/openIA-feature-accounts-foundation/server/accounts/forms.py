from django import forms
from django.contrib.auth.forms import PasswordChangeForm
from .presets import PRESETS
from .models import User, ROLES, PERMISSIONS, normalize_phone

REMEMBER_ME_DAYS = 30


class LoginForm(forms.Form):
    phone=forms.CharField(label='Телефон',max_length=40,widget=forms.TextInput(attrs={'type':'tel','autocomplete':'username','placeholder':'+7 …'}))
    password=forms.CharField(label='Пароль',widget=forms.PasswordInput(attrs={'autocomplete':'current-password'}))
    remember_me = forms.BooleanField(
        label='Запомнить меня',
        required=False,
        help_text=f'Сохранить вход в этом браузере на {REMEMBER_ME_DAYS} дней.',
    )

    def clean_phone(self):
        return normalize_phone(self.cleaned_data['phone'])

class EmployeeForm(forms.Form):
    expected_version=forms.IntegerField(required=False,widget=forms.HiddenInput)
    full_name=forms.CharField(label='Фамилия, имя и отчество',max_length=150)
    phone=forms.CharField(label='Телефон',max_length=40,widget=forms.TextInput(attrs={'type':'tel'}))
    role=forms.ChoiceField(label='Должность',choices=ROLES)
    profile=forms.ChoiceField(label='Набор возможностей',choices=[('custom','Индивидуальная настройка')]+[(k,v['label']) for k,v in PRESETS.items()],required=False,help_text='При выборе профессии подставляется её набор прав.')
    is_active=forms.BooleanField(label='Учётная запись активна',required=False,initial=True)
    permissions=forms.MultipleChoiceField(label='Индивидуальные разрешения',choices=list(PERMISSIONS.items()),required=False,widget=forms.CheckboxSelectMultiple,help_text='Разрешения на просмотр дефектов и отчёты действуют в доступных контрактах и участках.')
    def __init__(self,*args,user=None,actor=None,**kwargs):
        self.edit_user=user
        self.actor=actor
        super().__init__(*args,**kwargs)
        from projects.models import ContractObject,CustomerAccess
        from projects.access import visible_contracts,visible_objects
        if actor and actor.is_leader:
            from projects.scope_widgets import ScopeChecklist
            self.fields['work_scope_present']=forms.BooleanField(required=False,initial=True,widget=forms.HiddenInput)
            self.fields['work_contracts']=forms.ModelMultipleChoiceField(
                label='Контракты',queryset=visible_contracts(actor).order_by('number','pk'),
                required=False,widget=ScopeChecklist,
            )
            self.fields['work_contracts'].label_from_instance=lambda contract: f'{contract.number} · {contract.subject}' + (' · Архив' if contract.status=='archived' else '')
            self.fields['work_areas']=forms.ModelMultipleChoiceField(
                label='Участки',queryset=visible_objects(actor).order_by('name','pk'),
                required=False,widget=ScopeChecklist,
            )
            self.work_area_contracts={}
            for area_id,contract_id in ContractObject.objects.filter(
                project_object__in=self.fields['work_areas'].queryset,
                contract__in=self.fields['work_contracts'].queryset,
            ).values_list('project_object_id','contract_id'):
                self.work_area_contracts.setdefault(str(area_id),[]).append(str(contract_id))
            if user:
                self.initial['work_contracts']=list(user.contract_access.values_list('contract_id',flat=True))
                self.initial['work_areas']=list(user.object_assignments.values_list('project_object_id',flat=True))
        scopes=ContractObject.objects.filter(contract__in=visible_contracts(actor),project_object__in=visible_objects(actor)).select_related('contract','project_object') if actor and actor.is_leader else ContractObject.objects.none()
        self.fields['customer_scopes_present']=forms.BooleanField(required=False,initial=True,widget=forms.HiddenInput)
        self.fields['customer_scopes']=forms.ModelMultipleChoiceField(label='Контракты и участки заказчика',queryset=scopes,required=False,widget=forms.CheckboxSelectMultiple)
        self.fields['customer_scopes'].label_from_instance=lambda s:f'{s.contract.number} · {s.project_object.name}'
        if user and user.role=='customer':
            old=set(CustomerAccess.objects.filter(user=user).values_list('contract_id','project_object_id'))
            self.initial['customer_scopes']=[s.pk for s in scopes if (s.contract_id,s.project_object_id) in old]
        from postoffice.forms import add_request_fields
        add_request_fields(self,actor)
        if actor and not actor.is_leader:
            allowed_profiles=[('custom','Индивидуальная настройка')]+[(k,v['label']) for k,v in PRESETS.items() if k not in ('customer','lessor') and set(v['permissions']).issubset(set(actor.grants.values_list('permission',flat=True)))]
            self.fields['profile'].choices=allowed_profiles
            self.fields['role'].choices=[v for v in ROLES if v[0] not in ('customer','lessor')]
            allowed=set(actor.grants.values_list('permission',flat=True))
            self.fields['permissions'].choices=[(k,v) for k,v in PERMISSIONS.items() if k in allowed]
        if not self.is_bound:
            selected_role=self.initial.get('role') or (user.role if user else next(iter(self.fields['role'].choices))[0])
            self.initial.setdefault('role',selected_role)
            choices={key for key,label in self.fields['profile'].choices}
            current=set(self.initial.get('permissions',user.grants.values_list('permission',flat=True) if user else []))
            self.initial.setdefault('permissions',sorted(current))
            # Existing custom grants are authoritative. Infer a preset only when
            # all of its grants already exist; never grant on an ordinary save.
            default=selected_role if selected_role in choices else 'custom'
            if user and not set(PRESETS.get(default,{}).get('permissions',[])).issubset(current):default='custom'
            self.initial.setdefault('profile',default)
            if not user:self.initial['permissions']=sorted(current|set(PRESETS.get(default,{}).get('permissions',[])))
    def clean(self):
        from postoffice.forms import validate_request
        data=super().clean()
        profile=PRESETS.get(data.get('profile'))
        if profile and data.get('profile')!=data.get('role'):
            raise forms.ValidationError('Набор возможностей не соответствует профессии. Выберите подходящий набор или индивидуальную настройку.')
        if profile:data['permissions']=list(set(data.get('permissions',[]))|set(profile['permissions']))
        if data.get('role')=='lessor':
            if not self.actor or not self.actor.is_leader:raise forms.ValidationError('Арендодателя создаёт руководитель.')
            if data.get('permissions') or data.get('request_mail'):raise forms.ValidationError('Арендодателю не выдаются внутренние права или корпоративная почта.')
        if data.get('role')=='customer':
            if not self.actor or not self.actor.is_leader:raise forms.ValidationError('Заказчика создаёт руководитель.')
            if data.get('permissions') or data.get('request_mail'):raise forms.ValidationError('Заказчику не выдаются внутренние права и корпоративная почта. Выберите набор заказчика без внутренних прав.')
        if data.get('role')!='customer' and data.get('profile')=='customer':raise forms.ValidationError('Набор заказчика применяется только к роли «Заказчик».')
        internal_role=data.get('role') and data['role'] not in ('customer','lessor','subcontractor')
        if not internal_role:
            data['work_scope_present']=False
        if internal_role and data.get('work_scope_present') and data['role']!='pto' and data.get('work_contracts') is not None and data.get('work_areas') is not None:
            from projects.models import ContractObject
            selected={contract.pk:contract for contract in data['work_contracts']}
            linked=set(ContractObject.objects.filter(contract_id__in=selected,project_object__in=data['work_areas']).values_list('contract_id',flat=True))
            existing=set(self.initial.get('work_contracts',[]))
            if self.edit_user and self.edit_user.role in ('customer','lessor','subcontractor','pto'):
                existing=set()
            can_manage_projects='projects.manage' in data.get('permissions',[])
            missing=[contract.number for pk,contract in selected.items() if pk not in linked and pk not in existing and not (can_manage_projects and not contract.objects_linked.exists())]
            if missing:
                self.add_error('work_areas','Выберите хотя бы один участок каждого из этих контрактов: '+', '.join(missing))
        return validate_request(self,data)
    def clean_phone(self):
        phone=normalize_phone(self.cleaned_data['phone'])
        existing=User.objects.filter(phone=phone)
        if self.edit_user:
            existing=existing.exclude(pk=self.edit_user.pk)
        if existing.exists():
            raise forms.ValidationError('Этот телефон уже используется.')
        return phone

class SecurePasswordChangeForm(PasswordChangeForm):
    def clean(self):
        data=super().clean()
        value=data.get('new_password2')
        if value and self.user.check_password(value):
            self.add_error('new_password2','Новый пароль должен отличаться от текущего.')
        return data
