from datetime import timedelta
from uuid import UUID, uuid4

from django.core.exceptions import PermissionDenied, ValidationError
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from documents import timesheets
from documents.models import TimesheetAssignment, TimesheetDay
from .dialog import button, queue

PAGE_SIZE = 7


def menu_buttons(user):
    return [button('Табель', '/табель')] if timesheets.may_open(user) else []


def _save_pending(binding, value=None):
    scope = binding.menu_scope.copy()
    if value is None:
        scope.pop('timesheet_pending', None)
    else:
        scope['timesheet_pending'] = value
    binding.menu_scope = scope
    binding.save(update_fields=['menu_scope'])


def _send(event, binding, text, buttons, people=(), *, settings=False, day=None):
    queue(event, text, buttons, binding=binding, scope={
        'timesheet': {'people': [str(pk) for pk in people], 'settings': settings, 'date': day.isoformat() if day else ''},
    })


def delivery_allowed(binding, scope):
    try:
        user = binding.user
        if scope['settings']:
            people = timesheets.directory(user)
        elif scope['date']:
            people = timesheets.for_date(user, timesheets.parse_date(scope['date']))
        else:
            return timesheets.may_open(user)
        ids = set(scope['people'])
        return {str(pk) for pk in people.filter(pk__in=ids).values_list('pk', flat=True)} == ids
    except (PermissionDenied, ValidationError, KeyError, TypeError):
        return False


def _page(queryset, page, prefix):
    if not 0 <= page <= 10000:
        raise ValidationError('Откройте табель заново.')
    offset = page * PAGE_SIZE
    people = list(queryset[offset:offset + PAGE_SIZE + 1])
    buttons = [button('← Назад', f'{prefix}{page - 1}')] if page else []
    if len(people) > PAGE_SIZE:
        buttons.append(button('Далее →', f'{prefix}{page + 1}'))
    return people[:PAGE_SIZE], buttons


def _day_list(event, binding, day, page=0):
    today = timezone.localdate()
    if day > today:
        raise ValidationError('Выберите сегодняшнюю или прошедшую дату.')
    people, navigation = _page(timesheets.for_date(binding.user, day), page, f'ts:day:{day}:')
    marks = dict(TimesheetDay.objects.filter(date=day, person__in=people).values_list('person_id', 'mark'))
    labels = dict(TimesheetDay.Mark.choices)
    buttons = [button(f'{person.full_name} · {labels.get(marks.get(person.pk), "—")}', f'ts:person:{person.pk}:{day}')
               for person in people]
    if day > day.min:
        navigation.append(button('Предыдущий день', f'ts:day:{day - timedelta(days=1)}:0'))
    if day < today:
        navigation.append(button('Следующий день', f'ts:day:{day + timedelta(days=1)}:0'))
    if binding.user.is_leader:
        navigation.append(button('Настроить табель', 'ts:settings:0'))
    text = f'Табель · {day:%d.%m.%Y}'
    if not people:
        text += '\nСотрудников пока нет.'
    _send(event, binding, text, buttons + navigation + [button('Меню', '/меню')],
          [person.pk for person in people], day=day)


def _select_user(queryset, pk):
    row = queryset.filter(pk=pk).first()
    if row is None:
        raise PermissionDenied
    return row


def _preview(event, binding, person, payload, text, day=None):
    nonce = uuid4().hex
    _save_pending(binding, {**payload, 'person': str(person.pk), 'nonce': nonce,
                            'expires': (timezone.now() + timedelta(minutes=15)).isoformat()})
    _send(event, binding, text, [button('Подтвердить', f'ts:save:{nonce}'), button('Отменить', f'ts:cancel:{nonce}')],
          [person.pk], settings=day is None, day=day)


def _finish(event, binding, action, nonce):
    pending = binding.menu_scope.get('timesheet_pending', {})
    expires = parse_datetime(pending.get('expires', ''))
    if pending.get('nonce') != nonce or not expires or expires <= timezone.now():
        raise ValidationError('Подтверждение устарело. Откройте /табель.')
    if action == 'cancel':
        _save_pending(binding)
        _send(event, binding, 'Отменено.', [button('Табель', '/табель')])
        return
    if 'date' in pending:
        day = timesheets.parse_date(pending['date'])
        timesheets.record(binding.user, pending['person'], day, pending['mark'],
                          pending['version'], pending['assignment_version'])
        _save_pending(binding)
        _day_list(event, binding, day)
    else:
        owner = UUID(pending['responsible']) if pending['responsible'] else None
        timesheets.configure(binding.user, pending['person'], owner, pending['version'])
        _save_pending(binding)
        _send(event, binding, 'Настройки табеля сохранены.', [button('Табель', '/табель')], settings=True)


def handle(event, binding):
    text = event.payload.get('text', '').strip()
    if text != '/табель' and not text.startswith(('/табель ', 'ts:')):
        return False
    if not timesheets.may_open(binding.user):
        raise PermissionDenied
    if text.startswith('/табель'):
        parts = text.split(maxsplit=1)
        _day_list(event, binding, timesheets.parse_date(parts[1]) if len(parts) > 1 else timezone.localdate())
        return True

    _, action, *args = text.split(':')
    user = binding.user
    if action == 'day':
        _day_list(event, binding, timesheets.parse_date(args[0]), int(args[1]))
    elif action in ('person', 'mark'):
        person_id, date_text, *extra = args
        day = timesheets.parse_date(date_text)
        person = _select_user(timesheets.for_date(user, day), person_id)
        entry = TimesheetDay.objects.filter(person=person, date=day).first()
        assignment = TimesheetAssignment.objects.filter(person=person, responsible__isnull=False).first()
        editable = assignment and not person.archived and day <= timezone.localdate()
        if action == 'person':
            buttons = [button(label, f'ts:mark:{person.pk}:{day}:{mark}') for mark, label in TimesheetDay.Mark.choices] if editable else []
            label = entry.get_mark_display() if entry else 'Отметки пока нет'
            _send(event, binding, f'{person.full_name} · {day:%d.%m.%Y}\n{label}',
                  buttons + [button('К списку', f'ts:day:{day}:0')], [person.pk], day=day)
        else:
            if not editable:
                raise PermissionDenied
            mark = TimesheetDay.Mark(extra[0])
            _preview(event, binding, person, {'date': str(day), 'mark': mark, 'version': entry.version if entry else 0,
                                             'assignment_version': assignment.version},
                     f'{person.full_name} · {day:%d.%m.%Y}\n{mark.label}', day=day)
    elif action == 'settings':
        people, navigation = _page(timesheets.directory(user).order_by('full_name', 'pk'), int(args[0]), 'ts:settings:')
        buttons = [button(person.full_name, f'ts:owners:{person.pk}:0') for person in people]
        _send(event, binding, 'Выберите сотрудника.', buttons + navigation + [button('Табель', '/табель')],
              [person.pk for person in people], settings=True)
    elif action in ('owners', 'assign'):
        person = _select_user(timesheets.directory(user).select_related('user'), args[0])
        assignment = TimesheetAssignment.objects.filter(person=person).select_related('responsible').first()
        candidates = timesheets.eligible(person)
        if action == 'owners':
            users, navigation = _page(candidates, int(args[1]), f'ts:owners:{person.pk}:')
            buttons = [button(owner.full_name, f'ts:assign:{person.pk}:{owner.pk}') for owner in users]
            label = assignment.responsible.full_name if assignment and assignment.responsible_id else 'Табель выключен'
            if assignment and assignment.responsible_id:
                buttons.append(button('Выключить табель', f'ts:assign:{person.pk}:off'))
            _send(event, binding, f'{person.full_name}\n{label}\nВыберите ответственного.',
                  buttons + navigation + [button('К списку', 'ts:settings:0')], [person.pk], settings=True)
        else:
            owner = _select_user(candidates, args[1]) if args[1] != 'off' else None
            label = f'Ответственный · {owner.full_name}' if owner else 'Выключить табель'
            _preview(event, binding, person, {'responsible': str(owner.pk) if owner else '',
                                             'version': assignment.version if assignment else 0},
                     f'{person.full_name}\n{label}')
    elif action in ('save', 'cancel'):
        _finish(event, binding, action, args[0])
    else:
        raise ValidationError('Откройте табель заново.')
    return True
