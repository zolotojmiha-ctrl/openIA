> Подпись получена. [Команды установки](INSTALL_6_33_7.md).

# Подпись 6.33.7 владельцем

Запустите команду в обычном терминале Mac. Она скачивает проверенный кандидат из GitHub и запрашивает прежний ключ подписи на вашем компьютере.

```bash
bash <<'SIGN'
set -euo pipefail
if [[ "$(uname -s)" != Darwin || "$EUID" -eq 0 ]]; then
  echo 'Запустите в обычном терминале Mac.' >&2
  exit 1
fi
umask 077
mkdir -p "$HOME/Downloads"
work=$(mktemp -d "$HOME/Downloads/armada-6.33.7-sign.XXXXXX")
url='https://api.github.com/repos/zolotojmiha-ctrl/openIA/contents/candidates/6.33.7/5f1a8daf36390a8e39407d65403fed81340c28f5'
ref='c323130147013ddcd5b66a4f9605dd26fe609d4e'
for name in openIA-6.33.7-update.zip install-6.33.7.sh openIA-6.33.7-update.json signing-helper-6.33.7.zip; do
  curl --http1.1 --tlsv1.2 --tls-max 1.2 -fsSL --retry 2 \
    -H 'Accept: application/vnd.github.raw+json' \
    --output "$work/$name" "$url/$name?ref=$ref"
done
(cd "$work" && shasum -a 256 -c) <<'SHA'
a15281138fc4391e968f73779854b695e6afe2b7077d20d9cc11293e37f4a029  openIA-6.33.7-update.zip
c4ccbc1b38f3207172f2bc99b14d1a98997bd8a1c9f4b6ed84c6a254e11e084e  install-6.33.7.sh
cc97983fc47e7d5b47972b584fd7c4e4e1438df134d6244ed0e83efcce105299  openIA-6.33.7-update.json
bb3ef689d56526005ca9ad1806a17cc11b852de4fc8e35f28ed0cfb06d84bb80  signing-helper-6.33.7.zip
SHA
unzip -q "$work/signing-helper-6.33.7.zip" -d "$work/helper"
python3 "$work/helper/owner_sign_6337.py" --directory "$work" \
  --archive-sha a15281138fc4391e968f73779854b695e6afe2b7077d20d9cc11293e37f4a029 \
  --installer-sha c4ccbc1b38f3207172f2bc99b14d1a98997bd8a1c9f4b6ed84c6a254e11e084e \
  --source 5f1a8daf36390a8e39407d65403fed81340c28f5
SIGN
```

Передайте публичный файл `armada-6.33.7-public-signatures.zip`, путь к которому напечатает команда.
