# Установка подписанной 6.33.9

25 ноября 2026 года владелец подтвердил установку на VPS. Данные и настройки сохранены, MAX-worker возобновлён. Ниже команды этого выпуска.

Подписанный пакет опубликован в коммите `cc5a66859500754e630a880569b339e83ff567f8`. После скачивания проверены обе подписи, контрольные суммы и публичный ключ резервирования. Архив приложения и установщик совпадают с проверенным кандидатом.

В терминале Mac подключитесь к VPS.

```bash
ssh -o UseKeychain=yes -o IdentitiesOnly=yes -o PasswordAuthentication=no -i ~/.ssh/armada_beget root@185.23.35.28
```

После появления приглашения `root@…:~#` вставьте в терминал VPS весь блок.

```bash
bash <<'VPS'
set -euo pipefail

if [[ "$(uname -s)" != "Linux" || "$EUID" -ne 0 ]]; then
  echo 'Эту команду нужно выполнить на VPS от root, после подключения по SSH.' >&2
  exit 1
fi

test -f /opt/armada/deploy/beget/compose.yml
armada_trust='/root/armada-6.32.0/armada-release-signing.public.pem'
test -f "$armada_trust"
armada_fingerprint=$(openssl pkey -pubin -in "$armada_trust" -outform DER | sha256sum | awk '{print $1}')
[[ "$armada_fingerprint" == 'e2f6b26419ccb10faa61baf1cfb5a0ea53f499da8803f23f0dd0df3f420aa3e4' ]]

umask 077
armada_work=$(mktemp -d /root/armada-6.33.9.XXXXXX)
armada_url='https://raw.githubusercontent.com/zolotojmiha-ctrl/openIA'
armada_ref='cc5a66859500754e630a880569b339e83ff567f8'
for name in armada-6.33.9.zip armada-6.33.9.zip.sig; do
  curl --http1.1 --tlsv1.2 -fsSL --retry 3 \
    -H 'Accept: application/vnd.github.raw+json' \
    --output "$armada_work/$name" "$armada_url/$armada_ref/$name"
done

printf '%s\n' '402c9975ce76a38f1ec56a4d4f5d2b7a0c7f211c4610d704d9ee6b0737b9adf5  armada-6.33.9.zip' | (cd "$armada_work" && sha256sum -c -)
openssl dgst -sha256 -verify "$armada_trust" -signature "$armada_work/armada-6.33.9.zip.sig" "$armada_work/armada-6.33.9.zip"

unzip -q "$armada_work/armada-6.33.9.zip" -d "$armada_work"
armada_release="$armada_work/armada-6.33.9"
(
  cd "$armada_release"
  openssl dgst -sha256 -verify "$armada_trust" -signature SHA256SUMS-6.33.9.sig SHA256SUMS-6.33.9
  sha256sum -c SHA256SUMS-6.33.9
  printf '%s\n' 'ed88e924d64fa785d343907855b0245b2a01c932cfdb28a44ff3490e77aa31a4  backup-recovery.public.pem' | sha256sum -c -
)

ARMADA_APP_ROOT=/opt/armada \
ARMADA_RELEASE_PUBLIC_KEY="$armada_trust" \
ARMADA_BACKUP_PUBLIC_KEY="$armada_release/backup-recovery.public.pem" \
bash "$armada_release/install-6.33.9.sh"
VPS
```

Подтверждением установки служит итоговая строка «Обновление 6.33.9 установлено».
