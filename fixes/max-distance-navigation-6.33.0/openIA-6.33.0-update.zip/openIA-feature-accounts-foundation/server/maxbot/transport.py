"""MAX transport: fixed API origin, bounded bodies, no secret in file requests."""
import io
import ipaddress
import json
import socket
import ssl
import warnings
from pathlib import Path
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler, HTTPSHandler
from django.conf import settings
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from PIL import Image, ImageOps, UnidentifiedImageError

API = 'https://platform-api2.max.ru'
API_CA_FILE = Path('/run/armada/max-api-ca.pem')


class DeliveryError(Exception):
    def __init__(self, state='unknown', retry_after=None):
        self.state = state
        self.retry_after = retry_after


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def api_ssl_context():
    """Additional operator-provided CA applies only to the fixed MAX API."""
    context = ssl.create_default_context()
    if API_CA_FILE.exists():
        context.load_verify_locations(cafile=str(API_CA_FILE))
    return context


def api(method, path, body=None):
    if not settings.ARMADA_MAX_TOKEN:
        raise DeliveryError('failed')
    request = Request(API + path, data=json.dumps(body).encode() if body is not None else None,
                      headers={'Authorization': settings.ARMADA_MAX_TOKEN, 'Content-Type': 'application/json'}, method=method)
    try:
        with build_opener(NoRedirect(), HTTPSHandler(context=api_ssl_context())).open(request, timeout=15) as response:
            result = response.read(1024 * 1024 + 1)
            if len(result) > 1024 * 1024:
                raise DeliveryError()
            return json.loads(result)
    except HTTPError as exc:
        # A timeout/5xx may mean MAX accepted the message: never retry blindly.
        retry_after = None
        if exc.code == 429:
            value = exc.headers.get('Retry-After', '') if exc.headers else ''
            try:
                retry_after = max(0, min(86400, int(value)))
            except (ValueError, TypeError):
                try:
                    date = parsedate_to_datetime(value)
                    retry_after = max(0, min(86400, int((date - datetime.now(timezone.utc)).total_seconds())))
                except (ValueError, TypeError, OverflowError):
                    pass
        raise DeliveryError('pending' if exc.code == 429 else 'failed' if 400 <= exc.code < 500 else 'unknown', retry_after) from None
    except (OSError, URLError, ValueError):
        raise DeliveryError() from None


def send(chat, body):
    if body.get('_callback_id'):
        result = api('POST', '/answers?' + urlencode({'callback_id': body['_callback_id']}),
                     {'notification': body['notification']})
        if not isinstance(result, dict) or result.get('success') is not True:
            raise DeliveryError()
        return
    result = api('POST', '/messages?' + urlencode({'chat_id': chat}), body)
    if not isinstance(result, dict) or not result.get('message', {}).get('body', {}).get('mid'):
        raise DeliveryError()


def attachment_bytes(url,hosts):
    """Bounded credential-free HTTPS fetch; the configured CDN allowlist is shared."""
    if not isinstance(url,str) or len(url)>4000:
        raise ValidationError('Недопустимый адрес вложения.')
    try:
        parsed=urlsplit(url)
        if not (parsed.scheme=='https' and parsed.hostname in hosts and parsed.port in (None,443)
                and not parsed.username and not parsed.password and not parsed.fragment):raise ValueError
        addresses=socket.getaddrinfo(parsed.hostname,443,type=socket.SOCK_STREAM)
        if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):raise ValueError
    except (ValueError,OSError):
        raise ValidationError('Источник вложения ещё не разрешён. Сообщите администратору домен источника; черновик сохранён.') from None
    try:
        with build_opener(NoRedirect()).open(Request(url),timeout=10) as response:
            content=response.read(10*1024*1024+1)
        if not content or len(content)>10*1024*1024:raise ValueError
        return content
    except (OSError,URLError,ValueError):
        raise ValidationError('Не удалось загрузить вложение. Повторите отправку; размер файла — до 10 МБ.') from None


def download_file(url,filename):
    if not isinstance(filename,str) or not filename.strip() or len(filename)>512:
        raise ValidationError('У файла должно быть название.')
    content=attachment_bytes(url,getattr(settings,'ARMADA_MAX_FILE_HOSTS',()) or settings.ARMADA_MAX_PHOTO_HOSTS)
    return SimpleUploadedFile(filename,content)


def download_photo(url):
    """Images retain decoding and WEBP conversion checks after the same safe fetch."""
    content=attachment_bytes(url,settings.ARMADA_MAX_PHOTO_HOSTS)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error', Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(content)) as image:
                if image.format not in ('PNG', 'JPEG', 'WEBP'):
                    raise ValueError
                webp = image.format == 'WEBP'
                if webp and getattr(image, 'n_frames', 1) != 1:
                    raise ValueError
                if image.width * image.height > 16_000_000 or max(image.size) > 8000:
                    raise ValueError
                suffix = 'png' if image.format == 'PNG' else 'jpg'
                image.verify()
            with Image.open(io.BytesIO(content)) as image:
                image.load()
                if webp:
                    # MAX may transcode an ordinary photograph to WEBP. Keep the
                    # existing private attachment contract by storing a JPEG.
                    ImageOps.exif_transpose(image, in_place=True)
                    if 'A' in image.getbands():
                        converted = Image.new('RGB', image.size, 'white')
                        with image.getchannel('A') as alpha:
                            converted.paste(image, mask=alpha)
                    else:
                        converted = image.convert('RGB')
                    try:
                        with io.BytesIO() as output:
                            converted.save(output, format='JPEG', quality=92)
                            if output.tell() > 10 * 1024 * 1024:
                                raise ValueError
                            content = output.getvalue()
                    finally:
                        converted.close()
                    suffix = 'jpg'
    except (OSError, ValueError, SyntaxError, UnidentifiedImageError, Image.DecompressionBombWarning, Image.DecompressionBombError):
        raise ValidationError('Фото не удалось загрузить или проверить. Повторите отправку фотографии.') from None
    return SimpleUploadedFile('photo.' + suffix, content, content_type='image/' + ('png' if suffix == 'png' else 'jpeg'))
