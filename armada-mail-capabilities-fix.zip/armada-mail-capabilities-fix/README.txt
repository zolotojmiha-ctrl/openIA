АРМАДА — возможности IMAP после LOGIN
Исходник: 04d389c6e2abfb5748e82a7bc4421c3650e64597
Поверх установленного mail-sharing-fix. Без миграций.
Проверить SHA-256 и подпись перед запуском.
ARMADA_APP_ROOT=/opt/armada bash /root/armada-mail-capabilities-fix/install.sh
Проверка --require-trash не должна сообщать успех при неподтверждённом результате.
