#!/usr/bin/env bash
# ARMADA 6.32.0. Existing installation only. No data reset or implicit MAX activation.
set -euo pipefail
umask 077
app_root=${ARMADA_APP_ROOT:-/opt/armada/openIA-feature-accounts-foundation}
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)
if (( EUID != 0 )); then printf 'Запустите установщик от root.\n' >&2; exit 1; fi
for command_name in curl sha256sum unzip docker flock df awk python3 openssl; do
  command -v "$command_name" >/dev/null || { printf 'Не найдена команда: %s\n' "$command_name" >&2; exit 1; }
done
python3 -c 'import sys; assert sys.version_info >= (3,9)' || { printf 'Требуется Python 3.9 или новее.\n' >&2; exit 1; }
if [[ -L "$app_root" || ! -f "$app_root/deploy/beget/compose.yml" || ! -f "$app_root/deploy/beget/backup.sh" || ( $(basename -- "$app_root") != openIA-feature-accounts-foundation && $(basename -- "$app_root") != armada ) ]]; then
  printf 'Не найден штатный каталог существующей установки: %s\n' "$app_root" >&2; exit 1
fi
docker compose version >/dev/null
docker info >/dev/null
exec 9>"$app_root/.armada-update.lock"
flock -n 9 || { printf 'Другое обновление уже выполняется.\n' >&2; exit 1; }
cd -- "$app_root"
compose=(docker compose -f "$app_root/deploy/beget/compose.yml")
# Read the actual running image, without importing settings or displaying secrets.
version_code='import ast,pathlib; tree=ast.parse(pathlib.Path("/app/server/accounts/context.py").read_text()); versions=[v.value for n in ast.walk(tree) if isinstance(n,ast.Dict) for k,v in zip(n.keys,n.values) if isinstance(k,ast.Constant) and k.value=="release_version" and isinstance(v,ast.Constant)]; assert len(versions)==1; print(versions[0])'
installed=$("${compose[@]}" exec -T web python -c "$version_code")
case "$installed" in
  6.25.0|6.25.1|6.26.0|6.27.0|6.28.0|6.29.0|6.30.0|6.31.0|6.32.0) ;;
  *) printf 'Версия работающего приложения не поддержана или не определена. Сначала проверьте восстановленную установку.\n' >&2; exit 1;;
esac
for target in "$app_root" /tmp; do
  available_kb=$(df -Pk -- "$target" | awk 'NR==2 {print $4}')
  if [[ ! "$available_kb" =~ ^[0-9]+$ ]] || (( available_kb < 2097152 )); then
    printf 'Для безопасной сборки нужно минимум 2 ГБ свободного места: %s\n' "$target" >&2; exit 1
  fi
done
staging=$(mktemp -d /tmp/armada-update-6.32.0.XXXXXX)
# EXIT also handles explicit failures, not only commands triggering ERR.
recovery=
phase=prepare
original_web_id=
original_web_tag=
switched=0
completed=0
finish() {
  status=$?
  trap - EXIT INT TERM
  if (( completed == 0 )) && [[ -n "$recovery" ]]; then
    set +e
    if [[ "$phase" == migrations || "$phase" == verify ]]; then
      if ! "${compose[@]}" --profile max stop web mailworker maxworker; then
        printf 'Не удалось подтвердить остановку: проверьте Docker и вручную остановите писателей.\n' >&2
      fi
      printf 'Установка остановлена после начала миграций. Подана команда остановки всех писателей.\nИнструкция: %s/RECOVERY.md\n' "$recovery" >&2
    elif [[ -f "$recovery/writers" ]]; then
      if (( switched )); then
        "${compose[@]}" --profile max stop web mailworker maxworker
        python3 "$package_root/deploy/beget/switch_tree.py" rollback --app "$app_root" --recovery "$recovery"
        cd -- "$app_root"
      fi
      if [[ "$original_web_tag" == armada-web:6.32.0 && -n "$original_web_id" ]]; then
        docker image tag "$original_web_id" "$original_web_tag"
      fi
      original=()
      while IFS= read -r service; do [[ -z "$service" ]] || original+=("$service"); done < "$recovery/writers"
      if (( ${#original[@]} )); then
        rollback_compose=("${compose[@]}" -f "$recovery/images.json" --profile max)
        "${rollback_compose[@]}" up -d --no-build --no-deps --force-recreate web
        restore_status=$?
        old_healthy=0
        if (( restore_status == 0 )); then
          for attempt in {1..30}; do
            cid=$("${rollback_compose[@]}" ps -q web)
            if [[ -n "$cid" && $(docker inspect --format '{{.State.Health.Status}}' "$cid") == healthy ]]; then old_healthy=1; break; fi
            sleep 2
          done
        fi
        if (( old_healthy )); then
          "${rollback_compose[@]}" exec -T web python server/manage.py check &&
          "${rollback_compose[@]}" exec -T web python server/manage.py migrate --check
          restore_status=$?
        else restore_status=1; fi
        if (( restore_status == 0 )); then
          resumed=()
          for service in "${original[@]}"; do [[ "$service" == web ]] || resumed+=("$service"); done
          if (( ${#resumed[@]} )); then
            "${rollback_compose[@]}" up -d --no-build --no-deps --force-recreate "${resumed[@]}"
            restore_status=$?
          fi
        fi
        if (( restore_status == 0 )); then printf 'До миграций: прежнее приложение проверено, службы возобновлены.\n' >&2
        else
          "${rollback_compose[@]}" stop "${original[@]}"
          printf 'Автовозврат не подтверждён; писатели остановлены. См. %s/RECOVERY.md\n' "$recovery" >&2
        fi
      fi
    fi
  fi
  rm -rf -- "$staging"
  if (( completed == 0 && status == 0 )); then status=1; fi
  exit "$status"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
archive_path=${ARMADA_UPDATE_ARCHIVE:-}
if [[ -z "$archive_path" && -f "$script_dir/openIA-6.32.0-update.zip" ]]; then
  archive_path="$script_dir/openIA-6.32.0-update.zip"
fi
if [[ -n "$archive_path" ]]; then
  [[ -f "$archive_path" ]] || { printf 'Архив не найден.\n' >&2; exit 1; }
  cp -- "$archive_path" "$staging/update.zip"
else
  curl --fail --location --retry 3 --output "$staging/update.zip" 'https://github.com/zolotojmiha-ctrl/openIA/raw/refs/heads/downloads/nas-updates/openIA-6.32.0-update.zip'
fi
# Trust anchor belongs to the operator, not to the downloaded archive.
trust_key=${ARMADA_RELEASE_PUBLIC_KEY:-/etc/armada/release-signing-public.pem}
[[ -f "$trust_key" && ! -L "$trust_key" ]] || { printf 'Нет независимого доверенного ключа подписи. Установка запрещена.\n' >&2; exit 1; }
python3 - "$trust_key" <<'PY'
import os,stat,sys
s=os.stat(sys.argv[1]);assert s.st_uid==0 and not s.st_mode & 0o022,'Trust key must be root-owned and not writable by others'
PY
for artifact in SHA256SUMS-6.32.0 SHA256SUMS-6.32.0.sig openIA-6.32.0-update.json; do
  if [[ -f "$script_dir/$artifact" ]]; then
    cp -- "$script_dir/$artifact" "$staging/$artifact"
  else
    curl --fail --location --retry 3 --output "$staging/$artifact" "https://github.com/zolotojmiha-ctrl/openIA/raw/refs/heads/downloads/nas-updates/$artifact"
  fi
done
openssl dgst -sha256 -verify "$trust_key" -signature "$staging/SHA256SUMS-6.32.0.sig" "$staging/SHA256SUMS-6.32.0" >/dev/null 2>&1 || { printf 'Подпись выпуска не подтверждена. Установка запрещена.\n' >&2; exit 1; }
python3 - "$staging" "${BASH_SOURCE[0]}" <<'PY'
import hashlib,json,pathlib,re,sys
root=pathlib.Path(sys.argv[1]);rows={}
for line in (root/'SHA256SUMS-6.32.0').read_text().splitlines():
    m=re.fullmatch(r'([0-9a-f]{64})  ([A-Za-z0-9_.-]+)',line)
    assert m and m[2] not in rows,'Invalid signed manifest';rows[m[2]]=m[1]
files={'openIA-6.32.0-update.zip':root/'update.zip','install-6.32.0.sh':pathlib.Path(sys.argv[2]),'openIA-6.32.0-update.json':root/'openIA-6.32.0-update.json'}
assert set(rows)==set(files),'Unexpected signed manifest contents'
for name,path in files.items():assert hashlib.sha256(path.read_bytes()).hexdigest()==rows[name],'Signed artifact mismatch'
assert rows['openIA-6.32.0-update.zip']=='d1cc7a6a169bd9c7ea5d27eb6c063bf00716c8310f6d74577f9faf762f2c58e5','Archive differs from installer'
meta=json.loads(files['openIA-6.32.0-update.json'].read_text())
assert meta.get('version')=='6.32.0' and meta.get('ready_for_install') is True,'Release is not validated'
assert re.fullmatch('[0-9a-f]{40}',meta.get('source_commit','')),'Source commit missing'
PY
unzip -tq "$staging/update.zip"
python3 - "$staging/update.zip" <<'PY'
import ast,stat,sys,zipfile
from pathlib import PurePosixPath
prefix='openIA-feature-accounts-foundation/'
with zipfile.ZipFile(sys.argv[1]) as z:
    names=z.namelist()
    assert names and len(set(names))==len(names),'Duplicate or empty archive'
    for item in z.infolist():
        name=item.filename; parts=PurePosixPath(name).parts
        assert name.startswith(prefix) and '\\' not in name and '..' not in parts,'Unsafe archive path'
        assert not stat.S_ISLNK(item.external_attr>>16),'Archive symlink'
        assert not any(p in ('.git','.runtime','__pycache__','.env') for p in parts),'Private runtime file'
    required=['index.html','server/config/settings.py','server/accounts/context.py','deploy/synology/Dockerfile','deploy/beget/compose.yml','deploy/beget/backup.sh','deploy/beget/switch_tree.py']
    assert all(prefix+n in names for n in required),'Missing package file'
    tree=ast.parse(z.read(prefix+'server/accounts/context.py').decode())
    versions=[v.value for n in ast.walk(tree) if isinstance(n,ast.Dict) for k,v in zip(n.keys,n.values) if isinstance(k,ast.Constant) and k.value=='release_version' and isinstance(v,ast.Constant)]
    assert versions==['6.32.0'],'Wrong package version'
PY
unzip -oq "$staging/update.zip" -d "$staging/source"
package_root="$staging/source/openIA-feature-accounts-foundation"
original_web_container=$("${compose[@]}" ps -q web)
original_web_id=$(docker inspect --format '{{.Image}}' "$original_web_container")
original_web_tag=$(docker inspect --format '{{.Config.Image}}' "$original_web_container")
printf 'Собираем 6.32.0 до остановки работающего приложения.\n'
docker build -f "$package_root/deploy/synology/Dockerfile" -t armada-web:6.32.0 "$package_root"
# Scheduled Disk jobs must not be claimed while web is stopped: holding only
# backup.lock would allow a job to be claimed and stranded during maintenance.
backup_root=${ARMADA_BACKUP_DIR:-/var/backups/armada}
[[ "$backup_root" == /* ]] || { printf 'Каталог копий должен быть абсолютным.\n' >&2; exit 2; }
mkdir -p -- "$backup_root"
chmod 700 -- "$backup_root"
exec 7>"$backup_root/.disk-worker.lock"
flock -n 7 || { printf 'Обработчик резервирования занят. Повторите после его завершения.\n' >&2; exit 1; }
exec 8>"$backup_root/.backup.lock"
flock -n 8 || { printf 'Резервирование занято; обновление не начато.\n' >&2; exit 1; }
# Private recovery state is durable even after an interrupted installer.
recovery=$(mktemp -d "$(dirname -- "$app_root")/.armada-recovery-6.32.0.XXXXXX")
printf '%s\n' "$installed" > "$recovery/previous-version"
printf 'До миграций: проверить running/images.json/writers/backup.log. Не удалять тома. При неудачном автовозврате вручную остановить писателей и вернуть прежнее дерево/image ID.\n' > "$recovery/RECOVERY.md"
# Save exact image IDs for the running services (not mutable tag names).
declared=$("${compose[@]}" --profile max config --services)
previous_services=()
while IFS= read -r service; do
  case "$service" in web|mailworker|maxworker|proxy) previous_services+=("$service");; esac
done <<< "$declared"
"${compose[@]}" --profile max ps --services --status running "${previous_services[@]}" > "$recovery/running"
python3 - "$recovery/running" "$recovery/images.json" "${compose[@]}" <<'PY'
import json,subprocess,sys
services={}
for name in open(sys.argv[1]).read().splitlines():
    if name not in ('web','mailworker','maxworker','proxy'):raise ValueError('Unexpected service')
    cid=subprocess.check_output(sys.argv[3:]+['--profile','max','ps','-q',name],text=True).strip()
    image=subprocess.check_output(['docker','inspect','--format','{{.Image}}',cid],text=True).strip()
    if not image.startswith('sha256:'):raise ValueError('Missing image ID')
    services[name]={'image':image}
with open(sys.argv[2],'x') as f:json.dump({'services':services},f)
PY
printf 'Создаём копию без промежуточного возобновления записи.\n'
bash "$package_root/deploy/beget/backup.sh" --hold-writers --compose-file "$app_root/deploy/beget/compose.yml" --state-file "$recovery/writers" --lock-fd 8 > "$recovery/backup.log" 2>&1
# This checkpoint includes private .env; never upload recovery directories.
python3 "$package_root/deploy/beget/switch_tree.py" prepare --source "$package_root" --app "$app_root" --recovery "$recovery"
python3 - "$recovery" "$app_root" <<'PY'
import pathlib,sys
r=pathlib.Path(sys.argv[1]);app=sys.argv[2]
lines=(r/'backup.log').read_text().splitlines()
archives=[line.removeprefix('Backup saved: ') for line in lines if line.startswith('Backup saved: ')]
if len(archives)!=1 or not pathlib.Path(archives[0]).is_file():raise ValueError('Backup missing')
(r/'archive').write_text(archives[0]+'\n')
(r/'RECOVERY.md').write_text("""# Восстановление после неуспешного обновления

1. Не запускать прежний web поверх изменённой схемы. Остановить web/mailworker/maxworker, таймер и службу armada-disk-backup. Проверить, что посторонних писателей нет.
2. Сохранить текущее состояние отдельно для расследования. Каталог recovery содержит .env/закрытые настройки: не публиковать его.
3. В файле archive указан точный предустановочный архив. Если он зашифрован, расшифровать на доверенной машине закрытым ключом восстановления; ключ не копировать на VPS.
4. Проверить SHA256SUMS внутри архива и выполнить пробное восстановление в отдельную временную БД/тома, включая файлы и ключи. Инструкция deploy/beget/README.md прежнего дерева и docs/YANDEX_DISK_BACKUPS.md описывает восстановление полного архива. Не выполнять down -v.
5. После проверки восстановить предустановочные БД, config и documents вместе; вернуть дерево tree и прежние image ID из images.json. Только затем запустить web и проверить версию, migrate --check, документы и данные. Включать почту и MAX после отдельной проверки; MAX только если был включён прежде.

Точное расположение приложения: """+app+'\nТочный архив: '+archives[0]+'\n')
PY
max_was_running=0
while IFS= read -r service; do
  if [[ "$service" == maxworker ]]; then max_was_running=1; fi
done < "$recovery/writers"
switched=1
python3 "$package_root/deploy/beget/switch_tree.py" switch --app "$app_root" --recovery "$recovery"
cd -- "$app_root"
# Check configuration before crossing the irreversible migration barrier.
"${compose[@]}" config --quiet
phase=migrations
printf 'migrations\n' > "$recovery/phase"
"${compose[@]}" run --rm --no-deps -T --entrypoint python web server/manage.py migrate --noinput
"${compose[@]}" run --rm --no-deps -T --entrypoint python web server/manage.py check
"${compose[@]}" run --rm --no-deps -T --entrypoint python web server/manage.py migrate --check
phase=verify
"${compose[@]}" up -d --no-build --no-deps web mailworker
"${compose[@]}" up -d --no-build --no-deps --force-recreate proxy
healthy=0
for attempt in {1..90}; do
  web_id=$("${compose[@]}" ps -q web)
  worker_id=$("${compose[@]}" ps -q mailworker)
  proxy_id=$("${compose[@]}" ps -q proxy)
  if [[ -n "$web_id" && -n "$worker_id" && -n "$proxy_id" ]] &&
     [[ $(docker inspect --format '{{.State.Health.Status}}' "$web_id") == healthy ]] &&
     [[ $(docker inspect --format '{{.State.Running}}' "$worker_id") == true ]] &&
     [[ $(docker inspect --format '{{.State.Running}}' "$proxy_id") == true ]]; then healthy=1; break; fi
  sleep 2
done
if (( healthy == 0 )); then
  "${compose[@]}" ps
  printf 'Не подтверждён запуск сайта, почтового процесса или прокси. MAX-worker не запускался.\n' >&2; exit 1
fi
"${compose[@]}" exec -T web python server/manage.py check
"${compose[@]}" exec -T web python server/manage.py migrate --check
actual=$("${compose[@]}" exec -T web python -c "$version_code")
[[ "$actual" == 6.32.0 ]] || { printf 'Работающий контейнер не подтвердил 6.32.0.\n' >&2; exit 1; }
if (( max_was_running )); then
  "${compose[@]}" --profile max up -d --no-build maxworker
  sleep 3
  max_id=$("${compose[@]}" --profile max ps -q maxworker)
  [[ -n "$max_id" && $(docker inspect --format '{{.State.Running}}' "$max_id") == true ]] || { printf 'MAX-worker не возобновился. Проверьте журнал.\n' >&2; exit 1; }
fi
completed=1
printf 'complete\n' > "$recovery/phase"
printf '\nОбновление 6.32.0 установлено. Данные и настройки сохранены.\n'
if (( max_was_running )); then printf 'Ранее работавший MAX-worker возобновлён.\n'; else printf 'MAX-worker не включался автоматически. Настройка и пилот — отдельный шаг.\n'; fi
