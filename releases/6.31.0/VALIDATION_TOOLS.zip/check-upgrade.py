import json,os,shutil,subprocess,tarfile,tempfile,time,urllib.request,uuid
from pathlib import Path
work=Path(__file__).resolve().parent
release=work/'fixture-artifacts'
old=os.environ.get('ARMADA_UPGRADE_FROM','6.25.0')
assert old in ('6.25.0','6.25.1','6.26.0','6.27.0','6.28.0','6.29.0','6.30.0')
name='armada-release631-'+uuid.uuid4().hex[:8]
root=Path(tempfile.mkdtemp(prefix=name+'-',dir='/tmp'))
app=root/'openIA-feature-accounts-foundation';deploy=app/'deploy/beget';deploy.mkdir(parents=True)
runner=root/'runner-bin';runner.mkdir()
(root/'runner-tmp').mkdir()
shutil.copy2(work/'synthetic-signing.public.pem',root/'trust-public.pem')
docker=shutil.which('docker')
env=os.environ.copy()
for key in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH','ARMADA_MAX_TOKEN','ARMADA_MAX_TOKEN_FILE','ARMADA_MAX_WEBHOOK_SECRET','ARMADA_MAX_WEBHOOK_SECRET_FILE','ARMADA_UPDATE_ARCHIVE'):env.pop(key,None)
env.update(COMPOSE_PROJECT_NAME=name,UPGRADE_IMAGE='armada-web:'+old,ARMADA_BACKUP_DIR=str(root/'backups'),MAX_ENABLED='0',TEST_INIT_FILE=str(root/'fixture-init.py'))
(root/'fixture-init.py').write_bytes(Path('/workspace/openIA/deploy/synology/init_secrets.py').read_bytes())
cli=[docker,'--host=unix:///var/run/docker.sock']
base=cli+['compose','-p',name,'-f',str(root/'test-compose.yml')]
volumes=[]
compose='''name: ${COMPOSE_PROJECT_NAME}
x-app: &app
  image: ${UPGRADE_IMAGE}
  read_only: true
  cap_drop: [ALL]
  pids_limit: 128
  tmpfs: ['/tmp:rw,size=128m,mode=1777']
  environment: &appenv
    PRIVATE_DOCUMENT_ROOT: /var/lib/armada-documents
    ARMADA_SECRET_KEY_FILE: /run/armada/django-key
    ARMADA_MAIL_KEY_FILE: /run/armada/mail-key
    DATABASE_URL_FILE: /run/armada/database-url
    ARMADA_ALLOWED_HOSTS: app.armada-sibir.ru,armada-sibir.ru,127.0.0.1,localhost,testserver
    ARMADA_TRUST_PROXY: '1'
    ARMADA_APP_DOMAIN: app.armada-sibir.ru
    ARMADA_MAX_ENABLED: ${MAX_ENABLED:-0}
    ARMADA_MAX_TOKEN_FILE: ${MAX_TOKEN_FILE:-}
    ARMADA_MAX_WEBHOOK_SECRET_FILE: ${MAX_SECRET_FILE:-}
    ARMADA_MAX_BOT_NAME: synthetic_bot
  volumes: [config:/run/armada:ro, documents:/var/lib/armada-documents]
  networks: [backend]
services:
  init:
    image: python:3.12-slim-bookworm
    user: '0:0'
    command: [python, /fixture-init.py]
    volumes: [config:/run/armada, documents:/var/lib/armada-documents, '${TEST_INIT_FILE}:/fixture-init.py:ro']
    network_mode: none
  db:
    image: armada-pg17-test:631
    depends_on: {init: {condition: service_completed_successfully}}
    environment:
      PGDATA: /var/lib/postgresql/data
      PG_MAJOR: '17'
      LANG: en_US.utf8
      LD_LIBRARY_PATH: /pg-libs
      PATH: /usr/lib/postgresql/17/bin:/usr/local/bin:/usr/bin:/bin
      POSTGRES_USER: armada_admin
      POSTGRES_DB: armada
      POSTGRES_PASSWORD_FILE: /run/armada/postgres-admin-password
    volumes:
      - config:/run/armada:ro
      - /usr/lib/x86_64-linux-gnu:/usr/lib/x86_64-linux-gnu:ro
      - /usr/lib/locale:/usr/lib/locale:ro
      - /usr/share/zoneinfo:/usr/share/zoneinfo:ro
      - /lib:/lib:ro
      - /lib64:/lib64:ro
      - /usr/bin:/usr/bin:ro
      - /usr/bin:/bin:ro
      - /workspace/armada-release-6.31.0/work/pg17-native/root/usr/lib/postgresql/17:/usr/lib/postgresql/17:ro
      - /workspace/armada-release-6.31.0/work/pg17-native/root/usr/share/postgresql:/usr/share/postgresql:ro
      - /workspace/armada-release-6.31.0/work/pg17-native/root/usr/lib/x86_64-linux-gnu:/pg-libs:ro
      - /workspace/armada-release-6.31.0/work/pg-entrypoint.sh:/usr/local/bin/docker-entrypoint.sh:ro
      - /workspace/armada-release-6.31.0/work/gosu:/usr/local/bin/gosu:ro
      - /workspace/armada-release-6.31.0/work/pg-passwd:/etc/passwd:ro
      - /workspace/armada-release-6.31.0/work/pg-group:/etc/group:ro
      - /workspace/armada-release-6.31.0/work/pg-init-app.sh:/docker-entrypoint-initdb.d/10-create-app.sh:ro
    tmpfs: ['/var/lib/postgresql/data:rw,size=768m','/tmp:rw,size=64m,mode=1777']
    command: [postgres, -c, shared_buffers=32MB, -c, max_wal_size=64MB, -c, min_wal_size=32MB]
    networks: [backend]
    healthcheck:
      test: [CMD-SHELL, pg_isready -U armada_admin -d armada]
      interval: 1s
      timeout: 3s
      retries: 40
  web:
    <<: *app
    depends_on: {db: {condition: service_healthy}}
    healthcheck:
      test: [CMD, python, -c, "import urllib.request; r=urllib.request.Request('http://127.0.0.1:8000/cabinet/login/',headers={'Host':'app.armada-sibir.ru','X-Forwarded-Proto':'https'}); urllib.request.urlopen(r,timeout=3)"]
      interval: 1s
      timeout: 4s
      retries: 40
  mailworker:
    image: caddy:2-alpine@sha256:eb4d35b7452d1ab6171fbdbe8d9275b2301dad6dad92115d91e19fb9b24d510f
    entrypoint: [sh, -c]
    command: ['exec sleep 3600']
    networks: [backend]
    depends_on: {db: {condition: service_healthy}}
  maxworker:
    <<: *app
    image: python:3.12-slim-bookworm
    user: '10001:10001'
    working_dir: /app
    volumes: [config:/run/armada:ro, documents:/var/lib/armada-documents, max-runtime:/app:ro, max-python:/usr/local/lib/python3.12/site-packages:ro]
    profiles: [max]
    depends_on: {web: {condition: service_healthy}}
    command: [python, server/manage.py, process_max, --loop]
  proxy:
    image: caddy:2-alpine@sha256:eb4d35b7452d1ab6171fbdbe8d9275b2301dad6dad92115d91e19fb9b24d510f
    entrypoint: [sh, -c]
    command: ['exec sleep 3600']
    networks: [backend]
    depends_on: {web: {condition: service_healthy}}
volumes:
  config:
  documents:
  max-runtime:
  max-python:
networks:
  backend:
    internal: true
'''
(root/'test-compose.yml').write_text(compose)
legacy=compose
if old!='6.30.0':
 a=legacy.index('  maxworker:');b=legacy.index('  proxy:',a);legacy=legacy[:a]+legacy[b:]
(root/'legacy-compose.yml').write_text(legacy)
(deploy/'compose.yml').write_text(compose)
(deploy/'Caddyfile').write_text('synthetic isolated proxy; no real domain binding\n')
(deploy/'.env').write_text('SYNTHETIC_PRESERVE=1\n')
(deploy/'backup.sh').write_bytes(subprocess.check_output(['git','show','53c3ac9:deploy/beget/backup.sh'],cwd='/workspace/openIA'))
(app/'index.html').write_text('OLD SOURCE')
# All inner compose commands target this one test project; no production ports/proxy.
wrapper=r'''#!/usr/local/bin/python3
import os,sys
from pathlib import Path
args=sys.argv[1:]
if not args or args[0] not in ('compose','build','info','inspect','version','image'):raise SystemExit('Unexpected test Docker operation')
if args[0]=='compose':
 if '-f' in args:
  target=os.environ['TEST_COMPOSE']
  if Path(os.environ['ARMADA_APP_ROOT'],'index.html').read_text()=='OLD SOURCE':target=os.environ['TEST_LEGACY_COMPOSE']
  args[args.index('-f')+1]=target
 args[1:1]=['-p',os.environ['COMPOSE_PROJECT_NAME']]
if args[0]=='build':args.insert(1,'--network=none')
# Test-only failure injection and write attempts, never installed on a VPS.
mode=os.environ.get('ARMADA_TEST_FAIL','')
if args[0]=='build' and mode=='build':raise SystemExit(61)
if args[0]=='compose' and (('pg_dump' in args) or ('config' in args and '--quiet' in args) or ('migrate' in args and '--noinput' in args)):
 import subprocess,json
 probe_code="from accounts.models import User; User.objects.filter(pk="+repr(os.environ['PROBE_WORKER'])+").update(full_name='UNEXPECTED SYNTHETIC WRITE')"
 probe_args=['compose','-p',os.environ['COMPOSE_PROJECT_NAME'],'-f',os.environ['TEST_COMPOSE'],'exec','-T','web','python','server/manage.py','shell','-c',probe_code]
 probe=subprocess.run(['/usr/local/bin/docker','--host=unix:///var/run/docker.sock',*probe_args],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 with open(os.environ['WRITE_PROBES'],'a') as f:f.write(json.dumps({'during':' '.join(x for x in ('pg_dump','config','migrate') if x in args),'blocked':probe.returncode!=0})+'\n')
 if probe.returncode==0:raise SystemExit('Synthetic write unexpectedly succeeded during freeze')
if args[0]=='compose' and 'config' in args and '--quiet' in args and mode=='before':raise SystemExit(62)
if args[0]=='inspect' and any('Health.Status' in x for x in args) and mode=='health':
 print('unhealthy');raise SystemExit(0)
if args[0]=='compose' and 'migrate' in args and '--noinput' in args and mode=='migration':
 status=os.spawnv(os.P_WAIT,'/usr/local/bin/docker',['docker','--host=unix:///var/run/docker.sock',*args])
 raise SystemExit(status or 63)
os.execv('/usr/local/bin/docker',['docker','--host=unix:///var/run/docker.sock',*args])
'''
(runner/'docker').write_text(wrapper)
(runner/'curl').write_text('#!/bin/sh\necho "Network download forbidden in isolated installer check" >&2\nexit 99\n')
(runner/'unzip').write_text('''#!/usr/local/bin/python3
import sys,zipfile,os,calendar
from pathlib import Path
with zipfile.ZipFile(sys.argv[2]) as z:
 if sys.argv[1]=='-tq':assert z.testzip() is None
 else:
  mask=os.umask(0o022);z.extractall(sys.argv[4]);os.umask(mask)
  for i in sorted(z.infolist(),key=lambda i:len(i.filename),reverse=True):
   path=Path(sys.argv[4])/i.filename;os.chown(path,1000,1000);path.chmod(((i.external_attr>>16)&0o777) or (0o755 if i.is_dir() else 0o644));t=calendar.timegm(i.date_time+(0,0,-1));os.utime(path,(t,t))
''')
(runner/'sleep').write_text('#!/usr/local/bin/python3\nimport os,sys\nif os.environ.get("ARMADA_TEST_FAIL")!="health":os.execv("/bin/sleep",["sleep",*sys.argv[1:]])\n')
for f in runner.iterdir():f.chmod(0o755)

def run(args,input=None,binary=False,local_env=None):
 r=subprocess.run(args,input=input,capture_output=True,text=not binary,env=local_env or env)
 if r.returncode:
  err=r.stderr.decode(errors='replace') if binary else r.stderr
  out='[binary output suppressed]' if binary else r.stdout
  raise RuntimeError('Test command failed: '+str(args[:6])+'\n'+out[-1000:]+'\n'+err[-2000:])
 return r.stdout

def shell(code,local_env=None):return run(base+['run','--rm','--no-deps','-T','--user','0:0','--cap-add','DAC_OVERRIDE','--cap-add','CHOWN','--entrypoint','python','web','server/manage.py','shell'],input=code,local_env=local_env)
def ready():
 deadline=time.monotonic()+90
 while time.monotonic()<deadline:
  try:
   web=run(base+['ps','-q','web']).strip();info=json.loads(run(cli+['inspect',web]))[0]
   if info['State'].get('Health',{}).get('Status')=='healthy':
    probe="import urllib.request; r=urllib.request.Request('http://127.0.0.1:8000/cabinet/login/',headers={'Host':'app.armada-sibir.ru','X-Forwarded-Proto':'https'}); assert urllib.request.urlopen(r,timeout=3).status==200"
    run(base+['exec','-T','web','python','-c',probe]);return
  except (OSError,RuntimeError,IndexError,KeyError):time.sleep(.3)
 raise RuntimeError('Isolated web did not become ready')

def root_run(command,logname,expected_failure=False):
 cfg=Path(os.environ.get('DOCKER_CONFIG',str(Path.home()/'.docker')))
 args=cli+['run','--rm','--network','none','--read-only','--user','0:0',
   '--mount',f'type=bind,src={root},dst={root}',
   '--mount',f'type=bind,src={root/"runner-tmp"},dst=/tmp',
   '--mount',f'type=bind,src={release},dst={release},readonly',
   '--mount','type=bind,src=/var/run/docker.sock,dst=/var/run/docker.sock',
   '--mount','type=bind,src=/usr/local/bin/docker,dst=/usr/local/bin/docker,readonly',
   '--mount',f'type=bind,src={work/"openssl-bookworm"},dst=/usr/bin/openssl,readonly',
   '--mount','type=bind,src=/workspace/openIA/.venv/lib/python3.12/site-packages,dst=/usr/local/lib/python3.12/site-packages,readonly',
   '--mount','type=bind,src=/usr/libexec/docker/cli-plugins,dst=/usr/libexec/docker/cli-plugins,readonly']
 if cfg.is_dir():args+=['--mount',f'type=bind,src={cfg},dst={cfg},readonly','-e','DOCKER_CONFIG='+str(cfg)]
 values={'COMPOSE_PROJECT_NAME':name,'UPGRADE_IMAGE':'armada-web:6.31.0','ARMADA_APP_ROOT':str(app),
  'ARMADA_UPDATE_ARCHIVE':str(release/'openIA-6.31.0-update.zip'),'ARMADA_BACKUP_DIR':str(root/'backups'),
  'TEST_COMPOSE':str(root/'test-compose.yml'),'TEST_LEGACY_COMPOSE':str(root/'legacy-compose.yml'),'PATH':str(runner)+':/usr/local/bin:/usr/bin:/bin',
  'BUILDX_CONFIG':'/tmp/buildx','TEST_INIT_FILE':str(root/'fixture-init.py'),'MAX_ENABLED':env.get('MAX_ENABLED','0'),
  'ARMADA_RELEASE_PUBLIC_KEY':str(root/'trust-public.pem'),
  'ARMADA_TEST_FAIL':os.environ.get('ARMADA_TEST_FAIL',''),'PROBE_WORKER':str(snapshot['worker']),'WRITE_PROBES':str(root/'write-probes.jsonl'),
  'MAX_TOKEN_FILE':env.get('MAX_TOKEN_FILE',''),'MAX_SECRET_FILE':env.get('MAX_SECRET_FILE','')}
 for k,v in values.items():args+=['-e',k+'='+v]
 cleanup=f'chown -R {os.getuid()}:{os.getgid()} {root}'
 body=f'chown 0:0 {root}/trust-public.pem; chmod 644 {root}/trust-public.pem; status=0; {command} || status=$?; {cleanup}; exit "$status"'
 r=subprocess.run(args+['--entrypoint','bash','python:3.12-slim-bookworm','-c',body],env=env,capture_output=True,text=True)
 (work/(logname+'-'+old+'.log')).write_text(r.stdout+'\n'+r.stderr)
 if r.returncode and not expected_failure:raise RuntimeError('Isolated root command failed, see '+logname+'-'+old+'.log')
 if expected_failure and not r.returncode:raise RuntimeError('Injected failure was ignored')
 return r.returncode

def unpack(archive):
 with tarfile.open(archive) as z:
  def get(name):
   member=next(m for m in z.getmembers() if m.name.removeprefix('./')==name)
   return z.extractfile(member).read()
  return get('database.dump'),get('config.tar'),get('documents.tar')

def restore(archive,version,dbname,code,max_env=False):
 # Free only this project's writer containers before isolated recovery; preserve volumes.
 run(base+['--profile','max','stop','web','mailworker','maxworker','proxy'])
 run(base+['--profile','max','rm','--force','web','mailworker','maxworker','proxy'])
 dump,cfg,docs=unpack(archive)
 run(base+['exec','-T','db','psql','-U','armada_admin','-d','postgres','-c',f'CREATE DATABASE {dbname} OWNER armada_app;'])
 run(base+['exec','-T','db','pg_restore','-U','armada_admin','-d',dbname,'--no-owner','--no-acl','--role=armada_app'],input=dump,binary=True)
 restored=[name+'-'+dbname+'-config',name+'-'+dbname+'-documents'];volumes.extend(restored)
 for vol,contents in zip(restored,[cfg,docs]):
  run(cli+['volume','create',vol]);run(cli+['run','--rm','-i','--network','none','--user','0:0','-v',vol+':/restore','--entrypoint','tar','armada-web:'+version,'-C','/restore','-xf','-'],input=contents,binary=True)
 args=cli+['run','--rm','-i','--user','0:0','--read-only','--tmpfs','/tmp:rw,size=128m,mode=1777','--network',name+'_backend','-v',restored[0]+':/run/armada:ro','-v',restored[1]+':/var/lib/armada-documents'+('' if max_env else ':ro')]
 settings={'PRIVATE_DOCUMENT_ROOT':'/var/lib/armada-documents','ARMADA_SECRET_KEY_FILE':'/run/armada/django-key','ARMADA_MAIL_KEY_FILE':'/run/armada/mail-key','DATABASE_URL_FILE':'/run/armada/database-url','ARMADA_ALLOWED_HOSTS':'app.armada-sibir.ru,127.0.0.1','ARMADA_TRUST_PROXY':'1','ARMADA_MAX_ENABLED':'0'}
 if max_env:settings.update(ARMADA_MAX_TOKEN_FILE='/run/armada/max-token',ARMADA_MAX_WEBHOOK_SECRET_FILE='/run/armada/max-secret',ARMADA_MAX_BOT_NAME='synthetic_bot')
 for k,v in settings.items():args+=['-e',k+'='+v]
 prelude='from django.db import connections\nconnections.close_all()\nconnections.databases["default"]["NAME"]='+repr(dbname)+'\n'
 output=run(args+['armada-web:'+version,'python','server/manage.py','shell'],input=prelude+code)
 app_args=args.copy();app_args[app_args.index('--user')+1]='10001:10001'
 run(app_args+['armada-web:'+version,'python','-c',"from pathlib import Path; [p.read_bytes() for p in Path('/var/lib/armada-documents').rglob('*') if p.is_file()]"])
 return output

try:
 run(base+['up','-d','--no-build','web','mailworker','proxy']);ready()
 db_before=run(base+['ps','-q','db']).strip()
 initial_web=run(base+['ps','-q','web']).strip()
 initial_image=run(cli+['inspect','--format','{{.Image}}',initial_web]).strip()
 output=shell('BASE_VERSION='+repr(old)+'\n'+(work/'seed-upgrade.py').read_text())
 snapshot=json.loads(next(l.removeprefix('SNAPSHOT:') for l in output.splitlines() if l.startswith('SNAPSHOT:')))
 shell("from pathlib import Path; from django.conf import settings; import os; p=Path(settings.PRIVATE_DOCUMENT_ROOT); [os.chown(f,10001,10001) for f in [p,*p.rglob('*')]]")
 mode=os.environ.get('ARMADA_TEST_FAIL','')
 verify=(work/'verify-upgrade.py').read_text()
 if mode:
  env['UPGRADE_IMAGE']='armada-web:6.31.0'
  root_run('bash '+str(release/'install-6.31.0.sh'),'failure-'+mode,expected_failure=True)
  if mode in ('build','before'):
   ready()
   current_web=run(base+['ps','-q','web']).strip()
   assert run(cli+['inspect','--format','{{.Image}}',current_web]).strip()==initial_image
   output=shell('SNAPSHOT='+repr(json.dumps(snapshot))+'\nEXPECTED_VERSION='+repr(old)+'\n'+verify,local_env=env|{'UPGRADE_IMAGE':'armada-web:'+old})
   assert (app/'index.html').read_text()=='OLD SOURCE'
  else:
   running=run(base+['--profile','max','ps','--services','--status','running','web','mailworker','maxworker']).strip()
   assert not running,'Writers resumed after migration failure'
   output=run(base+['run','--rm','--no-deps','-T','--user','0:0','--cap-add','DAC_OVERRIDE','--cap-add','CHOWN','--entrypoint','python','web','server/manage.py','shell'],input='SNAPSHOT='+repr(json.dumps(snapshot))+'\nEXPECTED_VERSION="6.31.0"\n'+verify)
  print('PASS injected '+mode+': expected failure, correct writer/image/tree state.',flush=True)
  for line in output.splitlines():
   if line.startswith('PASS '):print(line,flush=True)
  backups=list((root/'backups').glob('armada-*.tar.gz'))
  if mode=='build':assert not backups
  else:
   assert len(backups)==1
   output=restore(backups[0],old,'armada_failure631','SNAPSHOT='+repr(json.dumps(snapshot))+'\nEXPECTED_VERSION='+repr(old)+'\n'+verify)
   for line in output.splitlines():
    if line.startswith('PASS '):print(line,flush=True)
 else:
  # Execute the generated, checksum-bound installer as root; real Docker engine,
  # database, image build and archive. Only Compose endpoints are isolated.
  env['UPGRADE_IMAGE']='armada-web:6.31.0'
  root_run('bash '+str(release/'install-6.31.0.sh'),'installer-real')
  ready()
  assert run(base+['ps','-q','db']).strip()==db_before,'Database container was replaced'
  run(base+['exec','-T','web','python','-c',"from pathlib import Path; [p.read_bytes() for p in Path('/var/lib/armada-documents').rglob('*') if p.is_file()]; print('Private files readable by app UID')"])
  assert (app/'index.html').read_bytes()==Path('/workspace/openIA/index.html').read_bytes()
  assert (deploy/'.env').read_text()=='SYNTHETIC_PRESERVE=1\n'
  backups=list((root/'backups').glob('armada-*.tar.gz'));assert len(backups)==1
  print('PASS source '+old+': real installer built ZIP, captured original backup and started 6.31.0.',flush=True)
  verify=(work/'verify-upgrade.py').read_text()
  output=shell('SNAPSHOT='+repr(json.dumps(snapshot))+'\nEXPECTED_VERSION="6.31.0"\n'+verify)
  for line in output.splitlines():
   if line.startswith('PASS '):print(line,flush=True)
  if old=='6.30.0':
   exec((work/'max-roundtrip.py').read_text())
  output=restore(backups[0],old,'armada_original631','SNAPSHOT='+repr(json.dumps(snapshot))+'\nEXPECTED_VERSION='+repr(old)+'\n'+verify)
  for line in output.splitlines():
   if line.startswith('PASS '):print(line,flush=True)
 if (root/'write-probes.jsonl').exists():
  probes=[json.loads(l) for l in (root/'write-probes.jsonl').read_text().splitlines()]
  assert probes and all(p['blocked'] for p in probes)
  (work/('write-probes-'+(mode or old)+'.json')).write_text(json.dumps(probes))

finally:
 logs=subprocess.run(cli+['logs',name+'-db-1'],env=env,capture_output=True,text=True)
 (work/('db-'+old+'.log')).write_text(logs.stdout+'\n'+logs.stderr)
 # Only resources with this unique test project name are removed.
 subprocess.run(base+['--profile','max','down','--volumes','--remove-orphans'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 for vol in volumes:subprocess.run(cli+['volume','rm',vol],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
 try:shutil.rmtree(root)
 except PermissionError:print('Owned test evidence retained:',root)
