import os,subprocess
from pathlib import Path
work=Path(__file__).resolve().parent
with (work/'upgrade-6.30.0.log').open('w') as log:
 r=subprocess.run(['/workspace/openIA/.venv/bin/python',str(work/'check-upgrade.py')],env=os.environ|{'ARMADA_UPGRADE_FROM':'6.30.0','ARMADA_TEST_FAIL':''},stdout=log,stderr=subprocess.STDOUT)
if r.returncode:raise SystemExit('FAILED 6.30.0; inspect isolated log')
print('PASS transition 6.30.0 with MAX',flush=True)
for mode in ('build','before','migration','health'):
 with (work/('failure-'+mode+'.log')).open('w') as log:
  r=subprocess.run(['/workspace/openIA/.venv/bin/python',str(work/'check-upgrade.py')],env=os.environ|{'ARMADA_UPGRADE_FROM':'6.29.0','ARMADA_TEST_FAIL':mode},stdout=log,stderr=subprocess.STDOUT)
 if r.returncode:raise SystemExit('FAILED injected '+mode+'; inspect isolated log')
 print('PASS injected '+mode,flush=True)
