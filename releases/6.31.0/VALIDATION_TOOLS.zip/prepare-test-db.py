import io,os,subprocess,uuid,tarfile
from pathlib import Path
work=Path(__file__).resolve().parent;env=os.environ.copy()
for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(k,None)
d=['docker','--host=unix:///var/run/docker.sock'];name='armada-pg-entry-'+uuid.uuid4().hex[:8]
try:
 subprocess.run(d+['create','--name',name,'--network','none','postgres:17-bookworm@sha256:3645570cccdfa447589da9f57dd740faa29b30938e861289a5574b6ca6b03826'],env=env,check=True,stdout=subprocess.DEVNULL)
 for source,target in (('/usr/local/bin/docker-entrypoint.sh','pg-entrypoint.sh'),('/usr/local/bin/gosu','gosu'),('/usr/bin/openssl','openssl-bookworm')):
  subprocess.run(d+['cp',name+':'+source,str(work/target)],env=env,check=True)
  (work/target).chmod(0o755)
finally:subprocess.run(d+['rm','--volumes',name],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
(work/'pg-passwd').write_text('root:x:0:0:root:/root:/bin/bash\npostgres:x:999:999:postgres:/var/lib/postgresql:/bin/bash\n')
(work/'pg-group').write_text('root:x:0:\npostgres:x:999:\n')
(work/'pg-passwd').chmod(0o644);(work/'pg-group').chmod(0o644)
import shutil
shutil.copy2('/workspace/openIA/deploy/synology/10-create-app.sh',work/'pg-init-app.sh');(work/'pg-init-app.sh').chmod(0o444)
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w'):pass
subprocess.run(d+['import','--change','ENTRYPOINT ["/usr/local/bin/docker-entrypoint.sh"]','--change','CMD ["postgres"]','-','armada-pg17-test:631'],input=buf.getvalue(),env=env,check=True,stdout=subprocess.DEVNULL)
print('Created empty isolated test image; PG17 binaries and original entrypoint mounted read-only; no production files or settings.')
