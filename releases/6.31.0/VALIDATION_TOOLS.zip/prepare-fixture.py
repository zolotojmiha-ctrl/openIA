from pathlib import Path
import json,shutil,zipfile,calendar,os,subprocess
work=Path(__file__).resolve().parent;root=work.parent;package=work/'package';fixture=work/'fixture-artifacts'
package.mkdir(exist_ok=True);fixture.mkdir(exist_ok=True)
with zipfile.ZipFile(root/'final/openIA-6.31.0-update.zip') as z:
 z.extractall(package)
 for i in sorted(z.infolist(),key=lambda i:len(i.filename),reverse=True):
  p=package/i.filename;mode=(i.external_attr>>16)&0o777
  p.chmod(mode or (0o755 if i.is_dir() else 0o644));t=calendar.timegm(i.date_time+(0,0,-1));os.utime(p,(t,t))
for name in ('openIA-6.31.0-update.zip','install-6.31.0.sh','openIA-6.31.0-update.json'):
 shutil.copy2(root/'final'/name,fixture/name)
f=fixture/'openIA-6.31.0-update.json';m=json.loads(f.read_text());m.update(status='isolated_test_fixture_not_a_release',ready_for_install=True);f.write_text(json.dumps(m,indent=2)+'\n')

# Unrelated temporary test identity; the company key is never used by the test server.
key=work/'synthetic-signing.key';public=work/'synthetic-signing.public.pem'
if not key.exists():
 subprocess.run(['openssl','genpkey','-algorithm','RSA','-pkeyopt','rsa_keygen_bits:2048','-out',str(key)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
key.chmod(0o600)
subprocess.run(['openssl','pkey','-in',str(key),'-pubout','-out',str(public)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
subprocess.run(['python','/workspace/openIA/deploy/beget/sign_release.py','--directory',str(fixture),'--version','6.31.0','--key-file',str(key)],check=True)
