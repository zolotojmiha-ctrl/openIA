import os,re,subprocess,uuid
from pathlib import Path
root=Path(__file__).resolve().parent/'pg17-native/root';root.mkdir(parents=True,exist_ok=True)
env=os.environ.copy()
for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(k,None)
d=['docker','--host=unix:///var/run/docker.sock'];name='armada-pg-tools-'+uuid.uuid4().hex[:8]
def cmd(args,**kw):
 r=subprocess.run(d+args,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,**kw)
 if r.returncode:raise RuntimeError(r.stderr.decode())
 return r
try:
 cmd(['create','--name',name,'--network','none','postgres:17-bookworm@sha256:3645570cccdfa447589da9f57dd740faa29b30938e861289a5574b6ca6b03826'])
 for relative in ('usr/lib/postgresql/17','usr/share/postgresql'):
  dest=root/relative;dest.mkdir(parents=True,exist_ok=True);cmd(['cp',name+':/'+relative+'/.',str(dest)])
 lib=root/'usr/lib/x86_64-linux-gnu';lib.mkdir(parents=True,exist_ok=True)
 for path in [root,*root.rglob('*')]:
  if path.is_dir():path.chmod(0o755)
 native=env|{'LD_LIBRARY_PATH':str(lib)}
 for _ in range(10):
  missing=set()
  for bin in ('postgres','initdb','pg_ctl','psql'):
   result=subprocess.run(['ldd',str(root/'usr/lib/postgresql/17/bin'/bin)],env=native,capture_output=True,text=True)
   missing.update(re.findall(r'^\s*(\S+) => not found',result.stdout,re.M))
  if not missing:break
  for library in missing:cmd(['cp','-L',name+':/usr/lib/x86_64-linux-gnu/'+library,str(lib/library)])
 else:raise RuntimeError('Native engine dependencies incomplete')
 result=subprocess.run([str(root/'usr/lib/postgresql/17/bin/postgres'),'-V'],env=native,capture_output=True,text=True,check=True)
 print(result.stdout.strip()+'; copied only engine/share and missing libraries from cached pinned image; no system configuration changed.')
finally:subprocess.run(d+['rm','--volumes',name],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
