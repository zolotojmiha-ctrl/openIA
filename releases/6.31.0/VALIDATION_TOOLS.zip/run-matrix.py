import os,subprocess,json
from pathlib import Path
work=Path(__file__).resolve().parent
for version in ('6.25.0','6.25.1','6.26.0','6.27.0','6.28.0','6.29.0','6.30.0'):
 with (work/('upgrade-'+version+'.log')).open('w') as log:
  result=subprocess.run(['/workspace/openIA/.venv/bin/python',str(work/'check-upgrade.py')],env=os.environ|{'ARMADA_UPGRADE_FROM':version,'ARMADA_TEST_FAIL':''},stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit('FAILED upgrade '+version+'; see its isolated log')
 print('PASS transition '+version+' -> 6.31.0',flush=True)
for mode in ('build','before','migration','health'):
 with (work/('failure-'+mode+'.log')).open('w') as log:
  result=subprocess.run(['/workspace/openIA/.venv/bin/python',str(work/'check-upgrade.py')],env=os.environ|{'ARMADA_UPGRADE_FROM':'6.29.0','ARMADA_TEST_FAIL':mode},stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit('FAILED injected '+mode+'; see its isolated log')
 print('PASS injected '+mode,flush=True)
