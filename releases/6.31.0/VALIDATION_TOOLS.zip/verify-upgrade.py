import json, hashlib
from pathlib import Path
from decimal import Decimal
from django.utils import timezone
from django.conf import settings
from django.test import Client
from django.core.files.uploadedfile import SimpleUploadedFile
from accounts.models import User
from projects.models import ContractAccess, ObjectAccess, StockBalance, StockMovement, Warehouse
from documents.models import Document, DocumentVersion, Person
from documents.access import visible_documents
from finance.models import FinancialScope
from finance.services import summary
from repairs.models import Job, Report
from postoffice.models import Mailbox
from postoffice.crypto import reveal
s=json.loads(SNAPSHOT)
leader=User.objects.get(pk=s['leader']);worker=User.objects.get(pk=s['worker'])
assert leader.password==s['password_hash'] and leader.session_version==8
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/run/armada').iterdir() if p.is_file()}==s['config_hashes']
doc=Document.objects.get(pk=s['document']);version=DocumentVersion.objects.get(pk=s['version'])
assert doc.current_version_id==version.pk
assert hashlib.sha256((Path(settings.PRIVATE_DOCUMENT_ROOT)/version.storage_key).read_bytes()).hexdigest()==s['sha256']
assert doc.objects_linked.filter(pk=s['object']).exists() and doc.contracts_linked.filter(pk=s['contract']).exists() and doc.personnel_linked.filter(pk=s['person']).exists()
assert Person.objects.filter(pk=s['person']).exists() and not visible_documents(worker).filter(pk=doc.pk).exists()
assert ObjectAccess.objects.filter(user=worker,project_object_id=s['object']).exists() and ContractAccess.objects.filter(user=worker,contract_id=s['contract']).exists()
card=summary(FinancialScope.objects.get(pk=s['scope']))
assert (card['advances'],card['accepted'],card['paid'],card['offsets'],card['pending'])==(500,800,600,200,100)
assert StockBalance.objects.get(warehouse_id=s['warehouse'],item_id=s['item']).quantity==Decimal('7.5')
assert StockMovement.objects.filter(pk=s['movement']).exists()
assert Warehouse.objects.get(pk=s['warehouse']).served_objects.filter(pk=s['object']).exists()
job=Job.objects.get(pk=s['job']);assert job.length_m==1 and job.composition=='' and job.problem=='swamp'
assert Report.objects.get(pk=s['report']).note=='ТЕСТ История до обновления'
mailbox=Mailbox.objects.get(pk=s['mailbox']);assert mailbox.credential==s['mail_credential'] and reveal(mailbox.credential)=='synthetic-provider-secret'
client=Client(HTTP_HOST='app.armada-sibir.ru',HTTP_X_FORWARDED_PROTO='https');client.cookies[settings.SESSION_COOKIE_NAME]=s['session']
for url in ['/cabinet/','/cabinet/documents/','/cabinet/contracts/'+s['contract']+'/','/cabinet/stock/','/cabinet/stock/'+s['warehouse']+'/','/cabinet/repairs/'+s['job']+'/','/cabinet/mail/']:
 response=client.get(url,secure=True,follow=True);assert response.status_code==200,(url,response.status_code)
 assert EXPECTED_VERSION.encode() in response.content
from projects.models import StockItem,CustomerAccess
kit=StockItem.objects.get(pk=s['kit']);assert kit.unit=='kit'
assert StockBalance.objects.get(warehouse_id=s['warehouse'],item=kit).quantity==3
piece=StockItem.objects.get(pk=s['piece']);assert str(piece.reserved_job_id)==s['job'] and str(piece.coupling_id)==s['coupling'] and piece.version==s['piece_version']
assert StockBalance.objects.get(warehouse_id=s['warehouse'],item=piece).quantity==1
from postoffice.models import SiteRequest
receipt=SiteRequest.objects.get(pk=s['site_request']);assert bytes(receipt.resume_data)==b'preserved candidate resume' and receipt.delivery_state=='sent'
from projects import rentals
from projects.models import EquipmentRental,RentalDay,RentalPayment,RentalPeriod
rental=EquipmentRental.objects.get(pk=s['rental']);amounts=rentals.totals(rental)
assert (amounts['charged'],amounts['paid'],amounts['debt'])==(1000,300,700)
assert RentalDay.objects.get(pk=s['rental_day']).revisions.count()==1
assert RentalPayment.objects.get(pk=s['rental_payment']).amount==300
assert RentalPeriod.objects.get(pk=s['rental_period']).snapshot==s['rental_snapshot']
assert (card['direct'],card['cash_out'])==(1000,300)
from projects.models import CounterpartyAgreement
legacy=CounterpartyAgreement.objects.get(pk=s['legacy_agreement']);assert legacy.amount==Decimal('21000.01') and legacy.documents.filter(pk=doc.pk).exists()
assert str(legacy.customer_contract_id)==s['contract'] and str(legacy.project_object_id)==s['object']
assert sorted(str(c.pk) for c in legacy.customer_contracts.all())==s['agreement_contracts']
assert sorted(str(o.pk) for o in legacy.project_objects.all())==s['agreement_objects']
from accounts.permissions import permitted
from projects.models import CoatingProfile
pto=User.objects.get(pk=s['pto']);assert pto.password==s['pto_hash'] and pto.session_version==4
original={g.permission:str(g.pk) for g in pto.grants.exclude(permission='stock.manage')}
assert original==s['pto_grants'] and not permitted(pto,'finance.read') and not permitted(pto,'finance.write')
profile=CoatingProfile.objects.get(pk=s['profile']);assert profile.area_per_m==Decimal('2.55') and profile.full_length_mm==1460 and profile.version==1
assert StockMovement.objects.count()==s['movement_count']
assert StockMovement.objects.get(pk=s['expense']).quantity==Decimal('1.25')
pto_client=Client(HTTP_HOST='app.armada-sibir.ru',HTTP_X_FORWARDED_PROTO='https');pto_client.cookies[settings.SESSION_COOKIE_NAME]=s['pto_session']

deleted=StockItem.objects.get(pk=s['deleted_item'])
assert deleted.deleted_at and deleted.archived
assert not StockBalance.objects.filter(item=deleted,quantity__gt=0).exists()
assert Report.objects.get(pk=s['old_p1_report']).note=='ТЕСТ Историческая П1'
from projects.models import RepairConsumption
assert not RepairConsumption.objects.filter(job_id=s['old_p1']).exists()

if EXPECTED_VERSION=='6.31.0':
 assert settings.ARMADA_MAX_ENABLED is False
 from django.db.migrations.recorder import MigrationRecorder
 from maxbot.models import Binding,Outbox
 assert set(MigrationRecorder.Migration.objects.filter(app='maxbot').values_list('name',flat=True))=={'0001_initial','0002_outbox_scope','0003_binding_last_timestamp'}
 assert not Binding.objects.exists() and not Outbox.objects.exists()
 assert client.post('/integrations/max/webhook/',data='{}',content_type='application/json',secure=True).status_code==503
 from projects.models import DemandMailing,DemandMailRun
 assert DemandMailing.objects.count()==0 and DemandMailRun.objects.count()==0
 from projects.demand_mail import queue_due
 queue_due()
 assert DemandMailRun.objects.count()==0
 response=client.get('/cabinet/stock/coverage/mail/new/',secure=True)
 assert response.status_code==200
 assert 'Настройки рассылки потребности'.encode() in response.content
 from projects.stock_planning_views import DiameterForm
 assert 'DN 700' in str(DiameterForm(initial={'diameter_mm':720,'expected_diameter':720})['diameter_mm'])

 assert permitted(pto,'stock.manage') and pto.grants.filter(permission='stock.manage').count()==1
 for url in ['/cabinet/stock/inventory/','/cabinet/stock/warehouses/','/cabinet/stock/needs/','/cabinet/stock/settings/coating/']:
  response=pto_client.get(url,secure=True,follow=True);assert response.status_code==200,(url,response.status_code)
 from repairs.importer import read_book
 for url,name in [('/cabinet/repair-materials/excel/','Потребность'),('/cabinet/stock/coverage/?export=xlsx','Муфты')]:
  response=pto_client.get(url,secure=True);assert response.status_code==200,(url,response.status_code)
  book=read_book(SimpleUploadedFile('report.xlsx',response.content),sheet_name=name);assert book['cells']
 assert StockMovement.objects.count()==s['movement_count']
 assert legacy.customer_contracts.filter(pk=s['contract']).exists() and legacy.project_objects.filter(pk=s['object']).exists()
 auto=EquipmentRental.objects.get(placement_id=s['auto_placement']);assert not auto.days.exists() and not auto.payments.exists()
 assert auto.supplier=='ТЕСТ Владелец'
 for url in ['/cabinet/equipment/','/cabinet/equipment/'+s['auto_equipment']+'/','/cabinet/stock/needs/','/cabinet/stock/settings/coating/','/cabinet/repairs/'+s['job']+'/construction/']:
  response=client.get(url,secure=True,follow=True);assert response.status_code==200,(url,response.status_code)
 response=client.get('/cabinet/equipment/'+s['auto_equipment']+'/',secure=True)
 assert 'Наработка аренды'.encode() in response.content and 'Включить учёт аренды'.encode() not in response.content
 assert '>Материалы по ремонтам</a>'.encode() not in response.content
 master=Client(HTTP_HOST='app.armada-sibir.ru',HTTP_X_FORWARDED_PROTO='https');master.force_login(worker)
 result=master.post('/cabinet/equipment/'+s['auto_equipment']+'/',{'rental_id':str(auto.pk),'action':'day','kind':'work','date':str(timezone.localdate()),'version':'0'},secure=True)
 assert result.status_code==302 and auto.days.get().hours==10 and auto.days.get().amount==0
 from projects import stock
 restored=stock.reverse(leader,s['deleted_loss'],'ТЕСТ Восстановление прежней ошибки',__import__('uuid').uuid4())
 deleted.refresh_from_db()
 assert deleted.deleted_at is None and not deleted.archived
 assert StockBalance.objects.get(item=deleted,warehouse_id=s['warehouse']).quantity==24
 from django.core.exceptions import ValidationError
 try:stock.reverse(leader,s['deleted_loss'],'Повтор',__import__('uuid').uuid4())
 except ValidationError:pass
 else:raise AssertionError('Double undo was accepted')
 assert StockBalance.objects.get(item=deleted,warehouse_id=s['warehouse']).quantity==24
 from projects.p1_coating import coating
 from types import SimpleNamespace
 probe=SimpleNamespace(section=SimpleNamespace(diameter_mm=720),length_m=1,actual_cleaning_length_m='2.4')
 assert [line['quantity'] for line in coating(probe)]==['1.575','38.034','5.932']
 print('PASS new 6.31.0: PTO stock right added without finance; both Excel reports, multiple agreement scopes and coating norm preserved;  automatic equipment rental, private master hours on equipment, old debt/advance/periods, stock, plans, files, sessions and keys preserved.')
else:
 assert permitted(pto,'stock.manage')==s['pto_had_stock']
 assert pto_client.get('/cabinet/stock/settings/coating/',secure=True).status_code==(200 if s['pto_had_stock'] else 403)
 assert EquipmentRental.objects.filter(placement_id=s['auto_placement']).exists()
 print('PASS restored '+EXPECTED_VERSION+': original rental hours/payments/periods, stock, plans, private files, sessions and keys preserved.')
