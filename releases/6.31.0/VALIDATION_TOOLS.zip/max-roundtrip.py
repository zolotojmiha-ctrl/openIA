# Executed by the isolated upgrade driver after upgrading the synthetic 6.29.0.
run(base+['run','--rm','--no-deps','--entrypoint','python','init','-c',"from pathlib import Path; import secrets,os; files={'max-token':'SYNTHETIC_NO_LIVE_TOKEN','max-secret':secrets.token_urlsafe(48)}; [(Path('/run/armada',n).write_text(v),os.chown('/run/armada/'+n,10001,10001),os.chmod('/run/armada/'+n,0o600)) for n,v in files.items()]"])
env.update(MAX_ENABLED='1',MAX_TOKEN_FILE='/run/armada/max-token',MAX_SECRET_FILE='/run/armada/max-secret')
(deploy/'.env').write_text('SYNTHETIC_PRESERVE=1\nARMADA_MAX_ENABLED=1\nARMADA_MAX_TOKEN_FILE=/run/armada/max-token\nARMADA_MAX_WEBHOOK_SECRET_FILE=/run/armada/max-secret\nARMADA_MAX_BOT_NAME=synthetic_bot\n')
run(base+['up','-d','--no-build','--no-deps','web','mailworker']);ready()
code='''
import io,uuid,json,hashlib
from pathlib import Path
from PIL import Image
from django.db import transaction
from django.utils import timezone
from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile
from accounts.models import User
from repairs.models import Job,Defect,JobDefect,Report,Attachment
from projects.models import StockMovement
from documents.storage import validate_upload,store_file
from maxbot import links,dialog
from maxbot.models import Binding,Draft,Photo,Inbox,Outbox
u=User.objects.get(pk=ORIGINAL['worker'])
source=Job.objects.get(pk=ORIGINAL['job'])
j=Job.objects.create(contract=source.contract,section=source.section,method='grind',assigned_to=u,created_by=source.created_by)
d=Defect.objects.create(contract=j.contract,section=j.section,kilometre='999.001',number='MAX631-SYNTHETIC')
JobDefect.objects.create(job=j,defect=d)
code=links.issue(u)
with transaction.atomic():links.request_link(links.digest(code),101,201)
b=links.approve(u,links.digest(code))
draft=dialog.start(b,j,'repaired')
draft.raw.update(performed_date=str(timezone.localdate()),note='SYNTHETIC RECOVERY DRAFT',coordinates='55, 73')
draft.step=len(draft.fields);draft.state='confirm';draft.save()
output=io.BytesIO();Image.new('RGB',(2,2),'white').save(output,format='PNG')
data=validate_upload(SimpleUploadedFile('synthetic.png',output.getvalue()))
key=store_file(data)
Photo.objects.create(draft=draft,storage_key=key,**{k:data[k] for k in ('name','size','sha256')})
snapshot={'binding':str(b.pk),'draft':str(draft.pk),'job':str(j.pk),'report_count':Report.objects.count(),'attachment_count':Attachment.objects.count(),'movement_count':StockMovement.objects.count(),'outbox_count':Outbox.objects.count(),'user_hashes':{str(u.pk):u.password for u in User.objects.all()},'files':{str(p.relative_to(settings.PRIVATE_DOCUMENT_ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(settings.PRIVATE_DOCUMENT_ROOT).rglob('*') if p.is_file()},'config':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/run/armada').iterdir() if p.is_file()}}
assert not Inbox.objects.exists() and not Outbox.objects.filter(state='sent').exists()
print('MAXSNAPSHOT:'+json.dumps(snapshot))
'''
output=shell('ORIGINAL='+repr(snapshot)+'\n'+code)
maxstate=json.loads(next(l.removeprefix('MAXSNAPSHOT:') for l in output.splitlines() if l.startswith('MAXSNAPSHOT:')))
shell("from pathlib import Path; from django.conf import settings; import os; p=Path(settings.PRIVATE_DOCUMENT_ROOT); [os.chown(f,10001,10001) for f in [p,*p.rglob('*')]]")
for suffix,source in [('max-runtime','/app'),('max-python','/usr/local/lib/python3.12/site-packages')]:
 volume=name+'_'+suffix
 run(cli+['volume','create','--label','com.docker.compose.project='+name,'--label','com.docker.compose.volume='+suffix,volume])
 volumes.append(volume)
 paths=['server'] if suffix=='max-runtime' else ['.']
 content=run(base+['exec','-T','web','tar','-C',source,'-cf','-',*paths],binary=True)
 run(cli+['run','--rm','-i','--network','none','--user','0:0','-v',volume+':/restore','--entrypoint','tar','python:3.12-slim-bookworm','-C','/restore','-xf','-'],input=content,binary=True)
run(base+['--profile','max','up','-d','--no-build','--no-deps','maxworker'])
worker_id=run(base+['--profile','max','ps','-q','maxworker']).strip()
assert json.loads(run(cli+['inspect',worker_id]))[0]['State']['Running']
before=set((root/'backups').glob('*.tar.gz'))
root_run('bash '+str(deploy/'backup.sh'),'max-backup')
new=set((root/'backups').glob('*.tar.gz'))-before;assert len(new)==1
maxarchive=new.pop()
worker_id=run(base+['--profile','max','ps','-q','maxworker']).strip()
assert json.loads(run(cli+['inspect',worker_id]))[0]['State']['Running']
print('PASS MAX backup: real process_max without delivery stopped/resumed by stock backup.sh; DB, private photos, MAX keys and .env captured.',flush=True)
# Repeat the checksum-bound installer on 6.31.0 while the actual MAX worker runs.
root_run('bash '+str(release/'install-6.31.0.sh'),'max-reinstall')
ready()
worker_id=run(base+['--profile','max','ps','-q','maxworker']).strip()
assert json.loads(run(cli+['inspect',worker_id]))[0]['State']['Running']
assert 'ARMADA_MAX_ENABLED=1' in (deploy/'.env').read_text()
print('PASS MAX reinstall: installer froze writers during migration, retained settings and resumed only the previously active MAX worker.',flush=True)
# Exercise backup.sh optional encryption, not just the crypto library.
import sys
sys.path.insert(0,'/workspace/openIA/server')
from projects import disk_crypto
private,public,_=disk_crypto.generate()
(root/'synthetic-recovery-public.pem').write_text(public)
before_encrypted=set((root/'backups').glob('*.encrypted'))
root_run('ARMADA_BACKUP_PUBLIC_KEY='+str(root/'synthetic-recovery-public.pem')+' bash '+str(deploy/'backup.sh'),'max-encrypted-backup')
encrypted=set((root/'backups').glob('*.encrypted'))-before_encrypted
assert len(encrypted)==1
cipher=encrypted.pop();plain=root/'decrypted-synthetic.tar.gz'
disk_crypto.decrypt(cipher,plain,private)
assert Path(str(cipher)+'.key-id').read_text()==disk_crypto.generate.__globals__['hashlib'].sha256(public.encode()).hexdigest()
maxarchive=plain
print('PASS encrypted backup: real backup.sh encrypted its complete archive on a public key; offline decryption succeeded; no private key mounted in server.',flush=True)
restore_code='''
import hashlib,uuid
from pathlib import Path
from unittest.mock import patch
from django.conf import settings
from django.test import override_settings,Client
from accounts.models import User
from repairs.models import Report,Attachment
from projects.models import StockMovement
from maxbot.models import Binding,Draft,Photo,Inbox,Outbox
from documents.storage import verified_file
from maxbot import worker
assert settings.ARMADA_MAX_ENABLED is False
assert Binding.objects.get(pk=S['binding']).active
assert Draft.objects.get(pk=S['draft']).state=='confirm'
assert Report.objects.count()==S['report_count'] and Attachment.objects.count()==S['attachment_count']
assert StockMovement.objects.count()==S['movement_count']
assert {str(u.pk):u.password for u in User.objects.all()}==S['user_hashes']
assert {str(p.relative_to(settings.PRIVATE_DOCUMENT_ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in Path(settings.PRIVATE_DOCUMENT_ROOT).rglob('*') if p.is_file()}==S['files']
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/run/armada').iterdir() if p.is_file()}==S['config']
import os
os.setgid(10001);os.setuid(10001)
assert Outbox.objects.count()==S['outbox_count'] and not Outbox.objects.filter(state='sent').exists()
with verified_file(Photo.objects.get()) as photo:assert photo.read().startswith(bytes.fromhex('89504e47'))
client=Client(HTTP_HOST='app.armada-sibir.ru',HTTP_X_FORWARDED_PROTO='https')
assert client.post('/integrations/max/webhook/',data='{}',content_type='application/json',secure=True).status_code==503
row=Inbox.objects.create(key=uuid.uuid4().hex,max_user=101,chat=201,payload={'kind':'message_callback','text':'confirm:'+S['draft'],'photos':[],'timestamp':1000})
with override_settings(ARMADA_MAX_ENABLED=True),patch('maxbot.transport.send',side_effect=AssertionError('NO EXTERNAL SEND')):
 worker.process(row.pk);worker.process(row.pk)
assert Report.objects.count()==S['report_count']+1
assert Attachment.objects.count()==S['attachment_count']+1
assert StockMovement.objects.count()==S['movement_count']
assert Draft.objects.get(pk=S['draft']).state=='submitted'
assert not Outbox.objects.filter(state='sent').exists()
print('PASS MAX restored: complete host archive recovered into a separate DB/config/documents; hashes and bindings/draft/photo retained, confirmation applied once, external sends disabled.')
'''
output=restore(maxarchive,'6.31.0','armada_maxrestore631','S='+repr(maxstate)+'\n'+restore_code,max_env=True)
for line in output.splitlines():
 if line.startswith('PASS '):print(line,flush=True)
