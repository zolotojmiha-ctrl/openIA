import hashlib,json,os,subprocess,zipfile
from pathlib import Path
base=Path(__file__).resolve().parent
archive=base.parent/'final/openIA-6.31.0-update.zip'
manifest={};prefix='openIA-feature-accounts-foundation/'
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for info in z.infolist():
  if info.is_dir():continue
  assert info.filename.startswith(prefix)
  name=info.filename[len(prefix):];paths=[]
  if name.startswith(('server/','portal/')) or name in ('index.html','deploy/synology/start.sh','deploy/synology/init_secrets.py'):paths.append('/app/'+name)
  if name.startswith('server/static/'):paths.append('/app/static/'+name[len('server/static/'):])
  for path in paths:manifest[path]=hashlib.sha256(z.read(info)).hexdigest()
(base/'image-manifest.json').write_text(json.dumps(manifest))
env=os.environ.copy()
for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(k,None)
code="import sys,json,hashlib,pathlib; m=json.load(sys.stdin); bad=[p for p,h in m.items() if not pathlib.Path(p).is_file() or hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()!=h]; assert not bad,bad; print('PASS final image hashes:',len(m))"
subprocess.run(['docker','--host=unix:///var/run/docker.sock','run','--rm','--network','none','--read-only','-i','--entrypoint','python','armada-web:6.31.0','-c',code],input=json.dumps(manifest),text=True,env=env,check=True)
