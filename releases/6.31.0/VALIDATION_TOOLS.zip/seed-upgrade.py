import json, secrets, hashlib, uuid
from pathlib import Path
from decimal import Decimal
from django.conf import settings
from django.test import Client
from django.utils import timezone
from django.core.files.uploadedfile import SimpleUploadedFile
from accounts.models import User, AccessGrant
from projects.models import LegalEntity, ProjectObject, Contract, ContractObject, ContractAccess, ObjectAccess, COMPANY_TAX_ID, StockItem
from projects import stock
from documents.models import Document, Bundle, Person
from documents.services import make_version
from documents.storage import validate_upload
from finance.models import FinancialScope, FinancialImport, OpeningSnapshot, PendingWork
from repairs.models import Section, Job, Defect, JobDefect, Report
from postoffice.models import Mailbox
from postoffice.crypto import seal

company=LegalEntity.objects.get(tax_id=COMPANY_TAX_ID)
leader=User.objects.create_user('+70000000601',secrets.token_urlsafe(24),full_name='ТЕСТ Руководитель',leader_slot=1,must_change_password=False,session_version=8)
worker=User.objects.create_user('+70000000602',secrets.token_urlsafe(24),full_name='ТЕСТ Мастер',role='foreman',must_change_password=False)
obj=ProjectObject.objects.create(legal_entity=company,name='ТЕСТ Участок до обновления')
ObjectAccess.objects.create(user=worker,project_object=obj,granted_by=leader)
contract=Contract.objects.create(legal_entity=company,number='ТЕСТ-623',subject='ТЕСТ',work_kinds=['repairs'])
ContractObject.objects.create(contract=contract,project_object=obj)
ContractAccess.objects.create(user=worker,contract=contract,granted_by=leader)
person=Person.objects.create(legal_entity=company,created_by=leader,full_name='ТЕСТ Сотрудник')
bundle=Bundle.objects.create(title='ТЕСТ Комплект',legal_entity=company,created_by=leader)
doc=Document.objects.create(legal_entity=company,created_by=leader,title='ТЕСТ Сохранённый документ',section='other',bundle=bundle)
doc.objects_linked.add(obj);doc.contracts_linked.add(contract);doc.personnel_linked.add(person)
version=make_version(doc,leader,validate_upload(SimpleUploadedFile('synthetic.txt',b'synthetic preserved upgrade content')))
source=FinancialImport.objects.create(sha256=version.sha256,original_name='synthetic.txt',uploaded_by=leader,source_document=doc,source_version=version)
scope=FinancialScope.objects.create(legal_entity=company,title='ТЕСТ Финансы',created_by=leader,contract=contract)
OpeningSnapshot.objects.create(scope=scope,source=source,total_defects=10,repaired_defects=4,advance_received=500,accepted=800,paid_for_work=600,advance_offset=200,declared_advance_balance=300,declared_pending=100)
PendingWork.objects.create(scope=scope,title='ТЕСТ Неоплаченное выполнение',amount=100,source=source)
warehouse=stock.save_warehouse(leader,None,None,{'name':'ТЕСТ Склад','location':'ТЕСТ Адрес','served_objects':[obj],'served_brigades':[]})
item=stock.save_item(leader,None,None,{'sku':'UPGRADE-623','name':'ТЕСТ Материал','kind':'material','unit':'kg','method':'','diameter_mm':None,'length_mm':None,'wall_mm':None,'coupling':None,'archived':False})
movement=stock.move(leader,item.pk,'receipt',Decimal('7.5'),None,warehouse.pk,timezone.localdate(),'ТЕСТ Поступление',uuid.uuid4())
section=Section.objects.create(project_object=obj,rnu='ТЕСТ',pipeline='ТЕСТ',name='ТЕСТ Ведомость')
job=Job.objects.create(contract=contract,section=section,assigned_to=worker,created_by=leader,method='p2',length_m=1,wall_mm=8,composition='',problem='swamp',problem_note='ТЕСТ Болото')
defect=Defect.objects.create(contract=contract,section=section,kilometre='10.123',number='UPGRADE-623');JobDefect.objects.create(job=job,defect=defect)
report=Report.objects.create(job=job,author=worker,kind='problem',performed_date=timezone.localdate(),problem='swamp',note='ТЕСТ История до обновления')
mailbox=Mailbox.objects.create(address='info@armada-sibir.ru',state='active',credential=seal('synthetic-provider-secret'),created_by=leader)
# Additional pre-existing 6.23 data: kit units, physical reservation and site receipt.
from projects import stock_planning
kit=stock.save_item(leader,None,None,{'sku':'UPGRADE-KIT','name':'ТЕСТ Композит','kind':'composite','unit':'kit','method':'','diameter_mm':None,'length_mm':None,'wall_mm':None,'coupling':None,'archived':False})
stock.move(leader,kit.pk,'receipt',3,None,warehouse.pk,timezone.localdate(),'ТЕСТ Комплекты',uuid.uuid4())
piece=stock.save_item(leader,None,None,{'sku':'UPGRADE-PIECE','name':'ТЕСТ П2','kind':'coupling','unit':'pcs','method':'p2','diameter_mm':720,'length_mm':1500,'wall_mm':10,'coupling':None,'archived':False})
stock.move(leader,piece.pk,'receipt',1,None,warehouse.pk,timezone.localdate(),'ТЕСТ Муфта',uuid.uuid4())
piece=stock_planning.reserve(leader,piece.pk,piece.version,job.pk)
try:
 from postoffice.models import SiteRequest
except ImportError:
 SiteRequest=None
receipt=SiteRequest.objects.create(kind='candidate',data={'name':'ТЕСТ Сохранённая анкета','phone':'+70000000603'},digest='synthetic-upgrade-624',consent_version='2026-10-30',resume_name='synthetic.txt',resume_type='text/plain',resume_data=b'preserved candidate resume',delivery_state='sent') if SiteRequest else None
# Preserve actual rental accounting, and activate only the other pre-existing rental machine.
from projects.models import Equipment,EquipmentAssignment,EquipmentRental
from projects import rentals
from projects.crews import create_crew,assign_crew_place
from datetime import timedelta
person.user=worker;person.save()
day=timezone.localdate()-timedelta(days=1)
brigade=create_crew(leader,'ТЕСТ Бригада перехода',person,[],day)
crew=assign_crew_place(leader,brigade.pk,brigade.version,contract.pk,obj.pk,day,None)
eq=Equipment.objects.create(legal_entity=company,name='ТЕСТ С прежними часами',inventory_number='UPGRADE-RENT-OLD',category='Экскаватор',ownership='rent',created_by=leader)
placement=EquipmentAssignment.objects.create(equipment=eq,project_object=obj,contract=contract,crew_assignment=crew,start_date=day,created_by=leader)
rental=rentals.configure(leader,placement.pk,'ТЕСТ Поставщик','ТЕСТ Договор')
rate=rentals.add_rate(leader,rental.pk,day,'hour',Decimal(100),Decimal(80))
rental_day=rentals.save_day(worker,rental.pk,day,'work')
rental_payment=rentals.payment(leader,rental.pk,day,Decimal(300),'ТЕСТ Аванс',uuid.uuid4())
period=rentals.close_period(leader,rental.pk,day,day,'ТЕСТ Сверка')
eq_new=Equipment.objects.create(legal_entity=company,name='ТЕСТ Уже внесённый арендный экскаватор',inventory_number='UPGRADE-RENT-AUTO',category='Экскаватор',ownership='rent',owner='ТЕСТ Владелец',created_by=leader)
placement_new=EquipmentAssignment.objects.create(equipment=eq_new,project_object=obj,contract=contract,crew_assignment=crew,start_date=day,created_by=leader)
rentals.ensure_for_assignment(leader,placement_new)
client=Client(HTTP_HOST='app.armada-sibir.ru',HTTP_X_FORWARDED_PROTO='https');client.force_login(leader)
assert client.get('/cabinet/',secure=True).status_code==200
snapshot={'rental':str(rental.pk),'rental_equipment':str(eq.pk),'rental_day':str(rental_day.pk),'rental_payment':str(rental_payment.pk),'rental_period':str(period.pk),'rental_snapshot':period.snapshot,'auto_equipment':str(eq_new.pk),'auto_placement':str(placement_new.pk),'leader':str(leader.pk),'worker':str(worker.pk),'password_hash':leader.password,'session':client.cookies[settings.SESSION_COOKIE_NAME].value,
 'document':str(doc.pk),'version':str(version.pk),'sha256':version.sha256,'contract':str(contract.pk),'object':str(obj.pk),'person':str(person.pk),'scope':str(scope.pk),
 'kit':str(kit.pk),'piece':str(piece.pk),'piece_version':piece.version,'coupling':str(piece.coupling_id),'site_request':str(receipt.pk) if receipt else None,'warehouse':str(warehouse.pk),'item':str(item.pk),'movement':str(movement.pk),'job':str(job.pk),'report':str(report.pk),'mailbox':str(mailbox.pk),'mail_credential':mailbox.credential,
 'config_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in Path('/run/armada').iterdir() if p.is_file()}}
from projects.models import CounterpartyAgreement
legacy=CounterpartyAgreement.objects.create(number='ТЕСТ СТАРЫЙ 6251',kind='equipment_rent',counterparty='ТЕСТ Арендодатель',subject='Договор до обновления',amount=Decimal('21000.01'),customer_contract=contract,project_object=obj,created_by=leader)
legacy.documents.add(doc)
snapshot.update(legacy_agreement=str(legacy.pk))
# Executed in the isolated baseline 6.25.0 before the original backup.
legacy.customer_contracts.add(contract)
legacy.project_objects.add(obj)
other_object=ProjectObject.objects.create(legal_entity=company,name='ТЕСТ Второй участок договора')
other_contract=Contract.objects.create(legal_entity=company,number='ТЕСТ ВТОРОЙ 6251',subject='ТЕСТ',work_kinds=['repairs'])
ContractObject.objects.create(contract=other_contract,project_object=other_object)
legacy.customer_contracts.add(other_contract)
legacy.project_objects.add(other_object)
pto=User.objects.create_user('+70000000611',secrets.token_urlsafe(24),full_name='ТЕСТ ПТО до обновления',role='pto',must_change_password=False,session_version=4)
for permission in ['repairs.prepare','works.prepare','document.upload','document.export','contract.changes']:
 AccessGrant.objects.create(user=pto,permission=permission,granted_by=leader)
ObjectAccess.objects.create(user=pto,project_object=obj,granted_by=leader)
ContractAccess.objects.create(user=pto,contract=contract,granted_by=leader)
if BASE_VERSION!='6.25.0':AccessGrant.objects.create(user=pto,permission='stock.manage',granted_by=leader)
pto_client=Client(HTTP_HOST='app.armada-sibir.ru',HTTP_X_FORWARDED_PROTO='https');pto_client.force_login(pto)
assert pto_client.get('/cabinet/stock/settings/coating/',secure=True).status_code==(200 if BASE_VERSION!='6.25.0' else 403)
from projects.models import CoatingProfile,StockMovement
norm_items={}
for kind in ['ksizol','wrapper','primer']:
 material=stock.save_item(leader,None,None,{'sku':'UPGRADE-NORM-'+kind,'name':'ТЕСТ '+kind,'kind':kind,'unit':'kg','method':'','diameter_mm':None,'length_mm':None,'wall_mm':None,'coupling':None,'archived':False})
 stock.move(leader,material.pk,'receipt',Decimal(100),None,warehouse.pk,timezone.localdate(),'ТЕСТ Материал норм',uuid.uuid4())
 norm_items[kind]=material
profile=CoatingProfile.objects.create(method='p2',diameter_mm=720,length_mm=1000,full_length_mm=1460,area_per_m=Decimal('2.55'),tape=norm_items['ksizol'],wrapper=norm_items['wrapper'],primer=norm_items['primer'],basis='ТЕСТ Сохранённая технологическая карта',created_by=leader)
expense=stock.move(leader,norm_items['primer'].pk,'consume',Decimal('1.25'),warehouse.pk,None,timezone.localdate(),'ТЕСТ Прежний расход',uuid.uuid4(),job_id=job.pk)
stock.reverse(leader,expense.pk,'ТЕСТ Прежняя отмена',uuid.uuid4())
snapshot.update(pto=str(pto.pk),pto_hash=pto.password,pto_session=pto_client.cookies[settings.SESSION_COOKIE_NAME].value,pto_had_stock=BASE_VERSION!='6.25.0',pto_grants={g.permission:str(g.pk) for g in pto.grants.exclude(permission='stock.manage')},profile=str(profile.pk),expense=str(expense.pk),movement_count=StockMovement.objects.count(),agreement_contracts=sorted(str(c.pk) for c in legacy.customer_contracts.all()),agreement_objects=sorted(str(o.pk) for o in legacy.project_objects.all()))


from projects import stock_planning
deleted=stock.save_item(leader,None,None,{'sku':'UPGRADE-DELETED','name':'ТЕСТ Ошибочные комплекты','kind':'sealant','unit':'kit','method':'','diameter_mm':None,'length_mm':None,'wall_mm':None,'coupling':None,'archived':False})
stock.move(leader,deleted.pk,'receipt',Decimal(24),None,warehouse.pk,timezone.localdate(),'ТЕСТ',uuid.uuid4())
stock_planning.delete(leader,deleted.pk,deleted.version,'ТЕСТ Ошибка')
loss=StockMovement.objects.get(item=deleted,kind='loss')
old_p1=Job.objects.create(contract=contract,section=section,assigned_to=worker,created_by=leader,method='p1',length_m=1,wall_mm=8,state='reported')
old_report=Report.objects.create(job=old_p1,author=leader,kind='complete',outcome='complete',method='p1',length_m=1,performed_date=timezone.localdate(),note='ТЕСТ Историческая П1')
snapshot.update(deleted_item=str(deleted.pk),deleted_loss=str(loss.pk),old_p1=str(old_p1.pk),old_p1_report=str(old_report.pk),movement_count=StockMovement.objects.count())
print('SNAPSHOT:'+json.dumps(snapshot))
