import os,socket,subprocess,tempfile,time,sys
from pathlib import Path
work=Path(__file__).resolve().parent;pg=work/'pg17-native/root';bin=pg/'usr/lib/postgresql/17/bin'
env=os.environ.copy()
for k in ('DATABASE_URL_FILE','ARMADA_MAIL_KEY_FILE'):env.pop(k,None)
env['LD_LIBRARY_PATH']=str(pg/'usr/lib/x86_64-linux-gnu')+(':'+env['LD_LIBRARY_PATH'] if env.get('LD_LIBRARY_PATH') else '')
with tempfile.TemporaryDirectory(prefix='armada-pg631-',dir=work) as td:
 root=Path(td);root.chmod(0o700);data=root/'data'
 with (work/'native-postgresql-server.log').open('w') as log:
  subprocess.run([str(bin/'initdb'),'-D',str(data),'-U','armada_test','--auth','trust','--locale','en_US.utf8','--encoding','UTF8','--no-sync'],env=env,stdout=log,stderr=log,check=True)
  with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
  server=subprocess.Popen([str(bin/'postgres'),'-D',str(data),'-h','127.0.0.1','-p',str(port),'-k',str(root),'-c','shared_buffers=32MB','-c','max_wal_size=64MB','-c','min_wal_size=32MB','-c','fsync=off'],env=env,stdout=log,stderr=log)
  try:
   for _ in range(80):
    if subprocess.run([str(bin/'pg_isready'),'-h','127.0.0.1','-p',str(port),'-U','armada_test'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:break
    if server.poll() is not None:raise RuntimeError('Isolated PG17 exited during startup')
    time.sleep(.25)
   runtime=Path('/workspace/openIA/.runtime/release631-full');(runtime/'static').mkdir(mode=0o700,parents=True,exist_ok=True)
   env.update(DATABASE_URL=f'postgresql://armada_test@127.0.0.1:{port}/postgres',ARMADA_DEVELOPMENT='1',ARMADA_RUNTIME_DIR=str(runtime))
   print('Final source: '+subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),flush=True)
   print(subprocess.check_output([str(bin/'postgres'),'-V'],env=env,text=True).strip()+'; isolated local temporary DB; en_US.utf8; no production service',flush=True)
   result=subprocess.run(['.venv/bin/python','server/manage.py','test','accounts','projects','documents','finance','repairs','postoffice','maxbot','--noinput','--verbosity','2'],env=env)
  finally:
   subprocess.run([str(bin/'pg_ctl'),'-D',str(data),'stop','-m','fast'],env=env,stdout=log,stderr=log,timeout=30)
   server.wait(timeout=30)
raise SystemExit(result.returncode)
