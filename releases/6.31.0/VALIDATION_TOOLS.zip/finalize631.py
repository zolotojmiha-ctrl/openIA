"""Finalize only after every final-source validation passes. Contains no private key material."""
import calendar,hashlib,io,json,os,re,subprocess,zipfile
from pathlib import Path
repo=Path('/workspace/openIA');work=Path(__file__).resolve().parent;out=work.parent/'final'
source='b41e5ca0f10cf9b9055b4856c0f33e5be838a38a';version='6.31.0'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
assert not git('status','--porcelain')
head=git('rev-parse','HEAD')
subprocess.run(['git','merge-base','--is-ancestor',source,head],cwd=repo,check=True)
allowed={'README.md','RELEASE_6_31_VALIDATION.md','docs/PROJECT_HANDOVER.md','docs/MAX_VALIDATION.md','docs/YANDEX_DISK_BACKUPS.md'}
assert set(git('diff','--name-only',source,head).splitlines())<=allowed
meta=json.loads((out/'openIA-6.31.0-update.json').read_text());assert meta['source_commit']==source
archive=out/meta['archive'];installer=out/meta['installer']
assert sha(archive)==meta['archive_sha256'] and sha(installer)==meta['installer_sha256']
assert installer.read_text()==subprocess.check_output(['git','show',source+':deploy/beget/install-update.sh.in'],cwd=repo,text=True).replace('__VERSION__',version).replace('__ARCHIVE_SHA256__',sha(archive))
profile=(work/'full-postgresql-final.log').read_text();match=re.search(r'Ran (\d+) tests in ([\d.]+)s',profile)
assert match and int(match[1])==1118 and '\nOK\n' in profile and 'FAILED (' not in profile and source in profile
assert 'Ran 24 tests' in (work/'installer-final.log').read_text() and '\nOK\n' in (work/'installer-final.log').read_text()
assert 'Ran 7 tests' in (work/'policy-final.log').read_text() and '\nOK\n' in (work/'policy-final.log').read_text()
versions=['6.25.0','6.25.1','6.26.0','6.27.0','6.28.0','6.29.0','6.30.0'];stages=0
for v in versions:
 text=(work/('upgrade-'+v+'.log')).read_text();expected=7 if v=='6.30.0' else 3
 assert text.count('PASS ')==expected and 'Traceback' not in text,(v,text[-200:]);stages+=expected
for mode in ('build','before','migration','health'):
 text=(work/('failure-'+mode+'.log')).read_text();expected=2 if mode=='build' else 3
 assert text.count('PASS ')==expected and 'Traceback' not in text,(mode,text[-200:]);stages+=expected
assert stages==36
for p in work.glob('write-probes-*.json'):
 probes=json.loads(p.read_text());assert probes and all(r['blocked'] for r in probes),p
assert 'PASS encrypted archive:' in (work/'backup-restore-final.log').read_text()
assert 'PASS restore rejection:' in (work/'backup-restore-final.log').read_text()
assert 'No changes detected' in (work/'migrations-check.log').read_text()
assert not git('diff','--name-only','14e88e83eefc6fe147179347b3c0ebbba474020d',source,'--','server/*/migrations/*')
assert 'PASS final image hashes: 666' in (work/'image-verify.log').read_text()
raw=subprocess.check_output(['git','archive','--format=zip',source],cwd=repo)
manifest={};prefix='openIA-feature-accounts-foundation/'
with zipfile.ZipFile(io.BytesIO(raw)) as original,zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for item in z.infolist():
  if item.is_dir():continue
  assert item.filename.startswith(prefix)
  name=item.filename[len(prefix):]
  assert not any(p in ('.git','.runtime','__pycache__','.env') for p in Path(name).parts)
  assert name!='AGENTS.md' and not name.startswith(('previous-draft/','tests/'))
  assert z.read(item)==original.read(name),name
  manifest[name]=hashlib.sha256(z.read(item)).hexdigest()
assert len(manifest)==meta['archive_files']==701
(out/'SOURCE_FILES.json').write_text(json.dumps({'source_commit':source,'files':manifest},ensure_ascii=False,indent=2)+'\n')
env=os.environ.copy()
for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(k,None)
d=['docker','--host=unix:///var/run/docker.sock']
image=subprocess.check_output(d+['image','inspect','armada-web:6.31.0','--format','{{.Id}}'],env=env,text=True).strip()
for previous in ('6.29.0','6.30.0'):
 folder=Path('/workspace/armada-release-'+previous+'/final');m=json.loads((folder/('openIA-'+previous+'-update.json')).read_text())
 assert sha(folder/m['archive'])==m['archive_sha256'] and sha(folder/m['installer'])==m['installer_sha256']
 if m.get('image_id'):assert subprocess.check_output(d+['image','inspect','armada-web:'+previous,'--format','{{.Id}}'],env=env,text=True).strip()==m['image_id']
bundle=out/'armada-6.31.0-final.bundle'
subprocess.run(['git','bundle','create',str(bundle),'feature/cabinet-6.31.0','^7c33879edf9efaced359d84280c36acfa1aa1b93'],cwd=repo,check=True)
subprocess.run(['git','bundle','verify',str(bundle)],cwd=repo,check=True,stdout=subprocess.DEVNULL)
meta.update(status='locally_verified',ready_for_install=True,published=False,production_installed=False,
 documentation_commit=head,bundle_head=head,image_id=image,image_verified_files=666,archive_matches_git_files=701,
 full_postgresql_tests=int(match[1]),full_postgresql_seconds=float(match[2]),full_postgresql_source=source,
 postgresql_version='17.11',postgresql_base_digest='sha256:3645570cccdfa447589da9f57dd740faa29b30938e861289a5574b6ca6b03826',
 full_postgresql_runtime='isolated native PG17 engine copied from pinned image; en_US.utf8; temporary data; localhost; fsync off',
 source_versions=versions,reinstall_version='6.31.0',installer_guard_cases=24,backup_policy_tests=7,
 upgrade_restore_stages=stages,new_migrations=False,real_messages_sent=False,live_max_checked=False,
 live_yandex_disk_checked=False,public_https_checked=False,max_default_enabled=False,max_requires_pilot=True,
 bundle=bundle.name,bundle_sha256=sha(bundle),bundle_base='7c33879edf9efaced359d84280c36acfa1aa1b93')
(out/'VALIDATION.md').write_text(f'''# Армада Управление 6.31.0 — итоговая проверка, 10 ноября 2026

Локальный выпуск проверен; публикации и установки на VPS не было. MAX выключен по умолчанию. Настоящие MAX/SMTP/Яндекс, публичный HTTPS и Figma не использовались.

Источник ZIP: {source}. Документальный итог: {head}. ZIP SHA-256 {sha(archive)}, установщик SHA-256 {sha(installer)}. 701 файл ZIP сверён побайтно с Git; 160 служебных записей исключены. Образ {image}, все 666 файлов приложения/статики сверены с ZIP. Сборка offline из hash-locked wheels, исходные Python/PG base закреплены digest; proxy/CA/registry credentials не заменялись.

Полный прогон именно конечного коммита: **1118 PostgreSQL 17/Chromium-тестов OK за {float(match[2])} с**. Движок PostgreSQL 17.11 извлечён из закреплённого официального образа; запущен от пользователя среды в отдельном временном каталоге/БД, en_US.utf8, loopback со случайным портом, fsync отключён только на синтетическом стенде. После прогона процесс/данные удалены. Прежние прогоны d144903 и 3962421 по 1117 OK не выдаются за конечный результат. Отдельно: 24 сценария установщика, 7 политики/шифрования, makemigrations --check без изменений; миграции относительно 6.30.0 не менялись.

Конечный checksum-bound/подписанный тестовым ключом установщик выполнен на {', '.join(versions)}. Для каждой версии: штатная копия, обновление, проверка данных, фактическое восстановление оригинальной копии в отдельные БД/config/documents — 21 этап. На 6.30.0 дополнительно: работающий process_max без доставки, backup со стоп/возобновлением, повторная установка с включённым worker, реальный backup.sh с шифрованием на отдельный открытый ключ, офлайн-расшифровка и восстановление полного MAX-состояния с фото/черновиком/повторным подтверждением (один отчёт). Ещё 4 этапа.

Принудительные ошибки сборки, до миграций, после реальных миграций и healthcheck: ещё 11 этапов. До барьера проверен возврат прежнего дерева/точного image ID/служб; после — писатели остановлены, автоматического отката нет, данные и архив сохранены и восстановлены отдельно. Итого **36 этапов PASS**. Попытки реальной записи через остановленный web при dump/конфигурации/миграциях отвергнуты; доказательства write-probes. Стандартный backup по-прежнему возобновляет прежние службы. В файловом тесте удалённый код исчезает, .env/права и inode блокировки сохранены. В 6.25–6.29 корневой тестовый адаптер действительно предъявлял старый Compose без maxworker, после переключения — новый.

Автоматическая восстановимость отдельно проверена на настоящем зашифрованном PostgreSQL 17 dump: временная БД и реально распакованные закрытые файлы, равенство строк/хэшей; неверное число строк не выдало receipt. Retention сохраняет последнюю восстановленную копию и более новые; без подтверждения не удаляет ничего. Планировщик доверенного стенда и реальная внешняя копия не включались. Закрытый recovery-ключ не передавался тестовому серверу; ключ подписи — отдельная сущность.

## Границы инфраструктурного испытания

Приложение — настоящий образ из ZIP, read-only/UID10001/cap_drop ALL/pids_limit128. Из-за VFS тестовый PostgreSQL-контейнер использовал тот же бинарный PG17.11, штатный entrypoint и неизменённый 10-create-app.sh, подключённые read-only; системные библиотеки/локаль/zoneinfo предоставлялись хостом. Это не проверка точного полного rootfs образа провайдера. DB имел реальную парольную аутентификацию/роли, отдельную internal-сеть и tmpfs, без публичных портов/рабочих томов. ID DB проверен неизменным после обновления. Proxy и mailworker заменены sleep-процессами; настоящий MAX работал без --deliver. Docker socket был только во временном root-runner. ZipFile shim воспроизводил структуру/Unix-права/время ZIP, контрольные суммы/подпись/логика установщика выполнялись штатно. Привилегии DAC_OVERRIDE/CHOWN добавлялись только синтетическим подготовительным ORM-процессам; runtime web оставался без capabilities. Закрытое tar-резервирование получает только DAC_OVERRIDE.

Ранние ограничения стенда/попытки отделены: необходимость сохранить завершённый init, экспорт кода от UID приложения, подстановка публичных библиотек и прав в минимальном тестовом PG. Обнаруженная реальная несовместимость запроса maxworker на старом Compose исправлена до конечного коммита и полного прогона. Старый тестовый комплект остановлен намеренно до изменений. Для места удалены только собственные доказанно неиспользуемые промежуточные 6.31-образы/точный кэш и повторные проверочные ZIP с сохранённой идентичной канонической копией и хэшами; старые image ID 6.29/6.30 и их архивы не изменялись. Настройки managed-среды не сохранялись/не публиковались.

## Перед настоящей установкой

- Проверить восстановленный VPS, фактическую версию, данные и место; установщик для существующего штатного приложения, не пустого VPS. Для нового сервера сначала отдельное развёртывание и восстановление. Особые локальные изменения Compose/томов требуют сверки.
- Независимо получить публичный ключ подписи, сверить его fingerprint и проверить подписанный манифест до запуска. Установить публичную часть root-owned; закрытую часть подписи хранить отдельно на Mac, не на VPS и не в Git/ZIP. В тестах был другой временный ключ, окончательный комплект подписывается ключом владельца после этого протокола.
- При первой попытке миграций барьер считается пересечённым даже при неоднозначном сбое Docker. После этого восстановление ручное по RECOVERY.md: остановить стандартные и посторонние писатели, восстановить БД/файлы/config вместе. При недоступном Docker команда остановки не считается подтверждением фактической остановки.
- MAX/Webhook/CDN/реальные отправки и Яндекс Диск требуют подключения/пилота; OAuth/recovery-ключ не получены. Автоматическая проверка должна работать на доверенном хосте с отдельным recovery-ключом, а не на VPS. Retention без receipt сохраняет всё, поэтому нужен контроль места. Яндекс Диск не является immutable-хранилищем.
- CSP ограниченная: objects/base/framing, не строгая nonce/script-src политика. У локально собранного armada-db:17 нет registry digest; можно закрепить точный ID/registry digest параметром ARMADA_DATABASE_IMAGE. Существующая БД автоматически не пересобиралась.

Git-bundle {bundle.name}: HEAD {head}, исходник ZIP {source}, база {meta['bundle_base']}, SHA-256 {sha(bundle)}. Он нужен для переноса исходников на Mac, не для установки. Документы в ZIP фиксируют состояние исходников; этот внешний протокол содержит итог.
''')
(out/'README.md').write_text('''# Армада Управление 6.31.0

Проверенный локальный накопительный выпуск с MAX и защитой обновления/резервирования. Производственный сервер не обновлён. MAX сам не включается.

Состав: ZIP, установщик, подписанный манифест/JSON, окончательный VALIDATION.md, Git-bundle и код синтетических проверок. Закрытых ключей, конфигураций, дампов и производственных данных нет. Закрытый ключ подписи хранится отдельно у владельца; публичный получить независимым доверенным способом, а не из этого архива.

До запуска установщика проверьте подпись и хэши (Mac):

```bash
openssl dgst -sha256 -verify /private/armada-release-signing.public.pem -signature SHA256SUMS-6.31.0.sig SHA256SUMS-6.31.0
shasum -a 256 -c SHA256SUMS-6.31.0
```

После восстановления Beget сначала проверить данные/версию. Установщик предназначен для существующей штатной установки, требует root, Python3.9+, OpenSSL и BuildKit; на пустом VPS сначала развёртывание/восстановление. Соседние ZIP/подписанный манифест/JSON используются локально; скачивание из GitHub возможно только после отдельной публикации. Публичную часть установить root-owned в /etc/armada/release-signing-public.pem. Закрытую часть на сервер не переносить.

Протокол и дополнительные файлы связаны хэшами в подписанном JSON. README внутри ZIP относится к полным исходникам Git; актуальный протокол — внешний VALIDATION.md. VALIDATION_TOOLS.zip — код для отдельного Linux/Docker-стенда, не запускать на рабочем VPS.

Ключ подписи и ключ расшифровки резервных копий — разные ключи. Для локального шифрования можно на доверенном компьютере получить recovery-public.pem из сохранённого recovery-private.pem командой openssl pkey -in recovery-private.pem -pubout -out recovery-public.pem, затем на VPS передавать только recovery-public.pem. Само расписание/настройки внешнего хранилища не включены. Параметры KEEP/DAYS/PUBLIC_KEY для systemd задаются администратором в drop-in службы, не через публикацию секретов. Перед очисткой старых копий необходимо подтверждение настоящего восстановления.
''')
tools=['check-upgrade.py','max-roundtrip.py','run-matrix.py','run-remaining.py','run-failures.py','seed-upgrade.py','verify-upgrade.py','check-image.py','run-full-native.py','prepare-native-pg.py','prepare-test-db.py','prepare-fixture.py','finalize631.py']
with zipfile.ZipFile(out/'VALIDATION_TOOLS.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in tools:z.write(work/name,name)
 for name in ('tests/check_release_installer.py','tests/test_release_safety.py','tests/test_backup_policy.py','tests/check_backup_restore.py'):z.write(repo/name,'repository/'+name)
attachments=[bundle,out/'VALIDATION.md',out/'README.md',out/'SOURCE_FILES.json',out/'VALIDATION_TOOLS.zip']
meta['attachments']={p.name:sha(p) for p in attachments}
(out/'openIA-6.31.0-update.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
# Company key is never copied into final/, the Git bundle, tools, logs or installer.
subprocess.run(['python',str(repo/'deploy/beget/sign_release.py'),'--directory',str(out),'--version',version,'--key-file','/workspace/armada-release-signing/private/armada-release-signing.key.pem'],cwd=repo,check=True)
public=Path('/workspace/armada-release-signing/armada-release-signing.public.pem')
subprocess.run(['openssl','dgst','-sha256','-verify',str(public),'-signature',str(out/'SHA256SUMS-6.31.0.sig'),str(out/'SHA256SUMS-6.31.0')],check=True)
subprocess.run(['sha256sum','--check','SHA256SUMS-6.31.0'],cwd=out,check=True)
signed=json.loads((out/'openIA-6.31.0-update.json').read_text())
for name,digest in signed['attachments'].items():assert sha(out/name)==digest
assert all('key.pem' not in p.name and 'public.pem' not in p.name for p in out.iterdir())
outer=Path('/workspace/armada-6.31.0-local-verified.zip')
with zipfile.ZipFile(outer,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(out.iterdir()):
  if p.is_file():z.write(p,'armada-6.31.0/'+p.name)
with zipfile.ZipFile(outer) as z:assert z.testzip() is None
Path(str(outer)+'.sha256').write_text(sha(outer)+'  '+outer.name+'\n')
print('Verified signed kit:',outer.name,'bytes',outer.stat().st_size,'source',source,'stages',stages)
